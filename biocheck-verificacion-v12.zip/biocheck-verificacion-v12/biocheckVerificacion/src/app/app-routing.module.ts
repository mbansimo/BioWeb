import {NgModule} from '@angular/core';
import {PreloadAllModules, RouterModule, Routes} from '@angular/router';
import {LayoutComponent} from "./layout/layout.component";


const routes: Routes = [
  {path: '', redirectTo: ' ', pathMatch: 'full',},
  {
    path: '', component: LayoutComponent, children: [
      {
        path: '', loadChildren: () => import('./website/home/home.module').then(m => m.HomeModule)
      },
      {
        path: 'avisoDePrivacidad', loadChildren: () => import('./website/aviso-de-privacidad/avisoDePrivacidad.module').then(m => m.AvisoDePrivacidadModule)
      },
      {
        path: 'full', loadChildren: () => import('./website/verificacion-full/verificacion-full.module').then(m => m.VerificacionFullModule)
      },
      {
        path: 'capturaIdManual', loadChildren: () => import('./website/captura-id-manual/capturaIdManual.module').then(m => m.CapturaIdManualModule)
      },
      {
        path: 'capturaDeRostro', loadChildren: () => import('./website/capturade-rostro/capturaDeRostro.module').then(m => m.CapturaDeRostroModule)
      },
      {
        path: 'capturaRostroIne', loadChildren: () => import('./website/captura-rostro-ine/captura-rostro-ine.module').then(m => m.CapturaRostroIneModule)
      },
      {
        path: 'escaner-ine', loadChildren: () => import('./website/escaner-ine/escaner-ine.module').then(m => m.EscanerIneModule)
      },
      {
        path: 'escanearRostroIne', loadChildren: () => import('./website/escanear-ine-rostro/escanear-ine-rostro.module').then(m => m.EscanearIneRostroModule)
      },
      {
        path: 'verificacion-ventanilla', loadChildren: () => import('./website/verificacion-ventanilla/verificacion-ventanilla.module').then(m => m.VerificacionVentanillaModule)
      },
      {
        path: 'verificacion-escritorio', loadChildren: () => import('./website/verificacion-escritorio/verificacion-escritorio.module').then(m => m.VerificacionEscritorioModule)
      },
      {
        path: 'verificacion-noCliente', loadChildren: () => import('./website/verificacion-noCliente/verificacion-noCliente.module').then(m => m.VerificacionNoClienteModule)
      },
      {
        path: 'verificacionNoClientePasaporte', loadChildren: () => import('./website/verificacion-no-cliente-pasaporte/verificacion-no-cliente-pasaporte.module').then(m => m.VerificacionNoClientePasaporteModule)
      },
      {
        path: 'formaMigratoria', loadChildren: () => import('./website/verificacion-no-cliente-forma-migratoria/verificacion-no-cliente-formaMigratoria.module').then(m => m.VerificacionNoClienteFormaMigratoriaModule)
      },
      {
        path: 'NoCliente/ausenciaycaptura', loadChildren: () => import('./website/ausenciaycaptura/ausenciaycaptura.module').then(m => m.AusenciaycapturaModule)
      },
      {
        path: 'ocrRostroIne', loadChildren: () => import('./website/ocr-rostro-ine/ocr-rostro-ine.module').then(m => m.OcrRostroIneModule)
      },
      {
        path: 'ocr-identificacion', loadChildren: () => import('./website/ocr-identificacion/ocr-identificacion.module').then(m => m.OcrIdentificacionModule)
      },
      {
        path: 'verificacionSimple', loadChildren: () => import('./website/verificacion-simple/verificacion-simple.module').then(m => m.VerificacionSimpleModule)
      },
      {
        path: 'finalizar',
        loadChildren: () => import('./website/finalizar/finalizar.module').then(m => m.FinalizarModule)
      }


    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: false,
    preloadingStrategy: PreloadAllModules,

  })],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
