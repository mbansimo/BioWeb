import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';


import {AppComponent} from './app.component';
import {LayoutComponent} from './layout/layout.component';
import {AppRoutingModule} from "./app-routing.module";
import {SharedModule} from "./shared/shared.module";
import {CoreModule} from "./core/core.module";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {MaterialModule} from "./material/material.module";
import {MatDividerModule} from "@angular/material/divider";
import {DialogsModule} from "./shared/dialogs/dialogs.module";
import { UtilDialogs } from './common/util-dialogs';
import {TooltipModule} from "./website/tooltip/tooltip.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {CustomTooltipDirective} from "./directives/custom-tooltip.directive";

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    SharedModule,
    CoreModule,
    BrowserAnimationsModule,
    MaterialModule,
    MatDividerModule,
    DialogsModule
  ],
  providers: [
    UtilDialogs
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
