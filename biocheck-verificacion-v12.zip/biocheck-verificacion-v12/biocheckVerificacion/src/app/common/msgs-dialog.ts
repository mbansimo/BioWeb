export const MessagesDialogProcesando = {
  cargandoDatos: {
    title: 'Los datos biométricos fortalecen tu seguridad, úsalos al identificarte para:',
    messages: [
      {
        text: 'Retiros en ventanilla mayores a $10,000 pesos',
      },
      {
        text: 'Contratación de créditos.',
      },
      {
        text: 'Transferencias bancarias.',
      },
      {
        text: 'Contratación tarjetas de crédito.'
      },
      {
        text: 'Reposición de tarjetas de Débito.'
      },
      {
        text: 'Apertura de cuenta, plazo o fondos.'
      }
    ]
  },
  cargandoDatosFinal: {
    title: 'Los datos biométricos fortalecen tu seguridad, úsalos al identificarte para:',
    messages: [
      {
        text: 'Retiros en ventanilla mayores a $10,000 pesos',
      },
      {
        text: 'Contratación de créditos.',
      },
      {
        text: 'Transferencias bancarias.',
      },
      {
        text: 'Contratación tarjetas de crédito.'
      },
      {
        text: 'Reposición de tarjetas de Débito.'
      },
      {
        text: 'Apertura de cuenta, plazo o fondos.'
      },
      {
        text: 'Espere un momento estamos verificando la información biométrica proporcionada',
        src:'assets/img/cargador.gif',
      },
      {
        text: 'Verificando información biométrica proporcionada',
        src:'assets/img/cargador.gif',
      },
      {
        text: 'Autenticando la información biométrica del usuario',
        src:'assets/img/cargador.gif',
      }
    ]
  },
  capturaIdentificacion: {
    title: 'Tips para la captura de la identificación',
    messages: [
      {
        text: 'Centra la identificación en el escáner',
        src: 'assets/img/tips/escaner_centrar.png',
        alt: 'Instrucción'
      },
      {
        text: 'En lugares luminosos, tapa el escáner',
        src: 'assets/img/tips/escaner_tapar.png',
        alt: 'Instrucción'
      },
      {
        text: "El dispositivo se encuentra mal conectado cuando muestra una luz roja o de varios colores, para resolverlo puedes intentar lo siguiente:",
        src: 'assets/img/tips/escaner_mal_conectado.png',
        alt: '1. Reinicia la aplicación de Biocheck. 2. Apaga y prende el botón de encendido'
      }
    ]
  },
  capturaHuellas: {
    title: 'Tips para la captura de huellas',
    messages: [
      {
        text: "Limpia el decadactilar con un paño seco antes y después de capturar las huellas de los clientes, así evitarás fallas.",
        src: 'assets/img/tips/lector_limpiar.png',
        alt: 'Instrucción'
      },
      {
        text: "Si ves las huellas del cliente secas, humecta con crema o gel y ejerce presión sobre el escáner",
        src: 'assets/img/tips/lector_huellas_secas.png',
        alt: 'Instrucción'
      },
      {
        text: "Si ves las huellas como manchas negras, solícita al cliente secarlas y no ejercer presión",
        src: 'assets/img/tips/lector_huellas_manchas.png',
        alt: 'Instrucción'
      }
    ]
  },
  capturaRostro: {
    title: 'Tips para la captura de rostro',
    messages: [
      {
        text: `Si el cliente tiene fleco, ojos pequeños, frente amplia y/o demasiado maquillaje en los ojos,
              recomienda que levante la cara para la captura de su rostro`,
        src: 'assets/img/tips/camara_levantar_rostro.png',
        alt: 'Instrucción'
      },
      {
        text: 'Cuida que el cliente no tenga accesorios que obstruya alguna parte del rostro',
        src: 'assets/img/tips/camara_accesorios.png',
        alt: 'Instrucción'
      },
      {
        text: 'Ajusta el tripié a la altura del cliente',
        src: 'assets/img/tips/camara_altura.png',
        alt: 'Instrucción'
      }
    ]
  },
  ifeRenapo: {
    title: 'Consultando INE',
    messages: [
      // {
      //   text: 'Beneficios que puedes comentarle al cliente',
      //   src: 'assets/img/consultaINE.png',
      //   alt: 'Instrucción'
      // },
      {
        text: 'Actualizando sus datos hace que su identidad sea más segura',
        src: 'assets/img/INEactiva.png',
        alt: 'Instrucción'
      },
      {
        text: 'Evitaremos que terceras personas hagan mal uso de sus datos',
        src: 'assets/img/consultaINE.png',
        alt: 'Instrucción'
      }
    ]
  },
  sms: {
    title: '',
    messages: [
      {
        text: 'Beneficios que obtiene el cliente al compartirnos su número de celular',
      },
      {
        text: 'Alerta de compra',
      },
      {
        text: 'Comentar al cliente que en ocasiones la recepción del SMS puede demorar algunos segundos',
      },
      {
        text: ''
      }
    ]
  },
  undefined: {
    title: '',
    messages: [
      {
        text: 'Espere un momento estamos obteniendo los datos del cliente',
      },
      {
        text: 'Validando el enrolamiento del usuario',
      },
      {
        text: 'Obteniendo la información biométrica registrada',
      },
      {
        text: 'Espere un momento estamos verificando la información biométrica proporcionada'
      },
      {
        text: 'Verificando información biométrica proporcionada'
      },
      {
        text: 'Autenticando la información biométrica del usuario'
      }
    ]
  },
}
