import {Injectable, NgZone} from "@angular/core";
import {MatDialog, MatDialogConfig, MatDialogRef} from '@angular/material/dialog';
import {
  DataDialogModel,
  DataDialogSolicitudHuella, DataFaceCaptureCheck,
  MsgDialogModel
} from "../core/models/msg-dialog.model";
import {DialogGeneralComponent} from "../shared/dialogs/dialog-general/dialog-general.component";
import {DialogProcesandoComponent} from "../shared/dialogs/dialog-procesando/dialog-procesando.component";
import {VerificacionSimpleComponent} from "../website/verificacion-simple/verificacion-simple.component";
import { DialogHuellasComponent } from "../shared/dialogs/dialog-huellas/dialog-huellas.component";
import {DialogSolicitaHuellaComponent} from "../shared/dialogs/dialog-solicita-huella/dialog-solicita-huella.component";
import {DialogCapturaRostroComponent} from "../shared/dialogs/dialog-captura-rostro/dialog-captura-rostro.component";
import {
  DialogCapturaRostroFacialComponent
} from "../shared/dialogs/dialog-captura-rostro-facial/dialog-captura-rostro-facial.component";

@Injectable()

export class UtilDialogs {
  constructor(
    public dialog: MatDialog,
    private zone: NgZone,
  ) { }

  showDialogProcesando(data?: MsgDialogModel, time: number = 10) {
    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
//    dialogConfig.timeInterval = time
    dialogConfig.width = '50%';
    dialogConfig.height = '500px';
    dialogConfig.panelClass = 'container-dialog-bc';
    dialogConfig.maxHeight = '90vh';
    dialogConfig.autoFocus = false;
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.panelClass = ['animate__animated', 'animate__fadeIn'];
    return this.dialog.open(DialogProcesandoComponent, dialogConfig);

  }

  showDialogVerificacionSimple() {

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.id = 'dialogVerificionSimple';
    dialogConfig.role = 'dialog';
    dialogConfig.minWidth = '70%';
    dialogConfig.minHeight = '590px';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.autoFocus = false;

    return this.dialog.open(VerificacionSimpleComponent, dialogConfig);
  }

  showModalSolicitaHuella(imagen: string, instruccion: string, intentos: number) {
    const data: DataDialogSolicitudHuella = {
      title: instruccion,
      imagen: imagen,
      numeroIntentos: intentos
    }
    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.role = 'alertdialog';
    dialogConfig.minWidth = '70%';
    dialogConfig.minHeight = '590px';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.autoFocus = false;

    return this.dialog.open(DialogSolicitaHuellaComponent, dialogConfig);
  }


  showDialogCancelar() {
    const data: DataDialogModel = {
      message: '¿Deseas realmente salir del flujo?',
      labelButton: 'Si',
      isError: false,
      isConfirm: true
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.autoFocus = true;
    dialogConfig.role = 'alertdialog';
//    dialogConfig.maxWidth = '55%'; //25%
//    dialogConfig.maxHeight = '80%';
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = 'myapp-no-padding-dialog';
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este

    return this.dialog.open(DialogGeneralComponent, dialogConfig);
  }

  showDialogError(mensaje: string, btnLbl: string) {
    const data: DataDialogModel = {
      message: mensaje,
      labelButton: btnLbl,
      isError: true,
      isConfirm: true
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.autoFocus = false;
    dialogConfig.role = 'alertdialog';
    // dialogConfig.width = '80%';
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['animate__animated', 'animate__fadeIn'];
    return this.dialog.open(DialogGeneralComponent, dialogConfig);
  }

  showDialogErrorMensaje(mensaje: string, btnLbl: string, titulo?: string, noEsError?: boolean) {

    if (!noEsError) {
      if (titulo !== '' && typeof titulo !== undefined) {
        titulo = `Código de error ${titulo}`;
      } else {
        titulo = '';
      }
      console.log('Esto lleva titulo en modal::' + titulo);
      //titulo = ''; //Esto no servía de nada siempre el título quedaba vacío
    }
    const data: DataDialogModel = {
      title: noEsError ? titulo : '<style>.jconfirm-title-c{background-color:#FAFAFA;}</style>',
      message: mensaje,
      labelButton: btnLbl,
      isError: true,
      isConfirm: btnLbl == "Salir" || btnLbl == "Finalizar" ? false : true,
      isExit: btnLbl == "Salir" || btnLbl == "Finalizar" ? true : false,
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.autoFocus = false;
    dialogConfig.role = 'alertdialog';
    //dialogConfig.height = '500px';
    dialogConfig.width = '50%';
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['animate__animated', 'animate__fadeIn'];
    return this.dialog.open(DialogGeneralComponent, dialogConfig);
  }

  showDialogErrorMensajeDos(mensaje: string, btnLbl: string) {
    const data: DataDialogModel = {
      message: mensaje,
      labelButton: btnLbl,
      isError: true,
      isConfirm: true
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
//    dialogConfig.autoFocus = true; //false
    dialogConfig.role = 'dialog';
    dialogConfig.width = 'auto';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.autoFocus = false; //false
    return this.dialog.open(DialogGeneralComponent, dialogConfig);
  }
    showDialogCaupturaHuellas(dedo: string, img: string) {
    const data: DataDialogModel = {
      message: "Verificar indice izquierdo",
      labelButton: "Escanear",
      isError: true,
      isConfirm: true,
      title: "Verificar indice izquierdo"
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.autoFocus = true; //false
    dialogConfig.role = 'alertdialog';
    dialogConfig.width = '70%';
    dialogConfig.id = 'dialogHuellasIne';

    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    //dialogConfig.panelClass = ['animate__animated', 'animate__fadeIn'];
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    // dialogConfig.disableClose = true;
    return this.dialog.open(DialogHuellasComponent, dialogConfig);
  }

  showDialogFaceCaptureCheck(img: any, texto: string) {
    const data: DataFaceCaptureCheck = {
      imagen: img,
      title: 'Verifica que la captura de rostro fue adecuada si no repite el proceso',
      modal: 'faceCaptureCheck',
      labelButton: texto
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.role = 'dialog';
    dialogConfig.minWidth = '71%';
    dialogConfig.minHeight = '590px';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.autoFocus = false;

    return this.dialog.open(DialogCapturaRostroComponent, dialogConfig);
  }

  showDialogPruebaVida() {
    const data: DataFaceCaptureCheck = {
      modal: 'PruebaVida',
      title: '0.Mire al frente',
      imagen: 'assets/img/usuario.png',
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.role = 'dialog';
    dialogConfig.minWidth = '70%';
    dialogConfig.minWidth = '70%';
    dialogConfig.minHeight = '590px';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.autoFocus = false; //false

    return this.dialog.open(DialogCapturaRostroComponent, dialogConfig);
  }

  showDialogInsctructionScan(msg: string, confirm: boolean, label?: string) {
    const data: DataDialogModel = {
      message: msg,
      labelButton: label,
      isError: false,
      isConfirm: false,
      isScan: label == undefined ? false : true,
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.autoFocus = false;
    dialogConfig.role = 'alertdialog';
    dialogConfig.minWidth = '30%';
    dialogConfig.width = 'auto'; //25%
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['animate__animated','animate__fadeIn'];
    return this.dialog.open(DialogGeneralComponent, dialogConfig);
  }

/*  showDialogError(mensaje: string, btnLbl: string) {
    const data: DataDialogModel = {
      message: mensaje,
      labelButton: btnLbl,
      isError: true,
      isConfirm: true
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.autoFocus = false;
    dialogConfig.role = 'alertdialog';
    dialogConfig.width = '80%';
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['animate__animated','animate__fadeIn'];
    return this.dialog.open(DialogGeneralComponent, dialogConfig);
  }*/

  showDialogRostro() {
    const data: DataFaceCaptureCheck = {
      imagen: '',
      title: 'Captura de rostro del cliente',
      modal: 'CapturaRostroIne',
      labelButton: 'Capturar'
    };

    let dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = data;
    dialogConfig.role = 'dialog';
    dialogConfig.minWidth = '70%';
   // dialogConfig.minHeight = '590px';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este
    dialogConfig.autoFocus = false; //false

    return this.dialog.open(DialogCapturaRostroFacialComponent, dialogConfig);
  }




}
