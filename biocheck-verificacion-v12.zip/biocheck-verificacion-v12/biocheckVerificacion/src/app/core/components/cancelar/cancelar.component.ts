import {Component, NgZone, OnInit, Inject} from '@angular/core';
import {BiocheckService} from '../../services/biocheck.service';
import {PostParentService} from '../../services/post-parent.service';
import {BcstorageService} from '../../services/bcstorage.service';
import {MessagesDialogProcesando} from '../../../common/msgs-dialog';
import {UtilDialogs} from 'src/app/common/util-dialogs';
import {Errors} from 'src/app/enums/errors.msg';
import {Router} from '@angular/router';
import {BiocheckRedireccionamientoService} from '../../services/biocheck-redireccionamiento.service';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {DialogGeneralComponent} from "src/app/shared/dialogs/dialog-general/dialog-general.component";
import {ConfiguracionRespuestaModel} from '../../models/configuracion-respuesta.model';
import {FinalDateModel} from '../../models/final-date.model';
import {BiocheckErrorService} from 'src/app/core/services/biocheck.error.service';
import {DialogProcesandoComponent} from 'src/app/shared/dialogs/dialog-procesando/dialog-procesando.component';
import {MsgDialogModel} from '../../models/msg-dialog.model';
import {devOnlyGuardedExpression} from '@angular/compiler';
import {BiocheckUtils} from 'src/app/core/services/biocheck-utils.service';

@Component({
  selector: 'app-cancelar',
  template: '',
})

export class CancelarComponent implements OnInit {
  public versionBiocheck!: string;
  public versionSistema!: string;
  public isnotwhitelist: boolean = true;
  public cont: number = 0;
  public infoLista: boolean = false; //Maneja la visualización del botón "Iniciar" que esta en la página de inicio, el cual se debe ocultar cuando de invoca el enrolamiento desde kiosko
  public finalDate!: FinalDateModel;
  public codeClientFail!: number;
  public ejecutivo = null;
  public winPros = null;
  public bucEmepleado = null; //no se usa en el angularjs
  public procesadorInvoked: boolean = false; //bandera para saber si ya se invoco procesador y no invocarlo nuevamente
  public intentosReiniciarEscaner: number = 0;
  public intentosResetEscanerDoc: number = 3;
  public esReintentoEscaner: boolean = false;
  public documento: string = '';
  public responseCodeToken = undefined;
  public dialogRef: MatDialogRef<DialogGeneralComponent, any> | undefined;
  public dialogRefLoad: MatDialogRef<DialogGeneralComponent, any> | undefined;
  public guid = null;
  public IdFlujoVerificacion: number = 0;
  public path: string = "";

  constructor(
    private bcService: BiocheckService,
    private postParentService: PostParentService,
    private storageService: BcstorageService,
    private dialogs: UtilDialogs,
    private router: Router,
    private rutaService: BiocheckRedireccionamientoService,
    private zone: NgZone,
    private biocheckError: BiocheckErrorService,
    private Utils: BiocheckUtils,
  ) {
  }

  ngOnInit(): void {
    console.log('::::: Inicia componente Cancelar :::::')
    this.postParentService.postCancelarConteoller();
    this.bcService.checkService();
    this.bcService.connection$.subscribe(response => {
      if (response) {
        this.storageService.bcStorage.versionSistema = "3.2.2.6";//Controla La versión del Windows service con la que debe de ejecutarse
        this.storageService.bcStorage.versionBiocheck = "1.4.7";//Muestra la etiqueta de la versión comercial que se muestra en el header
        this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;
        this.storageService.bcStorage.issuper = false;
        this.startSignalR();
      }
    }, error => {
      console.error(error);
    })

  }

  public inicioObservables() {
    // this.bcService.failProcesador();
    this.bcService.getFinalDate();
  }

  startSignalR() {
    const urlRef = window.location.href;
    //   const dialogRefLoad = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatos);
    this.mostrarDialogProcesando();
    this.inicioObservables();
    this.bcService.setEraseBiometrics();
    this.getVersionInstalador();
    this.getUrlFronResponse(urlRef);
    this.bcService.setConfigData();
    this.setUrlComponente();
  }

  mostrarDialogProcesando() { //el tipoVerificacion se obtiene desde el componente HOME en el metodo tipoDeFlujoVerificacion() asegurar agregar su metodo para mostrar

    console.log('mostramos tipoVerificacion==' + this.storageService.bcStorage.tipoVerificacion);

    if (this.storageService.bcStorage.tipoVerificacion == 'NoClientePasaporte') {
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    } else if (this.storageService.bcStorage.tipoVerificacion == 'full'
      || this.storageService.bcStorage.tipoVerificacion == 'NoClienteINE') {
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatos);
    } else if (this.storageService.bcStorage.tipoVerificacion == 'verifica_motor' || this.storageService.bcStorage.tipoVerificacion == 'verifica_ine_facial'
      || this.storageService.bcStorage.tipoVerificacion == 'verificacion_Ine_simple') {
      console.log('dialogProcesando ::: capturarRostro')
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaRostro);
    } else if (this.storageService.bcStorage.tipoVerificacion == 'simple'
      || this.storageService.bcStorage.tipoVerificacion == 'verificacion-ventanilla'
      || this.storageService.bcStorage.tipoVerificacion == 'verificacion-no-Enrolado') {
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaHuellas);
    }
    this.storageService.bcStorage.procesandoAbierto = true;
  }


  setUrlComponente() {
    this.path = '';
    var component = window.location.href
    if (component.includes("/#!/simple")) {
      this.path = "verificacion-simple";
      this.storageService.bcStorage.tipoFlujoVerificacion = 1;
    } else if (component.includes("/#!/full")) {
      this.path = "verificacion-full";
      this.storageService.bcStorage.tipoFlujoVerificacion = 2;
    } else if (component.includes("/#!/VentanillaINE")) {
      this.path = "verificacion-ventanilla";
      this.storageService.bcStorage.tipoFlujoVerificacion = 3;
    } else if (component.includes("/#!/Ejecutivo")) {
      this.path = "verificacion-escritorio";
      this.storageService.bcStorage.tipoFlujoVerificacion = 4;
    } else if (component.includes("/#!/NoCliente?documento=ine")) {
      this.path = "verificacion-noCliente";
      this.storageService.bcStorage.tipoFlujoVerificacion = 5;
    } else if (component.includes("/#!/NoCliente?documento=pasaporte")) {
      this.path = "verificacion-noCliente";
      this.storageService.bcStorage.tipoFlujoVerificacion = 6;
    }
  }

  //#region CARGA CONFIGURACION INCIAL GENERAL
  setComponentVerify() {
    this.zone.run(() => {
      console.log('lleva al path ' + this.path)
      this.router.navigateByUrl(`/${this.path}`);
    });
    if (this.storageService.bcStorage.tipoFlujoVerificacion === 5)
      this.getDatosCanal();
  }

  getDatosCanal() {
    var datosCanal = this.storageService.bcStorage.datosCanal;
    if (datosCanal && datosCanal !== undefined && datosCanal !== null && datosCanal !== "") {
      if (typeof datosCanal !== 'string') {
        datosCanal = JSON.stringify(datosCanal);
      }
    }
    this.Utils.sendLog("info", "PaaS [" + window.location.href + "] startSignalR", "Datos personalizados cliente: " + datosCanal);

    if (datosCanal == undefined || datosCanal == null || datosCanal == "") {
      this.storageService.bcStorage.codigoflujo = "CA000";
      this.modalErrorGlobal('<p class="textoErrorModal" >No se han enviado datos adicionales (nombre, apellidos y fecha de nacimiento) desde el origen, por lo tanto no se podrá comparar la información escaneada del documento.</p>', "Salir");
      this.dialogRefLoad?.close();
      return;
    }
  }

  getVersionInstalador() {
    console.log("==== Ejecucion 2");
    const params = [
      this.storageService.bcStorage.versionBiocheck,
      this.storageService.bcStorage.versionSistema
    ];
    this.bcService.getVersionInstalador(params);
  }

  getUrlFronResponse(urlRef: string) {
    console.log("==== Ejecucion 3");
    this.bcService.getUrlFront([urlRef]);
    this.getConfiguracionRespuesta();
  }

  getConfiguracionRespuesta() {//1
    console.log("==== Ejecucion 4.A");
    this.bcService.getConfiguracionRespuesta();
    this.bcService.configuracionSistema$.subscribe({
      next: (response: ConfiguracionRespuestaModel) => {
        if (response) {
          console.log('ingreso al response...')
          let versionSistema = '';
          this.storageService.bcStorage.OmitirVigenciaIne = false;
          if (response.VersionSistema !== null && response.VersionSistema !== undefined && response.VersionSistema !== '') {
            versionSistema = response.VersionSistema;
            console.log('version de sistema[' + versionSistema + ']')
          }
          if (response.OmitirVigenciaIne != null && response.OmitirVigenciaIne != undefined && response.OmitirVigenciaIne) {
            console.log('metodo omitir vigencia INE')
            this.storageService.bcStorage.OmitirVigenciaIne = response.OmitirVigenciaIne;
            this.storageService.bcStorage.EstadosVigenciaIne = response.EstadosVigenciaIne;
            this.storageService.bcStorage.FechaVigenciaProrroga = response.FechaVigenciaProrroga;
          }
          //Si el BWS no es capaz de entregar la versión del sistema o si la entrega y esta es diferente a la declarada en el front, redirecciona.
          if (versionSistema === '' || versionSistema !== this.storageService.bcStorage.versionSistema) {
            console.log('Ingresa redireccionar...')
            this.redireccionar();
          } else {
            console.log('verifica Token...')
            this.validarTipoLicencias();
            this.verificarToken();
          }
        }
      }
    });
  }

  redireccionar() {
    console.log("==== Ejecucion 5.A");
    this.bcService.redireccionar(['verify', true]);
  }

  getParameterByName(name: string) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null)
      return "";
    else
      return decodeURIComponent(results[1].replace(/\+/g, " "));
  }

  resetStorageDataName() {
    this.storageService.bcStorage.apicNombre = "";
    this.storageService.bcStorage.apicApellidoP = "";
    this.storageService.bcStorage.apicApellidoM = "";
  }

  //#endregion

  //#region ACCIONES TOKEN
  verificarToken() {
    console.log("==== Ejecucion 5.B");
    if (this.isnotwhitelist) {
      const token = this.storageService.bcStorage.token;
      let testtoken = this.getParameterByName('testtoken');
      console.log("parametro de token que va: " + token + "testToken: " + testtoken);
      if (this.storageService.bcStorage?.token) {
        if (this.storageService.bcStorage?.token !== '' && this.storageService.bcStorage?.token !== null) {
          this.buscarTipoToken();
          this.isSuperUser();
          this.successToken();
        } else {
          if (testtoken === 'false') {
            this.buscarTipoToken();
            this.successToken();
          } else {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = 'ETO06';
            debugger;
            this.getFinalDate();
          }
        }
      } else {
        if (testtoken === 'false') {
          this.buscarTipoToken();
          this.successToken();
        } else {
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = 'ETO06';
          debugger;
          this.getFinalDate();
        }
      }
    }
  }

  buscarTipoToken() {
    var datosCanal = null;
    let tipoToken = this.storageService.bcStorage.tipoToken;
    let tokenString = this.storageService.bcStorage.token;

    if (tipoToken == 'muro') {
      console.log('==>Verificacion de token Muro [' + tokenString + ']');
      this.bcService.invokeVerifyToken([tokenString]);//Regreso (6.A)biochkHub.client.isSuperUser, (6.B)biochkHub.client.successToken,
    } else if (tipoToken == 'tot') {
      console.log('==>Verificacion de token Transversal [' + tokenString + ']');
      this.bcService.invokeVerifyTokenTransversal([tokenString]);//Regreso (6.A)biochkHub.client.isSuperUser, (6.B)biochkHub.client.successToken,
    } else {
      console.log('==>Verificacion de token [' + [tokenString] + ']');
      this.bcService.invokeVerifyToken([tokenString]);//Regreso (6.A)biochkHub.client.isSuperUser, (6.B)biochkHub.client.successToken,
    }
  }

  isSuperUser() {
    console.log("==== Ejecucion 6.A");
    this.bcService.isSuperUser();
    this.storageService.bcStorage.issuper = true;
  }

  successToken() {
    console.log("==== Ejecucion 6.B");
    const token = this.storageService.bcStorage.token;
    this.bcService.getSuccessToken();
    this.bcService.successToken$.subscribe(response => {
      if (response) {
        try {
          this.storageService.bcStorage.tokenBase64 = response.Datos.stokenValidatorResponse.pAdicional;
        } catch {
        }
        console.log(response.CodigoEstatus);
        console.log(response);
        const code = response.CodigoEstatus;
        let msj = '';
        switch (code) {
          case 1:
            if (this.storageService.bcStorage.tipoFlujoVerificacion == 3)//
              this.consultarPe68();
            if (this.storageService.bcStorage.tipoFlujoVerificacion == 4)
              this.ejecutaBat();
            if (this.storageService.bcStorage.tipoFlujoVerificacion == 5)//no cliente ine
              this.ejecutaBat();

            break;
          case 2:
            this.storageService.bcStorage.codigoflujo = response.CodigoError;
            msj = this.bcService.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones);
            this.dialogRef = this.dialogs.showDialogErrorMensaje(msj, 'Salir', response.CodigoError);
            this.dialogRef.afterClosed().subscribe(response => {
              this.responseDialogErrorMsg(response, msj);
            });
            break;
          case 3:
            this.storageService.bcStorage.codigoflujo = response.codigoError;
            this.dialogRef = this.dialogs.showDialogErrorMensaje(response.Mensaje, 'Salir', response.CodigoError);
            this.dialogRef.afterClosed().subscribe(response => {
              this.responseDialogErrorMsg(response, response.Mensaje);
            });
            break
          case 4:
            this.storageService.bcStorage.codigoflujo = response.codigoError;
            this.dialogRef = this.dialogs.showDialogErrorMensaje(response.Mensaje, 'Salir', response.CodigoError);
            this.dialogRef.afterClosed().subscribe(response => {
              console.log(response);
              this.responseDialogErrorMsg(response, response.Mensaje);
            });
            break
          default:
            this.storageService.bcStorage.codigoflujo = response.codigoError;
            msj = 'Ocurri\u00F3 un error en la validaci\u00F3n de token.'
            this.dialogRef = this.dialogs.showDialogErrorMensaje(response.Mensaje, 'Salir', response.CodigoError);
            this.dialogRef.afterClosed().subscribe(response => {
              console.log(response);
              this.responseDialogErrorMsg(response, msj);
            });
            break;
        }
      }
    });
  }

  errorToken() {
    this.resetStorageDataName();
    this.storageService.bcStorage.proceso = false;
    //bcstorage.codigoflujo = "ETO01";
    this.getFinalDate();
  }

  //#endregion

  //#region VALIDA LICENCIAS DISPOSITIVOS
  validarTipoLicencias() {
    this.bcService.getFingerLicences([this.guid]);
    this.bcService.getlicsuccess();
    this.bcService.licsuccess$.subscribe({
      next: (response: any) => {
        if (response) {
          this.validarLectores();
        } else {
          this.failProcesador();
        }
      }
    });
  }

  // validarLicencias() {

  // }
  //#endregion

  //#region VALIDA DISPOSITIVOS
  //revisar porque se quita
  validarLectores() {
    if (this.storageService.bcStorage.tipoFlujoVerificacion == 3)
      this.bcService.devicesConnectedVerify([this.guid]);
    else if (this.storageService.bcStorage.tipoFlujoVerificacion == 4)
      this.bcService.devicesConnectedVerify([this.guid]);
    this.bcService.getDevicesSuccess();
    this.bcService.devicesSuccess$.subscribe({
      next: (response: any) => {
        if (response == "") {
          if (this.isnotwhitelist == true) {
            this.verificarToken();
          }
        } else {
          this.failProcesador();
        }
      }
    });
  }

  //#endregion

  //#region CONSULTAS A 390
  consultarPe68() {
    console.log("==== Ejecucion 7");
    this.bcService.transactionID();
    this.bcService.pE68Consultar();
    this.bcService.getpE68GuardarRespuesta();
    this.bcService.pE68GuardarRespuesta$.subscribe(response => {
      if (response) {
        console.log(response + '==> Ingreso a 7 ============');
        this.guardarRespuestaPe68(response);

      }
    });
  }

  guardarRespuestaPe68(response: any) {
    var code = response.CodigoEstatus;
    var errorcustom = false;
    var codigoEstatusRespuesta = "";

    if ((response.Datos != null && response.Datos != undefined) && (response.Datos.status != null && response.Datos.status != undefined)) {
      codigoEstatusRespuesta = response.Datos.status.statusCode;
    } else {
      codigoEstatusRespuesta = response.Mensaje
    }
    let msg = '';
    switch (code) {
      case 1:
        if (response.Datos.status.statusCode == 0 && response.Datos.partyRec.partyInfo.personPartyInfo != null) {
          var cData = response.Datos.partyRec.partyInfo.personPartyInfo;
          this.storageService.bcStorage.apicNombre = cData.personName.givenName || '';
          this.storageService.bcStorage.apicApellidoP = cData.personName.paternalName || '';
          this.storageService.bcStorage.apicApellidoM = cData.personName.maternalName || '';
          this.storageService.bcStorage.nombreCliente = this.storageService.bcStorage.apicNombre + " " + this.storageService.bcStorage.apicApellidoP + " " + this.storageService.bcStorage.apicApellidoM;
          this.storageService.bcStorage.tipoCliente = this.storageService.bcStorage.nombreCliente;
          if (this.storageService.bcStorage.tipoFlujoVerificacion == 4) {//verificacion no cliente escritorio
            if (cData.birthDt) {
              if (cData.birthDt != null && cData.birthDt != "") {
                if (typeof cData.birthDt != undefined) {
                  var btDate = cData.birthDt.split("-");
                  this.storageService.bcStorage.apicDia = btDate[2];
                  this.storageService.bcStorage.apicMes = btDate[1];
                  this.storageService.bcStorage.apicAno = btDate[0];
                }
              }
            }
            var sexo = "";
            if (cData.gender.toUpperCase() == "MASCULINO")
              sexo = "H";
            else if (cData.gender.toUpperCase() == "MALE")
              sexo = "H";
            else
              sexo = "M";
            this.storageService.bcStorage.apicSexo = sexo;
          }
          this.setComponentVerify();
        } else if (response.Datos.status.statusCode == 100 || response.Datos.status.statusCode == 100) {
          msg = "Ocurrió un error en la consulta del cliente.";
          this.modalErrorGlobal(msg, 'Salir');
        } else {
          /*Si el estatus de la respuesta que devuelve la API es fallido,muestra mensaje y termina el flujo.*/
          msg = this.biocheckError.codigoError("EPE6801");
          this.modalErrorGlobal(msg, 'Salir');
        }
        // if (winPros) {
        //   winPros.close();
        // }
        break;
      case 2:
        this.storageService.bcStorage.codigoflujo = response.CodigoError;
        var flagbuc = false;
        $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
          if (value.indexOf("customer does not exist") != -1)
            flagbuc = true;
        });
        if (flagbuc) {
          msg = "";
          $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
            msg += this.key;
          });
          this.modalErrorGlobal(msg, 'Salir');
        } else
          this.modalErrorGlobal(msg, 'Salir');
        break;
      case 3:
        this.storageService.bcStorage.codigoflujo = "EPE6802";
        msg = this.biocheckError.codigoError(this.storageService.bcStorage.codigoflujo);
        this.modalErrorGlobal(msg, 'Salir');
        break;
      case 4:
        this.storageService.bcStorage.codigoflujo = "EPE6802";
        msg = this.biocheckError.codigoError(this.storageService.bcStorage.codigoflujo);
        this.modalErrorGlobal(msg, 'Salir');
        break;
      default:
        this.storageService.bcStorage.codigoflujo = "EPE6802";
        msg = this.biocheckError.codigoError(this.storageService.bcStorage.codigoflujo);
        this.modalErrorGlobal(msg, 'Salir');
        break;
    }
  }

  //#endregion


  //#region VALIDA ESCANER
  ejecutaBat() {
    console.log("verificando escaner");
    this.bcService.ejecutaBat();
    this.bcService.ejecutaBat$.subscribe(response => {
      if (response) {
        this.verificarEscanerDocumentos();
      }
    });
  }

  verificarEscanerDocumentos() {//Regreso: (9.A)biochkHub.client.respuestaProcesador. Regreso fallo: (9.B)biochkHub.client.fail
    this.controladorFunciones("VerificarEstatusEscanerDoc", {}); // para saltar la verificacion del  escaner se agrega el id ActivarModoManualEscaner
    this.respuestaProcesador();
    //    this.failProcesador();
  }

  controladorFunciones(id: string, parametrosEntrada: any) {
    const funcion = {
      Id: id,
      ParametrosEntrada: parametrosEntrada
    };
    this.bcService.procesador([funcion]);
    console.log(this.procesadorInvoked + ' Esto lleva la variable de procesador Invoked...')
    if (!this.procesadorInvoked) {
      this.procesadorInvoked = true;
    }
  }

  respuestaProcesador() {
    if (this.bcService.respuestaProcesador() != null) {
      this.bcService.respuestaProcesador$.subscribe(response => {
        if (response) {
          const id = response.Id;
          switch (response.Id) {
            case 'VerificarEstatusEscanerDoc':
              if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
                this.activarModoManualEscaner();
              }
              break;
            case 'VerificarEscanerConectadoOnline':
              if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
                this.activarModoManualEscaner();
              }
              break;
            case 'ActivarModoManualEscaner':
              if (this.storageService.bcStorage.tipoFlujoVerificacion == 4)
                this.consultarPe68();
              else if (this.storageService.bcStorage.tipoFlujoVerificacion == 5) //no cliente ine
                this.setComponentVerify();
              break;
            default:
              break;
          }
        } else {
          this.failProcesador();
        }
      });
    } else {
      this.failProcesador();
    }

  }

  activarModoManualEscaner() {
    this.controladorFunciones("ActivarModoManualEscaner", {});//Regreso: (11.A)biochkHub.client.respuestaProcesador. Regreso fallo: (11.B)biochkHub.client.fail
  }

  //#endregion

  //#region ACCIONES FINALIZA FLUJO
  onFinalizarFlujo() {
    this.storageService.bcStorage.fechapros = this.finalDate.fecha;
    this.storageService.bcStorage.horapros = this.finalDate.hora;
    this.storageService.bcStorage.foliopros = this.finalDate.trasaction;
    const codigoFlujo = this.storageService.bcStorage.codigoflujo;
    if (codigoFlujo) {
      if (Object.keys(Errors).includes(codigoFlujo)) { // valida si existe el cógo en los enum Errors
        this.storageService.bcStorage.mensajeflujo = Errors[this.storageService.bcStorage.codigoflujo as keyof typeof Errors]; //busca el valor del enum
      }
    }
    this.router.navigateByUrl('/finalizar');
    this.bcService.onStopSignalR();
  }

  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.getFinalDate();
  }

  getFinalDate() {
    console.log('finalizar dialog')
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        console.log(response)
        this.finalDate = response;
        this.onFinalizarFlujo();
      }
    });
  }

  //#endregion

  //#region  RETORNA ERROR
  modalErrorGlobal(msg: string, accion: string, codeError: number = 0) {
    if (accion == "Salir") {//salir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, accion);
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.getFinalDate();
        }
        ;
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    } else {//repetir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.errorFunction(codeError);
        } else {
          if (response != undefined) {
            this.cancelarinfo();
          }
        }
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    }
  }

  failProcesador() {
    console.log("==== Ejecucion 9.B, 11.B, 12B, 13.B, 14.B");
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      if (response) {
        console.log("code response: " + response.code);
        const code = parseInt(response.code);
        // this.codeClientFail = code;
        let msg = '';
        if (this.ejecutivo) {
          //código por averiguar que hace
        }
        if (code === 310) {
          //modalerror2
          msg = `<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>`;
          this.modalErrorGlobal(msg, 'Repetir', code);
        } else if (code === 320) {
          //modalerror
          msg = `<div class="dvPrincipalFinger"'><img class="logoAlertFinger" alt='Alerta' src='assets/img/advertencia.png'></div><div class="msgAlertFinger">Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div class="dcImglectorFinger"'><img class= "imgLectorFinger" alt='Instrucciones.png' src='assets/img/error/lector_conexion.png'></div>`;
          this.modalErrorGlobal(msg, 'Repetir', code);
        } else if (code >= 100 && code < 200) {
          //modalerror
          msg = `<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='assets/img/error/lector_conexion.png'></div>`;
          this.modalErrorGlobal(msg, 'Repetir', code);
        } else if (code === 330) {
          //modalerror
          msg = `<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='assets/img/error/escaner_conexion.png'></div>`;
          this.modalErrorGlobal(msg, 'Repetir', code);
        } else if (code === 331) {
          //modalerror
          msg = `Servicio de escaneo de documentos no pudo ser iniciado.`;
          this.modalErrorGlobal(msg, 'Salir', code);
        } else {
          if (this.ejecutivo) {
          } else if (code === 270) {
            msg = `Mala calidad en huella.`;
            this.modalErrorGlobal(msg, 'Salir', code);
          } else if (code === 300) {
            msg = `<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='assets/img/error/lector_conexion.png'></div>`;
            this.modalErrorGlobal(msg, 'Repetir');
          } else if (code === 350) {
            this.modalErrorGlobal(response.message, 'Salir', code);
          }
        }
      }
    });
  }

  errorFunction(codeError: number = 0) {
    console.log('código de falla => ', this.codeClientFail);
    var timeInterval = 1000;
    //timeInterval = (this.storageService.bcStorage.tipoFlujoVerificacion === 4 ? 1500 : 1000);
    if (this.storageService.bcStorage.tipoFlujoVerificacion == 3 || this.storageService.bcStorage.tipoFlujoVerificacion == 4) {
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaHuellas, 15);

      dialogRef.afterClosed().subscribe(response => {
        if (codeError == 320 || codeError == 333) {
          this.validarLectores()
        } else if (codeError == 330) {
          this.ejecutaBat();
        } else {
        }

      });
    } else if (this.storageService.bcStorage.tipoFlujoVerificacion == (10)) {
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaRostro);
      dialogRef.afterClosed().subscribe(response => {
        //       biochkHub.server.getFaceLicences(guid);
      });

    }
    this.cont = 0;
  }

  errorConfig() {
    this.resetStorageDataName();
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.codigoflujo = "CS001";
    this.getFinalDate();
  }

  failConfig() {
    console.log("==== Ejecucion 4.B");
    const mensaje = 'Ocurri\u00F3 un error en la consulta de configuración';
    this.modalErrorGlobal(mensaje, 'Salir');
  }

  responseDialogErrorMsg(response: boolean, message: string) {
      this.errorToken()

    try {
      const params = ["warning", "PaaS [" + window.location.href + "]", message];
      this.bcService.invokeEscribeLog(params);
    } catch (tryError) {
      // ignored
    }
  }

  //#endregion
}
