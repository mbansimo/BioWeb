import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VentanillaComponent } from "../website/ventanilla/ventanilla.component";
import { CancelarComponent } from "./components/cancelar/cancelar.component";


@NgModule({
  declarations: [
    VentanillaComponent,
    CancelarComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    VentanillaComponent,
    CancelarComponent
  ]
})
export class CoreModule { }
