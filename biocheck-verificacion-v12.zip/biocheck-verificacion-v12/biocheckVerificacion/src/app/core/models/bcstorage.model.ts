import { datosObtenidos } from "./formatoCaptura.model";

export interface BcStorageModel {

  hubUrl: string;
  inicioServicio: string;
  signalrReady?: boolean;
  signalrStopped?: boolean;
  versionSistema?: string;
  versionBiocheck?: string;
  proceso?: boolean;
  cancel?: boolean;
  apicNombre?: string;
  apicApellidoP?: string | null;
  apicApellidoM?: string | null;
  esINE?: boolean;
  codigoflujo?: string | undefined | null;
  codigoImagenFlujo?: string | undefined | null;
  mensajeflujo?: string;
  indice?: string;
  esEjecutivo?: boolean;
  issuper?: boolean;
  procesandoAbrierto?: boolean;
  hash?: any;
  fechapros?: string;
  horapros?: string;
  foliopros?: string;
  token?: string;
  ejecutivoname?: any;
  datosCanal?: any;
  OmitirVigenciaIne?: boolean;
  EstadosVigenciaIne?: string;
  FechaVigenciaProrroga?: string;
  tipoToken?: string;
  numeroDeIntentosHuella?: number;
  dedoInicial?: string;
  tituloInstruccion?: string;
  dedoEnviar?: number;
  nombreCliente?: string;
  repetirProceso?: string;
  documento?: string;
  tipoCliente?: string;
  tipoFlujoVerificacion?: number;
  tipoIdentificacion?: string;

  curp?: string | undefined;
  ocr?: string;
  claveElector?: string;
  personalNumber?: string;
  procesandoAbierto?: boolean;
  mensajeinternoflujo?: string;
  anioEmision?: string;
  anioRegistro?: string;

  modalServicio?: string;
  codigoEmision?: string;
  fingerCapture?: number;
  tokenBase64?: string;

  ineRespuesta?: boolean;

  apicDia?: string;
  apicMes?: string;
  apicAno?: string;
  apicSexo?: string;

  //tiempos en dialogoProcesandoComponet
  tiempoMaximo?: boolean;

  //Tipo de Flujo
  tipoVerificacion?: string;    //Verificacion Full = full, verificacion simple= simple

  //variables para verificacion Full
  dedosAvtivos?: any[];
  dedosaux?: any[];

  //Modal solictud de huella
  instruccionText?: string;
  combinaciones?: string;
  intentosRestantes?: string;
  EsEscanerUnidactilar?: boolean;
  terminoFlujoRostro?: string;

  //Modal de capturaDeRostro
  reintentarFaceCaptureCheck?: boolean;
  continuarFaceCaptureCheck?: boolean;

  //Variables para verificacion Simple
  ciclo?: boolean;


  //Variables de documentacion INE
  autorizacionEjecutivoFM?: boolean;
  versionInstalador?: string;
  bucAnonimizada?: string;
  documentScan?: number;
  esIne?: boolean;
  imgFrontBase64?: any;
  imgBackBase64?: any;
  nombre?: string;
  apellidos?: string;
  apellidoP?: string | undefined;
  apellidoM?: string | undefined;
  nombrePasaporte?: string;
  apellidosPasaporte?: string | undefined;
  isCIC?: boolean;
  imagenFrente?: any;
  imagenAtras?: any;
  cic?: any;
  dia?: string;
  mes?: string;
  ano?: string;
  entidadNacimiento: string;
  type?: string;
  mrz?: string;
  sexo?: 'H' | 'M' | undefined;
  existenciaVigencia?: boolean;
  nacionalidad?: string;
  CP?: string;
  Colonia?: string;
  EDO?: string;
  Calle?: string;
  DelMun?: string;
  Observacion?: string;
  EstatusListaNegra?: string;
  folioNumber?: string | number;
  vigencia?: any;
  direccionCalle?: any;
  direccionColonia?: string;
  direccionMunicipio?: string;
  fehaNacimiento?: string;
  nacionalidadCode?: string | number;
  nacName?: string;
  emision?: string;
  numDocument?: string | number;
  nue?: string | number;
  pasaporteFrente?: string;
  pasaporteAtras?: string;
  expedicion?: string;
  DocumentSeries?: string;
  fehaNacimientoPasaporte?: string;
  numeroPasaporte?: string | number;
  ClaveEntidad?: any;
  esPasaporte?: boolean;
  EsFM?: boolean;
  dataJson?: any;
  ProcesoScan?: boolean;
  EsPermanente?: boolean;
  YaEscaneoPasaporte?: boolean;
  respuestaNC?: datosObtenidos;
  repetirCapturaDatosIne?: boolean;
  yaEscaneoIne?: boolean;
  AnioRegistro?: string;
  AnioEmision?: string;


  // CapturaRostroIne
  nombreProceso?: string;

  identificaionINE?: string;

  //OCRINEFACIAL
  renapoRespuesta?: boolean;
  nombreEditado?: string;
  apellidoPaternoEditado?: string | null;
  apellidoMaternoEditado?: string | null;
  apicApellidoPEditado?: string;
  apicApellidoMEditado?: string;
  apicNombreEditado?: string;
  //apellido?: string | null;
  apicNac?: any;


};

