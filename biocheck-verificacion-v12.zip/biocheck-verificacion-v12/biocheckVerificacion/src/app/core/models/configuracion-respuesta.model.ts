export interface ConfiguracionRespuestaModel {
  EstadosVigenciaIne: string;
  FechaVigenciaProrroga: string;
  ModulosEnrolamientoOpcionales: {
    BuroCredito:            boolean;
    ConfirmacionEjecutivo:  boolean;
    DatosContacto:          boolean;
    DatosPld:               boolean;
  }
  OmitirVigenciaIne:  boolean;
  VersionSistema:     string;
  VersionYml:         string;
}
