export class DataEditableModel {

  public genero: string | null | undefined = "";
  public entnac: string | null | undefined = "";
  public curp: string | null | undefined = "";
  public ocr: string | null | undefined = "";
  public vigencia: string | null | undefined = "";
  public nombrefront: string | null | undefined = "";
  public appatfront: string | null | undefined = "";
  public apmatfront: string | null | undefined = "";
  public claveElector: string | null | undefined = "";
  public codigoEmision: string | null | undefined = "";
  public cic: string | null | undefined = "";
  public fechaNacimiento: string | null | undefined = "";
  public aniodeEmision: string | null | undefined = "";
  public aniodeRegistro: string | null | undefined = "";


  constructor() {
    this.genero = "";
    this.curp = "";

  }
}
