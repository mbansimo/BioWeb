export interface EstadosRenapoModel {
  value: string;
  nombre: string;
}
export interface GenericModel {
  value: string;
  nombre: string;
}

export interface nacionalidadesSinSegundoApellido {
  value: string
}


