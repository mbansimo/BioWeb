export interface FinalDateModel {
  hora:       string;
  fecha:      string;
  trasaction: string;
}
