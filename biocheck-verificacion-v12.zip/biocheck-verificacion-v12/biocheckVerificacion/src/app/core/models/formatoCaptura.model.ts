export interface FormatoCapturaModel {
  colorMarco: string;
  imagen: string;
  intentosRestantes: number;
}

export interface ModalReloj {
  mensaje: string;
}

export interface ModalError {
  mensaje: string;
  boton: string;
  action: string;
}

export interface modalErrorDispositivo {
  boton: string;
  action: string;
}

export interface intentosHuellaCliente {
  intentos: any;
  EsEscanerUnidactilar: any;
}

export interface datosObtenidos {
  nombre: string;
  apellidoPaterno: string;
  apellidoMaterno: string;
  fechaDeNacimiento: string;
  genero: 'H' | 'M' | undefined;
  curp: string;
}

