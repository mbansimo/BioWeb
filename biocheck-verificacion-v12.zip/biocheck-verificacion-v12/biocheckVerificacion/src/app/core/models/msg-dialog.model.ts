export interface MsgDialogModel {
  title:    string;
  messages: MsgSlideModel[];
}

export interface MsgSlideModel {
  text?: string;
  src?:  string;
  alt?:  string;
}

export interface DataDialogModel {
  title?: string;
  message?: string;
  labelButton?: string;
  isError?: boolean;
  isConfirm?: boolean;
  isExit?: boolean;
  isScan?: boolean;
}

export interface DataDialogSolicitudHuella {
  imagen?: string;
  title?: string;
  numeroIntentos?: number;

}

export interface DataFaceCaptureCheck {
  imagen?: any;
  title?: string;
  labelButton?: string;
  modal?: string;
}
