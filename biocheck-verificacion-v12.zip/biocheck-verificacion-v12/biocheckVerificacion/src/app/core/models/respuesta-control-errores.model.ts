export interface RespuestaControlErroresModel {
  mensajeError:         string;
  mensajeErrorLegible:  string;
  msjBoton:             string;
}
