import { Injectable } from '@angular/core';
import { BcStorageModel } from "../models/bcstorage.model";
import { environment } from "../../../environments/environment";
import { of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class BcstorageService {

  bcStorage: BcStorageModel = {
    hubUrl: environment.hubUrl,
    inicioServicio: '',
    entidadNacimiento: '',
    renapoRespuesta: false,
    indice: '',
  }

  constructor() { }

  getBcStorage() {
    return this.bcStorage;
  }

}
