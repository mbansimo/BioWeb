import { TestBed } from '@angular/core/testing';

import { BiocheckCadenasService } from './biocheck-cadenas.service';

describe('BiocheckCadenasService', () => {
  let service: BiocheckCadenasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiocheckCadenasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
