import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BiocheckCadenas {
  private valor = "";
  constructor() { }



  limpiarEntidadNacimiento(esNacional: boolean, entidadNacimiento: string) {
    if (esNacional === false)
      entidadNacimiento = "NE";
    else if (typeof (entidadNacimiento) === "undefined") {
      entidadNacimiento = "OO";
    } else if (entidadNacimiento.length !== 2) {
      entidadNacimiento = "OO"
    } else {
      entidadNacimiento = entidadNacimiento.replace(/0/g, "O").replace(/1/g, "I").replace(/5/g, "S").replace(/0/g, "O").replace(/8/g, "B");
      entidadNacimiento = entidadNacimiento.toUpperCase();
    }
    return entidadNacimiento;
  }

  limpiarCurp(curp: string) {

    var cadena
    if (curp)
      cadena = curp.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    else
      cadena = '';

    return cadena;
  }

  limpiarVigencia(completa: string) {
    if (!completa)
      return '';

    var array = completa.split("-");
    return array[array.length - 1];
  }

  validacionClaveElector(claveElector: string) {
    if (claveElector == undefined || claveElector == null)
      return '';
    claveElector = claveElector.toUpperCase();
    if (claveElector.length == 18) {
      claveElector.toUpperCase();
      var clave1 = claveElector.substr(0, 6).replace(/[1]/gi, 'I').replace(/[0]/gi, 'O').replace(/[5]/gi, 'S').replace(/[8]/gi, 'B');
      var clave2 = claveElector.substr(6, 8).replace(/[O]/gi, '0').replace(/[S]/gi, '5').replace(/[B]/gi, '8').replace(/[I]/gi, '1');
      var clave3 = claveElector.substr(14, 1).replace(/[0]/gi, 'O').replace(/[5]/gi, 'S').replace(/[8]/gi, 'B');
      var clave4 = claveElector.substr(15, 3).replace(/[O]/gi, '0').replace(/[S]/gi, '5').replace(/[B]/gi, '8').replace(/[I]/gi, '1');
      var nuevaClave = clave1.concat(clave2).concat(clave3).concat(clave4);
      claveElector = nuevaClave;
    }
    return claveElector;
  };

  curpRemplazo(curp: string) {
    if (curp.length == 18) {
      var nombres = curp.substr(0, 4);
      var fechaNacimiento = curp.substr(4, 6);
      var sexo = curp.substr(10, 1);
      var entidad = curp.substr(11, 2);
      var consonantes = curp.substr(13, 3);
      var diferenciadorVerificador = curp.substr(16, 2);

      var nuevoNombres = this.numerosPorLetras(nombres); // Validar que todos sean letras
      var nuevoFechaNacimiento = this.letrasPorNumeros(fechaNacimiento); // Validar que todos sean número
      var nuevoSexo = this.numerosPorLetras(sexo); // Validar que sea letra
      var nuevoEntidad = this.numerosPorLetras(entidad); // Validar que sean letras
      var nuevoConsonantes = this.numerosPorLetras(consonantes); // Validar que sean letras
      var nuevoDiferenciadorVerificador = diferenciadorVerificador; // NO VALIDAR

      var curpRegreso = nuevoNombres.concat(nuevoFechaNacimiento).concat(nuevoSexo).concat(nuevoEntidad).concat(nuevoConsonantes).concat(nuevoDiferenciadorVerificador);
      return curpRegreso;
    } else {
      return curp;
    }
  }

  numerosPorLetras(texto: string) {
    var textoReemplazado = texto.replace(/1/g, "I").replace(/5/g, "S").replace(/8/g, "B").replace(/4/g, "A").replace(/0/g, "O").replace(/7/g, "T");
    return textoReemplazado;
  }

  letrasPorNumeros(texto: string) {
    var textoReemplazado = texto.replace(/I/ig, "1").replace(/l/ig, "1").replace(/S/ig, "5").replace(/B/g, "8").replace(/A/g, "4").replace(/O/ig, "0").replace(/T/ig, "7");
    return textoReemplazado;
  }

  normalizarCandena(cadenaAcentos: any) {
    var cadenaAcentos = cadenaAcentos.split('');
    var cadenaAcentosOut = new Array();

    var acentos = "ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÌÍÎÏìíîïÙÚÛÜùúûü";
    var sinAcentos = "AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeIIIIiiiiUUUUuuuu";
    for (var y = 0; y < cadenaAcentos.length; y++) {
      if (acentos.indexOf(cadenaAcentos[y]) != -1) {
        cadenaAcentosOut[y] = sinAcentos.substr(acentos.indexOf(cadenaAcentos[y]), 1);
      } else {
        cadenaAcentosOut[y] = cadenaAcentos[y];
      }
    }
    //  cadenaAcentosOut = cadenaAcentosOut.join('');

    var cadenaNormalizada = "";

    for (var i = 0; i < cadenaAcentosOut.length; i++) {
      if (cadenaAcentosOut[i] != "." && cadenaAcentosOut[i] != "-" && cadenaAcentosOut[i] != "'") {
        cadenaNormalizada += cadenaAcentosOut[i];
      }
    }

    return cadenaNormalizada;
  }


}
