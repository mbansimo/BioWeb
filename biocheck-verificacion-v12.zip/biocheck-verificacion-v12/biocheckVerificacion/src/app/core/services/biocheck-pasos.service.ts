import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BiocheckPasosService {

  private valor = "";
  constructor() { }

  public totalPasos(pasos: number) {
    for (var i = 1; i <= pasos; i++) {
      this.valor += ("<li id='paso" + i + "' style='float: left;margin-left: 19px; list-style: none;' >" + i + "</li>");
    }
    return this.valor;
  }

  public cambiarPaso(paso: number, nombre: string) {


    $('#paso' + paso).css('text-decoration', 'underline');
    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }
}
