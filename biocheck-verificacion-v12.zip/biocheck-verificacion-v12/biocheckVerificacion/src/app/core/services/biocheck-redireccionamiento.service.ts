import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BiocheckRedireccionamientoService {


  //1 enrolamiento
  //2 sin ine
  //3 extranjero
  //4 lesion fisica
  //5 no desea
  //6 kiosko (nacional)
  //7 kiosko (extranjero)
  public pasoActual: number = 3;
  public smslocal: number = 0;
  public codigosms: number = 0;
  public correoelectronico: string = '';

  constructor() { }

  public sms(sm: number) {
    this.smslocal = sm;
  }

  public setCodigosms(codigo: number) {
    this.codigosms = codigo;
  }

  public getCodigosms() {
    return this.codigosms;
  }

  public setCorreoElectronico(ce: string) {
    this.correoelectronico = ce;
  }

  public getCorreoElectronico() {
    return this.correoelectronico;
  }

  public nuevopaso(paso: number) {
    this.pasoActual = paso;
  }

  public getPaso() {
    return this.pasoActual;
  }

  public setPaso(paso: number) {
    this.pasoActual = paso;
  }

  public siguiente(ruta: number) {
    let path = '';
    console.log('Ingreso a metodo siguiente ........')
    switch (this.pasoActual) {
      case 1:
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'ausenciaycaptura';
        } else if (ruta == 8) {
          path = 'caprutaderostro';
        } else if (ruta == 9) {
          path = 'escanearife';
        } else if (ruta == 3) {
          path = 'ocrdeife';
        } else if (ruta == 4) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'burodecredito';
        } else if (ruta == 6) {
          path = 'burodecredito';
        } else if (ruta == 7) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = '/';
        }
        break;
      case 2: //sin ine
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'escanearpasaporte';
        } else if (ruta == 11) {
          path = 'otraidentificacion';
        } else if (ruta == 14) {
          path = 'ocrdepasaporte';
        } else if (ruta == 13) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'finalizar';
        } else if (ruta == 6) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = '/';
        }
        break;
      case 3: //extranjero
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'escanearpasaporte';
        } else if (ruta == 11) {
          path = 'escanearformamigratoria';
        } else if (ruta == 12) {
          path = 'ocrdepasaporte';
        } else if (ruta == 13) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'finalizar';
        } else if (ruta == 6) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = '/';
        }
        break;
      case 4: //lesion fisica
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'escanearife';
        } else if (ruta == 3) {
          path = 'ocrdeife';
        } else if (ruta == 4) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'burodecredito';
        } else if (ruta == 6) {
          path = 'burodecredito';
        } else if (ruta == 7) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = '/';
        }
        break;
      case 5: //no desea enrolarse
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'escanearife';
        } else if (ruta == 3) {
          path = 'ocrdeife';
        } else if (ruta == 4) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'burodecredito';
        } else if (ruta == 6) {
          path = 'burodecredito';
        } else if (ruta == 7) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = '/';
        }
        break;
      case 6: //kiosko (nacional)
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'ausenciaycaptura';
        } else if (ruta == 8) {
          path = 'caprutaderostro';
        } else if (ruta == 9) {
          path = 'escanearife';
        } else if (ruta == 3) {
          path = 'ocrdeife';
        } else if (ruta == 4) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'burodecredito';
        } else if (ruta == 6) {
          path = 'burodecredito';
        } else if (ruta == 7) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = '/kiosko';
        }
        break;

      case 7: //kiosko (extranjero)
        if (ruta == 1) {
          path = 'avisodeprivacidad';
        } else if (ruta == 2) {
          path = 'ausenciaycaptura';
        } else if (ruta == 8) {
          path = 'caprutaderostro';
        } else if (ruta == 9) {
          path = 'escanearformamigratoria';
        } else if (ruta == 3) {
          path = 'ocrformamigratoria';
        } else if (ruta == 4) {
          path = 'datosdecontacto';
        } else if (ruta == 5 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 5 && this.smslocal == 0) {
          path = 'burodecredito';
        } else if (ruta == 6) {
          path = 'burodecredito';
        } else if (ruta == 7) {
          path = 'finalizar';
        } else if (ruta == 10) {
          path = 'kiosko';
        }
        break;
      case 8: //Escaner
        if (ruta == 1) {
          path = 'escanearpasaporte';
        } else if (ruta == 2) {
          path = 'escanearife';
        } else if (ruta == 3) {
          path = 'finalizar';
        } else if (ruta == 4) {
          path = 'escanearformamigratoria';
        } else if (ruta == 5) {
          path = 'escanerdocs';
        } else if (ruta == 10) {
          path = '/';
        }
        break;
      default:
      //alert("flujo no existe");
    }
    return path;
  }

  public atras(ruta: number, biofun: any) {
    let path = '';
    if (biofun)
      biofun();
    switch (this.pasoActual) {
      case 1: //enrolamiento
        if (ruta == 2) {
          path = '/';
        } else if (ruta == 8) {
          path = 'avisodeprivacidad';
        } else if (ruta == 9) {
          path = 'ausenciaycaptura';
        } else if (ruta == 3) {
          path = 'caprutaderostro';
        } else if (ruta == 4) {
          path = 'escanearife';
        } else if (ruta == 5) {
          path = 'ocrdeife';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 0) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 10) {
          path = 'burodecredito';
        }
        break;
      case 2: //sin ine
        if (ruta == 2) {
          path = '/';
        } else if (ruta == 11) {
          //path = 'avisodeprivacidad';
          path = '/';
        } else if (ruta == 14) {
          path = 'escanearpasaporte';
        } else if (ruta == 13) {
          path = 'otraidentificacion';
        } else if (ruta == 5) {
          path = 'ocrdepasaporte';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 10) {
          path = 'confirmarsms';
        }
        break;
      case 3: //extranjero
        if (ruta == 2) {
          path = '/';
        } else if (ruta == 11) {
          //path = 'avisodeprivacidad';
          path = '/';
        } else if (ruta == 12) {
          path = 'escanearpasaporte';
        } else if (ruta == 13) {
          path = 'escanearformamigratoria';
        } else if (ruta == 5) {
          path = 'ocrdepasaporte';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 8) {
          path = 'avisodeprivacidad';
        }
        break;
      case 4: //lesion fisica
        if (ruta == 2) {
          path = '/';
        } else if (ruta == 3) {
          //path = 'avisodeprivacidad';
          path = '/';
        } else if (ruta == 4) {
          path = 'escanearife';
        } else if (ruta == 5) {
          path = 'ocrdeife';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 7 && this.smslocal == 0) {
          path = 'datosdecontacto';
        }
        break;
      case 5: //no desea enrolarse
        if (ruta == 2) {
          path = '/';
        } else if (ruta == 3) {
          //path = 'avisodeprivacidad';
          path = '/';
        } else if (ruta == 4) {
          path = 'escanearife';
        } else if (ruta == 5) {
          path = 'ocrdeife';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 7 && this.smslocal == 0) {
          path = 'datosdecontacto';
        }
        break;
      case 6: //kiosko (nacional)
        if (ruta == 2) {
          path = '/kiosko';
        } else if (ruta == 8) {
          path = 'avisodeprivacidad';
        } else if (ruta == 9) {
          path = 'ausenciaycaptura';
        } else if (ruta == 3) {
          path = 'caprutaderostro';
        } else if (ruta == 4) {
          path = 'escanearife';
        } else if (ruta == 5) {
          path = 'ocrdeife';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 0) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 10) {
          path = 'burodecredito';
        }
        break;
      case 7: //kiosko (extranjero)
        if (ruta == 2) {
          path = '/kiosko';
        } else if (ruta == 8) {
          path = 'avisodeprivacidad';
        } else if (ruta == 9) {
          path = 'ausenciaycaptura';
        } else if (ruta == 3) {
          path = 'caprutaderostro';
        } else if (ruta == 4) {
          path = 'escanearformamigratoria';
        } else if (ruta == 5) {
          path = 'ocrformamigratoria';
        } else if (ruta == 6) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 0) {
          path = 'datosdecontacto';
        } else if (ruta == 7 && this.smslocal == 1) {
          path = 'confirmarsms';
        } else if (ruta == 10) {
          path = 'burodecredito';
        }
        break;
      default:
      //alert("flujo no existe");
    }
    return path;
  }

}
