import { TestBed } from '@angular/core/testing';

import { BiocheckUtilsService } from './biocheck-utils.service';

describe('BiocheckUtilsService', () => {
  let service: BiocheckUtilsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiocheckUtilsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
