import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialogRef } from "@angular/material/dialog";
import { DialogGeneralComponent } from "../../shared/dialogs/dialog-general/dialog-general.component";
import { BcstorageService } from "./bcstorage.service";
import { Router } from "@angular/router";
import { UtilDialogs } from "../../common/util-dialogs";
import { BiocheckErrorService } from "./biocheck.error.service";
import { BiocheckService } from "./biocheck.service";
import { DataEditableModel } from "../models/dataTable.model";
import * as $ from "jquery";

@Injectable({
  providedIn: 'root'
})
export class BiocheckUtils {
  //#region "Variables"
  //#endregion

  public dialogRef: MatDialogRef<DialogGeneralComponent, any> | undefined;
  private valor: string = "";

  constructor(
    private readonly http: HttpClient,
    private storageService: BcstorageService,
    private readonly router: Router,
    private bcService: BiocheckService,
    private dialogs: UtilDialogs,
    private Error: BiocheckErrorService,
  ) {
  }

  errorVigencia() {
    var mensaje = `
        Indica al cliente que la identificación no está vigente
             que es importante que actualice su identificación
             para realizar cualquier trámite con el banco.`;
    return mensaje;
  }

  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.getfinalDate();
    this.bcService.finalDate$.subscribe((response: any) => {
      if (response) {
        this.finalDate(response);
      }
    });
  }

  finalDate(response: any) {
    this.storageService.bcStorage.fechapros = response.fecha;
    this.storageService.bcStorage.horapros = response.hora;
    this.storageService.bcStorage.foliopros = response.trasaction;
    var valorError = this.storageService.bcStorage.codigoflujo == undefined ? "" : this.storageService.bcStorage.codigoflujo;
    var codigoError = this.Error.codigoError(valorError)
    if (codigoError != '0' && (this.storageService.bcStorage.mensajeflujo === "" || this.storageService.bcStorage.mensajeflujo === undefined))
      this.storageService.bcStorage.mensajeflujo = codigoError;
    this.bcService.onStopSignalR();
    this.router.navigateByUrl('/finalizar');

    // this.storageService.bcStorage.fechapros = data.fecha;
    // this.storageService.bcStorage.horapros = data.hora;
    // this.storageService.bcStorage.foliopros = data.trasaction;
    // this.bcService.onStopSignalR();
    // this.router.navigateByUrl('/finalizar');
  }

  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.getFinalDate();
  }


  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "PaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  cancelar() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCancelar();
    this.dialogRef.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  public totalPasos(pasos: number) {
    this.valor = "";
    for (var i = 1; i <= pasos; i++) {
      this.valor += ("<li id='paso" + i + "'>" + i + "</li>");
    }
    $('#listaPasos').append(this.valor);
  }

  public cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  DataEditable(sexo: string | null, entnac: string | undefined | null, curp: string | undefined, ocr: string | undefined, vigencia: string | null, nombrefront: string | undefined, appatfront: string | null | undefined, apmatfront: string | null | undefined, claveElector: string | undefined, codigoEmision: string | undefined, cic: string | undefined) {
    let dta: DataEditableModel = new DataEditableModel();

    dta.genero = sexo;
    dta.entnac = entnac;
    dta.curp = curp == '' ? null : curp;
    dta.ocr = ocr == '' ? null : ocr;
    dta.vigencia = vigencia;
    dta.nombrefront = nombrefront == '' ? null : nombrefront;
    dta.appatfront = appatfront == '' ? null : appatfront;
    dta.apmatfront = apmatfront == '' ? null : apmatfront;
    dta.claveElector = claveElector == '' ? null : claveElector;
    dta.codigoEmision = codigoEmision == '' ? null : codigoEmision;
    dta.cic = (cic == '' ? null : cic);
    // dta.aniodeRegistro = anioRegistro == '' ? null : anioRegistro;
    // dta.aniodeEmision = anioEmision == '' ? null : anioEmision

    return dta;
  }

  validaOmitirVigencia(esVigente: string) {
    debugger;
    var OmitirVigencia = false;
    if (esVigente == "NO_VIGENTE") {
      var anioVigencia = parseInt((this.storageService.bcStorage.vigencia) ? this.storageService.bcStorage.vigencia : 0);
      const listEstadosVigencia = this.storageService.bcStorage.EstadosVigenciaIne !== undefined ? this.storageService.bcStorage.EstadosVigenciaIne.split(',') : "";
      const ExisteEstado = listEstadosVigencia !== "" ? listEstadosVigencia.find(value => value == this.storageService.bcStorage.ClaveEntidad) : false;
      var FechaAplicaVigencia = this.storageService.bcStorage.FechaVigenciaProrroga !== undefined ? (this.storageService.bcStorage.FechaVigenciaProrroga !== "" ? new Date(this.storageService.bcStorage.FechaVigenciaProrroga) : new Date("01/01/1990")) : new Date("01/01/1990")
      var fechaDeHoy = new Date();
      var anio = fechaDeHoy.getFullYear(); //año valido vigente
      var FechaTerminoProrroga = true;

      if (FechaAplicaVigencia < fechaDeHoy)
        FechaTerminoProrroga = false

      if (!ExisteEstado)
        OmitirVigencia = this.storageService.bcStorage.OmitirVigenciaIne === true && FechaTerminoProrroga && ExisteEstado != undefined;
      else
        OmitirVigencia = this.storageService.bcStorage.OmitirVigenciaIne === true && FechaTerminoProrroga;
    }
    return OmitirVigencia;
  }
}
