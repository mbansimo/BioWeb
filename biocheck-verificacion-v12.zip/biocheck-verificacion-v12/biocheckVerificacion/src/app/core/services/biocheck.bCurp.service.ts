import {Injectable} from '@angular/core';
import {GenericModel} from '../models/estados-renapo.model';

@Injectable({
  providedIn: 'root'
})
export class BiocheckCurp {
  private valor = "";

  constructor() {
  }

  public caracteresEspecialesRgx = /(?:[^A-Z]|[Ñ])/;
  public primerVocalInternaRgx = /^.(?:[B-DF-HJ-NP-TV-ZÑ]*)([^B-DF-HJ-NP-TV-ZÑ]{1}).*$/;
  public ultimaConsonanteRgx = /([B-DF-HJ-NP-TV-ZÑ]{1})(?:[^B-DF-HJ-NP-TV-ZÑ]*)$/;
  public primerConsonanteInternaRgx = /^.(?:[^B-DF-HJ-NP-TV-ZÑ]*)([B-DF-HJ-NP-TV-ZÑ]{1})/;

  bccurp() {

    const primerVocalInternaRgx = /^.(?:[B-DF-HJ-NP-TV-ZÑ]*)([^B-DF-HJ-NP-TV-ZÑ]{1}).*$/;
    const ultimaConsonanteRgx = /([B-DF-HJ-NP-TV-ZÑ]{1})(?:[^B-DF-HJ-NP-TV-ZÑ]*)$/;
    const primerConsonanteInternaRgx = /^.(?:[^B-DF-HJ-NP-TV-ZÑ]*)([B-DF-HJ-NP-TV-ZÑ]{1})/;
    const caracteresEspecialesRgx = /(?:[^A-Z]|[Ñ])/;

  }


  pad(str: string) {

    str += '';
    if (str.length == 1) {
      str = '0' + str;
    }
    return str;
  };

//  bccurp = {};

  nombreEstado(idEstado: string) {
    var clavesEstadosInv: GenericModel[] = [
      {'value': 'OO', 'nombre': '---- Selecciona Estado ----'},
      {'value': 'AS', 'nombre': 'Aguascalientes'},
      {'value': 'MS', 'nombre': 'Morelos'},
      {'value': 'BC', 'nombre': 'Baja California'},
      {'value': 'NT', 'nombre': 'Nayarit'},
      {'value': 'BS', 'nombre': 'Baja California Sur'},
      {'value': 'NL', 'nombre': 'Nuevo León'},
      {'value': 'CC', 'nombre': 'Campeche'},
      {'value': 'OC', 'nombre': 'Oaxaca'},
      {'value': 'CL', 'nombre': 'Coahuila'},
      {'value': 'PL', 'nombre': 'Puebla'},
      {'value': 'CM', 'nombre': 'Colima'},
      {'value': 'QT', 'nombre': 'Querétaro'},
      {'value': 'CS', 'nombre': 'Chiapas'},
      {'value': 'QR', 'nombre': 'Quintana Roo'},
      {'value': 'CH', 'nombre': 'Chihuahua'},
      {'value': 'SP', 'nombre': 'San Luis Potosí'},
      {'value': 'DF', 'nombre': 'Ciudad de México'},
      {'value': 'SL', 'nombre': 'Sinaloa'},
      {'value': 'DG', 'nombre': 'Durango'},
      {'value': 'SR', 'nombre': 'Sonora'},
      {'value': 'GT', 'nombre': 'Guanajuato'},
      {'value': 'TC', 'nombre': 'Tabasco'},
      {'value': 'GR', 'nombre': 'Guerrero'},
      {'value': 'TS', 'nombre': 'Tamaulipas'},
      {'value': 'HG', 'nombre': 'Hidalgo'},
      {'value': 'TL', 'nombre': 'Tlaxcala'},
      {'value': 'JC', 'nombre': 'Jalisco'},
      {'value': 'VZ', 'nombre': 'Veracruz'},
      {'value': 'MC', 'nombre': 'Estado de México'},
      {'value': 'YN', 'nombre': 'Yucatán'},
      {'value': 'MN', 'nombre': 'Michoacán'},
      {'value': 'ZS', 'nombre': 'Zacatecas'},
      {'value': 'NE', 'nombre': 'Nacido en el extranjero'}
    ];

    return clavesEstadosInv.find(f => f.value == idEstado)?.nombre;
  }

  generar(nombre: string, primerApellido: string, segundoApellido: string, ano: string, mes: string, dia: string, sexo: string, entidad: string | undefined) {
    /*
    En este if nos exige que todos los datos no esten vacios, pero pueden aver nombres sin apellido materno
    if (!(nombre && primerApellido && segundoApellido && ano && mes && dia && sexo && entidad)) {
        return '';
    }
    */
    var curp = '';

    nombre = this.limpiar(nombre);
    primerApellido = this.limpiar(primerApellido);
    segundoApellido = this.limpiar(segundoApellido);
    sexo = sexo.toUpperCase();
    if (entidad)
      entidad = entidad.toUpperCase();

    //Letra inicial del primer apellido
    curp += this.reemplazarCaracteres(this.letraInicial(primerApellido));
    //Primera vocal interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerVocalInternaRgx, 'X'));
    //Letra inicial del segundo apellido
    curp += this.reemplazarCaracteres(this.letraInicial(segundoApellido));
    //Primera letra del nombre
    curp += this.reemplazarCaracteres(this.letraInicial(nombre));
    //evalúa palabras altizonante
    curp = this.limpiarAltizonante(curp);
    //Dos dígitos del año
    curp += ano.substring(2);
    //Dos dígitos del mes
    curp += pad(mes);
    //Dos dígitos del día
    curp += pad(dia);
    //el caracter de género
    curp += sexo;
    //Dos letras de la entidad federativa
    curp += this.identificadorEntidadFederativa(entidad);
    //Primer consonante interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerConsonanteInternaRgx, 'X'));
    //Primer consonane interna del segundo apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(segundoApellido, this.primerConsonanteInternaRgx, 'X'));
    //Primer consonane interna del nombre
    curp += this.reemplazarCaracteres(this.matchOrDefault(nombre, this.primerConsonanteInternaRgx, 'X'));
    //Consecutivo
    curp += this.identificadorDeSiglo(Number.parseInt(ano));
    //Digito verificador
    curp += this.calcularHomoclave(curp);

    return curp;
  }

  generar2(nombre: string, primerApellido: string, segundoApellido: string, ano: string, mes: string, dia: string, sexo: string, entidad: string) {
    var curp = '';

    nombre = this.limpiar(nombre);
    primerApellido = this.limpiar(primerApellido);
    segundoApellido = this.limpiar(segundoApellido);
    sexo = sexo.toUpperCase();
    if (entidad)
      entidad = entidad.toUpperCase();

    //Letra inicial del primer apellido
    curp += this.reemplazarCaracteres(this.letraInicial(primerApellido));
    //Primera vocal interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerVocalInternaRgx, 'X'));
    //Letra inicial del segundo apellido
    curp += this.reemplazarCaracteres(this.letraInicial(segundoApellido));
    //Primera letra del nombre
    curp += this.reemplazarCaracteres(this.letraInicial(nombre));

    //evalúa palabras altizonante
    curp = this.limpiarAltizonante(curp);

    //Dos dígitos del año
    curp += ano.substring(2);
    //Dos dígitos del mes
    curp += pad(mes);
    //Dos dígitos del día
    curp += pad(dia);
    //el caracter de género
    curp += sexo;

    //Dos letras de la entidad federativa
    curp += entidad;

    //Primer consonante interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerConsonanteInternaRgx, 'X'));
    //Primer consonane interna del segundo apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(segundoApellido, this.primerConsonanteInternaRgx, 'X'));

    //Primer consonane interna del nombre
    curp += this.reemplazarCaracteres(this.matchOrDefault(nombre, this.primerConsonanteInternaRgx, 'X'));

    //Consecutivo
    curp += this.identificadorDeSiglo(Number.parseInt(ano));

    //Digito verificador
    curp += this.calcularHomoclave(curp);

    return curp;
  }

  validarFechaCurp(curp: string, dia: string, mes: string, ano: string) {
    var error = true;
    var anioCurp = curp.substr(4, 2);
    var mesCurp = curp.substr(6, 2);
    var diaCurp = curp.substr(8, 2);

    if (diaCurp != dia) {
      error = false;
    }
    if (mesCurp != mes) {
      error = false;
    }
    if (anioCurp != ano.substring(2)) {
      error = false;
    }
    return error;
  }//revisa que la fecha del input de curp sea igual a la fecha de 390


  limpiar(cadena: string) {
    cadena = cadena == null ? "" : cadena.toUpperCase();
    cadena = cadena.replace('Ü', 'U');
    cadena = this.primerNombreValido(cadena);

    return cadena;
  }

  primerNombreValido(cadena: string) {
    var chunks = cadena.split(/\s/);
    if (chunks.length == 1) {
      return cadena;
    }
    for (var i = 0; i < chunks.length; i++) {
      if (this.esPrimerNombreValido(chunks[i])) {
        return chunks[i];
      }
    }
    return "";
  }

  esPrimerNombreValido(cadena: string) {
    var listaPrimerNombreInvalido = ['MARIA', 'MA.', 'MA', 'JOSE', 'J', 'J.', 'DA', 'DAS', 'DE', 'DEL', 'DER', 'DI', 'DIE', 'DD', 'EL', 'LA', 'LOS', 'LAS', 'LE', 'LES', 'MAC', 'MC', 'VAN', 'VON', 'Y'];
    var valido = true;
    listaPrimerNombreInvalido.forEach(function (n) {
      if (cadena == n) {
        valido = false;
        return;
      }
    });
    return valido;
  }

  reemplazarCaracteres(letra: string) {
    if (letra.match(this.caracteresEspecialesRgx)) {
      letra = 'X';
    }
    ;
    return letra;
  }

  letraInicial(cadena: string) {


    if (cadena == '') {
      return 'X';
    }

    return cadena[0];
  }


  matchOrDefault(cadena: string, regex: any, def: string) {


    if (cadena == '') {
      return def;
    }
    var match = null;
    if ((match = cadena.match(regex))) {
      return match[1];
    }

    return def;

  }

  limpiarAltizonante(curp: string) {

    var palabrasInconvenientes = ['BACA', 'BAKA', 'BUEI', 'BUEY', 'CACA', 'CACO', 'CAGA', 'CAGO', 'COGI', 'COJA', 'COJE', 'COJI', 'COJO', 'COLA', 'CULO', 'FALO', 'FETO', 'GETA', 'GUEI', 'GUEY', 'JETA', 'JOTO', 'KACA', 'KACO', 'KAGA', 'KAGO', 'KAKA', 'KAKO', 'KOGE', 'KOGI', 'KOJA', 'KOJE', 'KOJI', 'KOJO', 'KOLA', 'KULO', 'LILO', 'LOCA', 'LOCO', 'LOKA', 'LOKO', 'MAME', 'MAMO', 'MEAR', 'MEAS', 'MEON', 'MIAR', 'MION', 'MOCO', 'MOKO', 'MULA', 'MULO', 'NACA', 'NACO', 'PEDA', 'PEDO', 'PENE', 'PIPI', 'PITO', 'POPO', 'PUTA', 'PUTO', 'QULO', 'RATA', 'ROBA', 'ROBE', 'ROBO', 'RUIN', 'SENO', 'TETA', 'VACA', 'CAGA', 'VAGO', 'VAKA', 'VUEI', 'VUEY', 'WUEI', 'WUEY'];

    palabrasInconvenientes.forEach(function (palabraInc) {

      if (curp == palabraInc) {
        curp = replaceCharacterAt(curp, 1, 'X');
        return;
      }

    });

    return curp;
  }

  replaceCharacterAt(original: string, index: number, replace: string) {
    return original.substring(0, index) + replace + original.substring(index + 1);
  }

  identificadorEntidadFederativa(entidad: string | undefined) {

    entidad = entidad || 'AGUASCALIENTES';

    entidad = entidad.toUpperCase();
    entidad = entidad.replace('Á', 'A');
    entidad = entidad.replace('É', 'E');
    entidad = entidad.replace('Í', 'I');
    entidad = entidad.replace('Ó', 'O');
    entidad = entidad.replace('Ú', 'U');

    var clavesEstados: GenericModel[] = [
      {"nombre": 'AGUASCALIENTES', "value": 'AS'},
      {"nombre": 'MORELOS', "value": 'MS'},
      {"nombre": 'BAJA CALIFORNIA', "value": 'BC'},
      {"nombre": 'NAYARIT', "value": 'NT'},
      {"nombre": 'BAJA CALIFORNIA SUR', "value": 'BS'},
      {"nombre": 'NUEVO LEON', "value": 'NL'},
      {"nombre": 'CAMPECHE', "value": 'CC'},
      {"nombre": 'OAXACA', "value": 'OC'},
      {"nombre": 'COAHUILA', "value": 'CL'},
      {"nombre": 'PUEBLA', "value": 'PL'},
      {"nombre": 'COLIMA', "value": 'CM'},
      {"nombre": 'QUERETARO', "value": 'QT'},
      {"nombre": 'CHIAPAS', "value": 'CS'},
      {"nombre": 'QUINTANA ROO', "value": 'QR'},
      {"nombre": 'CHIHUAHUA', "value": 'CH'},
      {"nombre": 'SAN LUIS POTOSI', "value": 'SP'},
      {"nombre": 'DISTRITO FEDERAL', "value": 'DF'},
      {"nombre": 'SINALOA', "value": 'SL'},
      {"nombre": 'DURANGO', "value": 'DG'},
      {"nombre": 'SONORA', "value": 'SR'},
      {"nombre": 'GUANAJUATO', "value": 'GT'},
      {"nombre": 'TABASCO', "value": 'TC'},
      {"nombre": 'GUERRERO', "value": 'GR'},
      {"nombre": 'TAMAULIPAS', "value": 'TS'},
      {"nombre": 'HIDALGO', "value": 'HG'},
      {"nombre": 'TLAXCALA', "value": 'TL'},
      {"nombre": 'JALISCO', "value": 'JC'},
      {"nombre": 'VERACRUZ', "value": 'VZ'},
      {"nombre": 'ESTADO DE MEXICO', "value": 'MC'},
      {"nombre": 'YUCATAN', "value": 'YN'},
      {"nombre": 'MICHOACAN', "value": 'MN'},
      {"nombre": 'ZACATECAS', "value": 'ZS'},
      {"nombre": 'NACIDO EN EL EXTRANJERO', "value": 'NE'}
    ];

    return clavesEstados.find(f => f.nombre == entidad)?.value;
  };

  identificadorDeSiglo(ano: number) {
    //El penúltimo dígito de la CURP es llamado identificador de sigo
    //Tiene un valor de 0 (cero) si el año de nacimiento es entre 1900 y 1999
    // y de A entre 2000 y 2099
    if (ano < 2000) {
      return '0';
    }

    return 'A';
  };

  calcularHomoclave(c: string) {
    var segRaiz = c.substring(0, 17),
      chrCaracter = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ",
      intFactor = new Array(17),
      lngSuma = 0.0,
      lngDigito = 0.0;

    for (var i = 0; i < 17; i++) {
      for (var j = 0; j < 37; j++) {
        if (segRaiz.substring(i, i + 1) == chrCaracter.substring(j, j + 1)) {
          intFactor[i] = j;
        }
      }
    }
    for (var k = 0; k < 17; k++) {

      lngSuma = lngSuma + ((intFactor[k]) * (18 - k));
    }

    lngDigito = (10 - (lngSuma % 10));
    if (lngDigito == 10) {
      lngDigito = 0;
    }

    return lngDigito;
  };

  esUltimoCaracterCambiable(curp: string) {
    var index = curp.length - 1;
    var ultimoCaracterCurp = curp.substring(index, 1);
    var arrayCaracteresCambiables = ["1", "5", "8", "4", "0", "I", "i", "L", "l", "S", "s", "B", "b", "A", "a", "O", "o", "T", "t"];
    return arrayCaracteresCambiables.includes(ultimoCaracterCurp);
  }

  cambiaUltimoCaracterCurp(curp: string) {
    var index = curp.length - 1;
    var ultimoCaracterCurp = curp.substr(index, 1);
    if (/[A-Z]/ig.test(ultimoCaracterCurp)) {
      ultimoCaracterCurp = this.letrasPorNumeros(ultimoCaracterCurp);
    } else if (/[0-9]/ig.test(ultimoCaracterCurp)) {
      ultimoCaracterCurp = this.numerosPorLetras(ultimoCaracterCurp);
    }
    var nuevaCurp = this.setCharAt(curp, index, ultimoCaracterCurp);
    return nuevaCurp;
  }

  letrasPorNumeros(texto: string) {
    var textoReemplazado = texto.replace(/I/ig, "1").replace(/l/ig, "1").replace(/S/ig, "5").replace(/B/g, "8").replace(/A/g, "4").replace(/O/ig, "0").replace(/T/ig, "7");
    return textoReemplazado;
  }

  numerosPorLetras(texto: string) {
    var textoReemplazado = texto.replace(/1/g, "I").replace(/5/g, "S").replace(/8/g, "B").replace(/4/g, "A").replace(/0/g, "O").replace(/7/g, "T");
    return textoReemplazado;
  }

  setCharAt(str: string, index: number, chr: string) {
    if (index > str.length - 1) return str;
    return str.substring(0, index) + chr + str.substring(index + 1);
  }
}

function replaceCharacterAt(original: string, index: number, replace: string) {
  return original.substring(0, index) + replace + original.substring(index + 1);
};

function pad(str: string) {

  str += '';

  if (str.length == 1) {
    str = '0' + str;
  }

  return str;
};
