import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BiocheckErrorService {

  private valor = "";

  constructor() {
  }


  codigoError(codigo: string) {
    var msjError = '';
    switch (codigo) {
      case 'PEC00':
        msjError = 'Enrolamiento en proceso';
        break;
      case 'ECC00':
      case 'ER5E.500':
        msjError = 'Error en Consulta Biométrica Inesperado';
        break;
      case 'ECC01':
        msjError = 'No hay conexión con servicio de consulta Biometrica';
        break;
      case 'EAC01':
        msjError = 'Error inesperado en API Customers';
        break;
      case 'EAC02':
        msjError = 'No hay conexión con servicio de consulta en API Customers';
        break;
      case 'EAC03':
        msjError = 'El número de cliente no es válido';
        break;
      case 'ELB00':
        msjError = 'Error inesperado en la letura de licencias';
        break;
      case 'ELB01':
        msjError = 'Error porque no hay servicios de Escaner de documentos activos';
        break;
      case 'ELB02':
        msjError = 'Error porque no hay Licencias de Huella activas';
        break;
      case 'ELB03':
        msjError = 'Error porque no hay Licencias de Escaner de documentos activas';
        break;
      case 'EDC01':
        msjError = 'Error en dispositivo de captura de huella';
        break;
      case 'EDC02':
        msjError = 'Error en dispositivo de captura de rostro';
        break;
      case 'EDC03':
        msjError = 'Error en dispositivo de captura de documentos';
        break;

      case 'ETO02':
        msjError = 'Error de Token Opaco por estar caducado';
        break;
      case 'ETO03':
        msjError = 'Error de Token Opaco porque no existe';
        break;
      case 'ETO04':
        msjError = 'Error de Token Opaco porque está duplicado';
        break;
      case 'ETO05':
        msjError = 'Error de Token Opaco porque los datos son inválidos';
        break;
      case 'EOB00':
        msjError = 'Se terminaron los intentos de captura de huellas.';
        break;
      case 'EOB01':
        msjError = 'Huellas no pudieron se capturadas por calidad insuficiente';
        break;
      case 'EOB02':
        msjError = 'Huella duplicadas durante la captura';
        break;
      case 'EOB03':
        msjError = 'No se pudo capturar el rostro';
        break;
      case 'EOB04':
        msjError = 'Credencial del INE Apócrifa';
        break;
      case 'EOB05':
        msjError = 'Credencial del INE No Vigente';
        break;
      case 'EOB06':
        msjError = 'Credencial del INE No legible';
        break;
      case 'EOB07':
        msjError = 'No coincide el nombre y/o fecha de nacimiento de la identificación con 390';
        break;
      case 'EVD01':
        msjError = 'CURP no válido en la RENAPO';
        break;
      case 'EVD02':
        msjError = 'OCR/CIC no válido en INE';
        break;
      case 'EVD03':
        msjError = 'Huellas no válidas en INE';
        break;
      case 'EVD04':
        msjError = 'Nombre registrado no coincide con el capturado';
        break;
      case 'EVD05':
        msjError = 'Error inesperado con servicio de INE de API Connect';
        break;
      case 'EVD06':
        msjError = 'No hay conexión con servicio de RENAPO de API Connect';
        break;
      case 'EVD07':
        msjError = 'Error inesperado con servicio de RENAPO de API Connect';
        break;
      case 'EVD08':
        msjError = 'La estructura de la CURP enviada no es valida';
        break;
      case 'EVD09':
        msjError = 'Los datos no corresponden al CURP enviado';
        break;
      case 'EEB00':
        msjError = 'Error de Enrolamiento  Inesperado';
        break;
      case 'EEB01':
        msjError = 'Error de Enrolamiento porque no hay conexión con el servicio de enrolamiento';
        break;
      case 'EEB02':
        msjError = 'El sujeto ya se encuentra enrolado biométricamente';
        break;
      case 'EEB03':
        msjError = 'El usuario no se encuentra enrolado biométricamente';
        break;
      case 'CA000':
        msjError = 'Se cancelo el proceso.';
        break;
      case 'ETO00':
        msjError = 'Error inesperado en la validación del Token';
        break;
      case 'ETOV00':
      case 'ETOV04':
        msjError = 'Error inesperado en la validación del Token';
        break;
      case 'ETO01':
        msjError = 'Error de Token Opaco por ser inválido';
        break;
      case 'ETO06':
        msjError = 'No se recibió token opaco.';
        break;
      case 'EVB00':
        msjError = 'Error de Verificación Inesperado';
        break;
      case 'EVB01':
        msjError = 'El sujeto no se encuentra enrolado biométricamente';
        break;
      case 'EVB02':
        msjError = 'Error de conexión con el servicio de verificación de API Connect';
        break;
      //Códigos nuevos
      case 'EEXG00'://Excepcion Genérica
        msjError = 'Ocurrió un error en la operación, favor de volver a intentarlo.Si el problema persiste, favor de comunicarse con el administrador del sistema.';
        break;
      case "ETD01": //Tipo de documento no valido
        msjError = 'El tipo de documento a escanear no es válido.';
        break;
      //HTTP
      case 'EHTT204':
        msjError = 'HTTP: NO CONTENT';
        break;
      case 'EHTT400':
        msjError = 'HTTP: BAD REQUEST';
        break;
      case 'EHTT401':
        msjError = 'HTTP: UNAUTHORIZED';
        break;
      case 'EHTT403':
        msjError = 'HTTP: FORBIDDEN';
        break;
      case 'EHTT404':
        msjError = 'HTTP: NOT FOUND';
        break;
      case 'EHTT405':
        msjError = 'HTTP: METHOD NOT ALLOWED';
        break;
      case 'EHTT406':
        msjError = 'HTTP: NOT ACCEPTABLE';
        break;
      case 'EHTT409':
        msjError = 'HTTP: CONFLICT';
        break;
      case 'EHTT415':
        msjError = 'HTTP: UNSUPPORTED MEDIA TYPE';
        break;
      case 'EHTT500':
        msjError = 'HTTP: INTERNAL SERVER ERROR';
        break;
      case 'EHTT503':
        msjError = 'HTTP: SERVICE TEMPORARILY UNAVAILABLE';
        break;
      case 'EAPC00':
        msjError = 'Campos faltantes para completar la operación';
        break;
      case 'EAPC01':
        msjError = 'Error inesperado en API Customers';
        break;
      case 'EAPC02':
        msjError = 'No existe la buc';
        break;
      case 'ETOK00':
        msjError = 'Campos faltantes para completar la operación de Token Opaco';
        break;
      case 'ETOK01':
        msjError = 'No se pudo conseguir el OAUTH necesario para la operación de Token Opaco';
        break;
      case 'EOTP00':
        msjError = 'Campos faltantes para completar la operación de OTP';
        break;
      case 'EOTP01':
        msjError = 'No se pudo conseguir el OAUTH necesario para la operación de OTP';
        break;
      case 'EPE6801':
        msjError = 'BUC Invalido verifíquelo y vuelva a intentarlo.';
        break;
      case 'EPE6802':
        msjError = 'Error en la consulta de PE68. Código de estatus: ';
        break;
      case 'EOB09':
        msjError = '<div class="std-centrarelem columna"> <div class="separar2"><img src="assets/img/INE.png" style="width: 350px"><br></div></div><div class="std-centrarelem columna"><div class="text-center std-tituloFont font16">Indica al cliente que la identificación no está vigente<br>que es importante que actualice su identificación</br>para realizar cualquier trámite con el banco.</br></div></div>';
        break;
      case 'KO0002':
        msjError = 'CLIENTE NO ENROLADO';
        break;
//      default:
//        msjError = '0';
//        break;
    }
    return msjError;
  }


}
