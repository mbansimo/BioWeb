import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {environment} from 'src/environments/environment';
import {BcstorageService} from './bcstorage.service';
import {Errors} from './../../enums/errors.msg';
import {Router} from '@angular/router';
import {BehaviorSubject, Observable} from 'rxjs';


declare var $: any;

@Injectable({
  providedIn: 'root'
})
export class BiocheckService {
  //#region "Variables"
  private connectionSubject = new BehaviorSubject<boolean>(false);
  private connectionScanerSubject = new BehaviorSubject<boolean>(false);
  private versionInstaladorSubject = new BehaviorSubject('');
  private successTokenObject = new BehaviorSubject<any>('');
  private configuracionRespuestaSubject = new BehaviorSubject<any>('');
  licsuccessSubject = new BehaviorSubject<any>('');
  private fingerChancesSubject = new BehaviorSubject<any>('');
  private consultResponseSubject = new BehaviorSubject<any>('');
  private versionBiocheckSubject = new BehaviorSubject('');
  private ejecutaBatObject = new BehaviorSubject<any>('');
  private finalDateSubject = new BehaviorSubject<any>('');
  private instructionScanObject = new BehaviorSubject<any>('');
  private devicesSuccessSubject = new BehaviorSubject<any>('');
  private pE68GuardarRespuestaObject = new BehaviorSubject<any>('');
  respuestaProcesadorObject = new BehaviorSubject<any>('');
  private fingerChancesObject = new BehaviorSubject<any>('');
  private successVerifyObject = new BehaviorSubject<any>('');
  private verifyResponseObject = new BehaviorSubject<any>('');
  private loadingObject = new BehaviorSubject<any>('');
  private responseScanObject = new BehaviorSubject<any>('');
  private failBuroObject = new BehaviorSubject<any>('');
  private showPreviewObject = new BehaviorSubject<any>('');
  private showInstructionObject = new BehaviorSubject<any>('');
  private ineResponseObject = new BehaviorSubject<any>('');
  private editableDataResponseObject = new BehaviorSubject<any>('');
  dataFingerResponseObject = new BehaviorSubject<any>('');
  evaluateSuccessResponseObject = new BehaviorSubject<any>('');
  private faceAlreadyCapturedObject = new BehaviorSubject<any>('');
  private dataFinger2ResponseObject = new BehaviorSubject<any>('');
  private finalDateObject = new BehaviorSubject<any>('');
  private oDB6GuardarRespuestaObject = new BehaviorSubject<any>('');
  public readonly connection$ = this.connectionSubject.asObservable();
  public readonly connectionScaner$ = this.connectionScanerSubject.asObservable();
  public connection: any;
  public proxy: any;
  public blacklist: boolean = true;
  private showPreviewCheckICAOObject = new BehaviorSubject<any>('');
  private showAttibutesICAOResponseObject = new BehaviorSubject<any>('');
  private captureCheckObject = new BehaviorSubject<any>('');
  private facecropObject = new BehaviorSubject<any>('');
  failICAOObject = new BehaviorSubject<any>('');
  private showPreviewIneCaptureObject = new BehaviorSubject<any>('');
  private getTipoVerificacionObject = new BehaviorSubject<any>('');
  private checkIfCameraIsConectedObject = new BehaviorSubject<any>('');
  private facialChancesObject = new BehaviorSubject<any>('');
  private showPreviewIneObject = new BehaviorSubject<any>('');
  private ineFacialMotorResponseObject = new BehaviorSubject<any>('');
  private ineFacialResponseObject = new BehaviorSubject<any>('');
  private responseRenapoObject = new BehaviorSubject<any>('');


  //#endregion

  constructor(
    private readonly http: HttpClient,
    private storageService: BcstorageService,
    private readonly router: Router
  ) {
    this.crearConexion();
    this.proxy.on('finalDate', (hora: string, fecha: string, trasaction: string) => {
      let date = {hora, fecha, trasaction}
      this.finalDateSubject.next(date);
    });
  }

  //#region "Metodos para signalR"
  public crearConexion(): void {
    this.connection = $.hubConnection(environment.hubUri);
    this.proxy = this.connection.createHubProxy('biocheckHub');
  }

  public initializeSignalConnection(): void {
    this.connection.start().done((data: any) => {
      console.log('Connected to Notification Hub');
      this.connectionScanerSubject.next(true);
    }).catch((error: any) => {
      console.log('Notification Hub error -> ' + error);
    });
  }

  // MÉTODO GENERICO PARA INVOCAR UNA ACCIÓN
  invokeMethod(actionName: string, data: any[]) {
    this.proxy.invoke(actionName, ...data)
      .then(() => {
      })
      .catch((error: any) => {
        console.log(`error ${actionName} -> ${error}`);
      });
  }

  onStopSignalR() {
    if (this.connection) {
      this.storageService.bcStorage.signalrStopped = true;
      this.connection.stop();
      console.log("=> Finaliza conexion a signalr <=")
    }
  }

  checkService(): void {
    console.log('ingreso al checkService')
    this.storageService.bcStorage.signalrReady = false;
    this.connection.start().done((data: any) => {
      console.log('Connected to Notification Hub...');
      this.storageService.bcStorage.signalrReady = true;
      this.connectionSubject.next(true);
    }).catch((error: any) => {
      this.storageService.bcStorage.proceso = false;
      this.storageService.bcStorage.apicNombre = '';
      this.storageService.bcStorage.apicApellidoP = '';
      this.storageService.bcStorage.apicApellidoM = '';
      this.storageService.bcStorage.codigoflujo = 'EBC00';
      if (Object.keys(Errors).includes(this.storageService.bcStorage.codigoflujo)) { // valida si existe el código en los enum Errors
        this.storageService.bcStorage.mensajeflujo = Errors[this.storageService.bcStorage.codigoflujo as keyof typeof Errors]; //busca el valor del enum
      }
      this.connectionSubject.next(false);
      this.router.navigateByUrl('/finalizar');
    });
  }

  //#endregion

  //#region "Metodos sin respuesta de back"
  public async getGuid() {
    await this.invokeMethod('guid', []);
  }

  // escribe log
  invokeEscribeLog(params: any[]) {
    this.invokeMethod('escribeLog', params);
  }

  public async getObtenerVersionDespliegue() {
    await this.proxy.on('obtenerVersionDespliegue', (response: string) => this.onGetVersionDespliegue(response));
  }

  onGetVersion(response: any) {
    this.storageService.bcStorage.versionSistema = response;
    this.versionInstaladorSubject.next(response);
  }

  onGetVersionDespliegue(response: any) {
    this.storageService.bcStorage.versionBiocheck = response;
    this.versionBiocheckSubject.next(response);
  }

  public async getUrlFront(params: any[]) {
    await this.proxy.on('urlFrontResponse', (response: any) => console.log('url ->', response));
    await this.invokeMethod('UrlFront', params);
  }

  public async setEraseBiometrics() {
    await this.proxy.on('eraseBiometricsResponse', (response: any) => console.log('url ->', response));
    await this.invokeMethod('eraseBiometrics', []);
  }

  public async setConfigData() {
    await this.proxy.on('ConfigDataResponse', (response: any) => console.log('url ->', response));
    await this.invokeMethod('setConfigData', []);
  }

  public async redireccionar(params: any[]) {
    let client = params[1] ? 'setRedirectUrl' : 'setFrontUrl';
    await this.proxy.on(client, (response: any) => console.log(response));
    await this.invokeMethod('getFrontUrl', params);
  }

  public async invokeVerifyToken(params: any[]) {
    await this.invokeMethod('verifyToken', params);
  }

  public async invokeVerifyTokenTransversal(params: any[]) {
    await this.invokeMethod('verifyTokenTransversal', params);
  }

  public async isSuperUser() {
    await this.proxy.on('isSuperUser', (response: any) => {
    });
  }

  public async transactionID() {
    await this.invokeMethod('transactionID', []);
  }

  //#endregion

  //#region "metodos client que esperan respuesta back"
  // obtener versión instalador
  public async getVersionInstalador(params: any) {
    await this.proxy.on('biocheckVersionInstalador', (response: any) => this.onGetVersion(response));
    await this.invokeMethod('getBiocheckVersion', params);
  }

  get versionInstalador$() {
    return this.versionInstaladorSubject.asObservable();
  }

  public async getFinalDate() {
    await this.invokeMethod('GetFinalDate', []);
  }

  public async getfinalDate() {
    await this.proxy.on('finalDate', (hora: string, fecha: string, trasaction: string) => {
      let date = {hora, fecha, trasaction}
      this.finalDateObject.next(date);
    });
  }

  get finalDate$() {
    return this.finalDateSubject.asObservable();
  }

  public async getConfiguracionRespuesta() {
    //    debugger;
    await this.proxy.on('configuracionRespuesta', (response: any) => this.configuracionRespuestaSubject.next(response));
    // await this.invokeMethod('descargarConfiguracion', []);
    console.log('getConfiguracionRespuesta(). metodo de proxy')
  }

  get configuracionSistema$() {
    return this.configuracionRespuestaSubject.asObservable();
  }

  public async getFingerLicences(params: any[]) {
    await this.invokeMethod('getFingerLicences', params);
  }

  public async getlicsuccess() {
    await this.proxy.on('licsuccess', (response: any) => this.licsuccessSubject.next(response));
  }

  get licsuccess$() {
    return this.licsuccessSubject.asObservable();
  }

  public async fingerChancesVerify() {
    await this.invokeMethod('getFingerChancesVerify', []);
  }

  public async getFingerChances() {
    await this.proxy.on('fingerChances', (response: any) => this.fingerChancesSubject.next(response));
  }

  get fingerChances$() {
    return this.fingerChancesSubject.asObservable();
  }

  fingerChancesSubjectUnsuscribe(){
    this.fingerChancesSubject.unsubscribe();
  }

  public async consult() {
    await this.invokeMethod('consult', []);
  }

  public async getConsult() {
    await this.proxy.on('consultResponse', (response: any) => this.consultResponseSubject.next(response));
  }

  get consult$() {
    return this.consultResponseSubject.asObservable();
  }

  public async devicesConnectedVerify(params: any[]) {
    await this.invokeMethod('DevicesConnectedVerify', params);
  }

  public async getDevicesSuccess() {
    await this.proxy.on('DevicesSuccess', (response: any) => this.devicesSuccessSubject.next(response));
  }

  get devicesSuccess$() {
    return this.devicesSuccessSubject.asObservable();
  }

  public async devicesConnectedNotEnrolled(params: any[]) {
    await this.invokeMethod('devicesConnectedNotEnrolled', params);
  }


  public async getSuccessToken() {
    await this.proxy.on('successToken', (response: any) => {
      try {
        this.storageService.bcStorage.tokenBase64 = response.Datos.stokenValidatorResponse.pAdicional;
      } catch (errorTokenBase64) {
        this.storageService.bcStorage.tokenBase64 = "";
      }
      this.successTokenObject.next(response);
    });
  }

  get successToken$() {
    return this.successTokenObject.asObservable();
  }


  public async pE68Consultar() {
    await this.invokeMethod('pE68Consultar', []);
  }

  public async getpE68GuardarRespuesta() {
    await this.proxy.on('pE68GuardarRespuesta', (response: any) => this.pE68GuardarRespuestaObject.next(response));
    // await this.invokeMethod('pE68GuardarRespuesta', []);
    // await this.proxy.on('DevicesSuccess', (response: any) => this.licsuccessSubject.next(response));
  }

  get pE68GuardarRespuesta$() {
    return this.pE68GuardarRespuestaObject.asObservable();
  }

  public async oDB6Consultar() {
    await this.invokeMethod('oDB6ConsultarCorreo', []);
  }

  public async getoDB6GuardarRespuesta() {
    await this.proxy.on('oDB6ConsultarCorreoRespuesta', (response: any) => this.oDB6GuardarRespuestaObject.next(response));
  }

  get oDB6GuardarRespuesta$() {
    return this.oDB6GuardarRespuestaObject.asObservable();
  }

  //#endregion

  //#region "Utilerias"
  msjExcepcionSumarizada(msj: string, diccionario: any) {
    var mensajeFinal = msj;
    if (diccionario != null && diccionario != undefined) {

      $.each(diccionario, function (key: string, value: string) {
        mensajeFinal += " " + key + " : " + value;
      });
    }
    return mensajeFinal;
  };

  //#endregion

  public async failProcesador() {
    await this.proxy.on('fail', (code: string, message: string) => {
      const response = {code, message};
      console.log('Obtuvimos respuesta en el fail --> ' + response);
      this.respuestaProcesadorObject.next(response);
      if (response.code != '') {
        this.blacklist = false;
      }

    });
  }

  public failProcesadorNew() {
    this.respuestaProcesadorObject = new BehaviorSubject<any>('');
//    this.licsuccessSubject = new BehaviorSubject<any>('');
//    this.configuracionRespuestaSubject = new BehaviorSubject<any>('');

  }

  public failProcesadorUnsubscribe() {
    this.respuestaProcesadorObject.unsubscribe();
    this.respuestaProcesadorObject = new BehaviorSubject<any>('');

  }

  public respuestaProcesadorUnsubscribe() {
//    this.respuestaProcesadorObject.unsubscribe();
  }

  public licsuccessUnsubscribe() {
    this.licsuccessSubject.unsubscribe();
  }

  public devicesSuccessUnsubcribe() {
    this.devicesSuccessSubject.unsubscribe();
  }

  public async respuestaProcesador() {
    console.log('Ingreso a respuestaProcesador')
    let error: any;
    await this.proxy.on('respuestaProcesador', (response: any) => {
      try {
        console.log('r ->', response);
        this.respuestaProcesadorObject.next(response)
      } catch (response) {
        console.log('error' + error);
      }
    });
  }

  get respuestaProcesador$() {
    return this.respuestaProcesadorObject.asObservable();
  }

  //#region funciones captura huellas
  public async getfingerChances() {
    await this.invokeMethod('getFingerChances', []);
  }

  public async fingerChances() {
    await this.proxy.on('fingerChances', (intentos: number, EsEscanerUnidactilar: boolean) => {
      let resp = {intentos, EsEscanerUnidactilar}
      this.fingerChancesObject.next(resp);
    });
  }

  get fingerChancesRespuesta$() {
    return this.fingerChancesObject.asObservable();
  }

  fingerChancesObjectUnsuscribe(){
    this.fingerChancesObject.unsubscribe();
    this.fingerChancesObject = new BehaviorSubject<any>('');

  }

  public async verify() {
    await this.invokeMethod('verify', []);
  }

  public async getverifyResponse() {
    await this.proxy.on('verifyResponse', (response: any) => this.verifyResponseObject.next(response));
  }

  get verifyResponse$() {
    return this.verifyResponseObject.asObservable();
  }

  verifyResponseObjectUnsuscribe(){
    this.verifyResponseObject.unsubscribe();
    this.verifyResponseObject = new BehaviorSubject<any>('');

  }

  public async evaluateVerify() {
    await this.invokeMethod('evaluateVerify', []);
  }

  public async getevaluateVerify() {
    await this.proxy.on('successVerify', (response: any) => this.successVerifyObject.next(response));
  }

  get successVerify$() {
    return this.successVerifyObject.asObservable();
  }

  successVerifyObjectUnsuscribe(){
    this.successVerifyObject.unsubscribe();
    this.successVerifyObject = new BehaviorSubject<any>('');

  }

  public async addFingerVerifyINE(params: any) {
    await this.invokeMethod('addFingerVerifyINE', params);
  }

  public async AddFingerVerify(params: any) {
    await this.invokeMethod('AddFingerVerify', params);
  }

  // public async getVersionInstalador(params: any) {
  //   await this.proxy.on('biocheckVersionInstalador', (response: string) => this.onGetVersion(response));
  //   await this.invokeMethod('getBiocheckVersion', params);
  // }
  public async getloading() {
    await this.proxy.on('loading', (response: any) => this.loadingObject.next(response));
  }

  get loadingRespuesta$() {
    return this.loadingObject.asObservable();
  }

  loadingObjectUnsuscribe(){
    this.loadingObject.unsubscribe();
    this.loadingObject = new BehaviorSubject<any>('');
  }
  public async getfailBuro() {
    await this.proxy.on('failBuro', (Code: string, Message: string) => {
      let fail = {Code, Message}
      this.failBuroObject.next(fail);
    });
  }

  get failBuroRespuesta$() {
    return this.failBuroObject.asObservable();
  }

  failBuroRespuestaUnsubscribe() {
    this.failBuroObject.unsubscribe();
    this.failBuroObject = new BehaviorSubject<any>('');
  }

  public async getshowPreview() {
    await this.proxy.on('showPreview', (response: any = "") => this.showPreviewObject.next(response));
  }

  get showPreviewRespuesta$() {
    return this.showPreviewObject.asObservable();
  }

  public showPreviewObjectUnsuscribe(){
    this.showPreviewObject.unsubscribe();
    this.showPreviewObject = new BehaviorSubject<any>('');
  }


  borradoShowPreview() {
    this.showPreviewObject = new BehaviorSubject<any>('');
    this.successVerifyObject = new BehaviorSubject<any>('');
    this.verifyResponseObject = new BehaviorSubject<any>('');
    this.dataFingerResponseObject = new BehaviorSubject<any>('');
    this.loadingObject = new BehaviorSubject<any>('');
  }


  public async verifyINENoEnrolled(params: any) {
    await this.invokeMethod('verifyINENoEnrolled', params);
  }

  public async getineResponse() {
    await this.proxy.on('ineResponse', (response: any) => this.ineResponseObject.next(response));
  }

  get ineResponseRespuesta$() {
    return this.ineResponseObject.asObservable();
  }

  public async editableData(params: any) {
    await this.invokeMethod('editableData', params);
  }

  public async geteditableDataResponse() {
    await this.proxy.on('editableDataResponse', (response: any) => this.editableDataResponseObject.next(response));
  }

  get editableDataResponseRespuesta$() {
    return this.editableDataResponseObject.asObservable();
  }

  public async startEvaluation() {
    await this.invokeMethod('StartEvaluation', [false]);
  }

  public async getEvaluateSuccess() {
    await this.proxy.on('EvaluateSuccess', (response: any) => {
      try {
        this.evaluateSuccessResponseObject.next(response)
      } catch (response) {
        console.log('error' + response);
      }
    })
  }

  get evaluateSuccessResponse$() {
    return this.evaluateSuccessResponseObject.asObservable();
  }

  public async FaceAlreadyCaptured() {
    await this.proxy.on('faceAlreadyCaptured', (response: any) => {
      try {
        this.faceAlreadyCapturedObject.next(response)
      } catch (response) {
        console.log('error' + response);
      }
    })
  }

  get FaceAlreadyCapturedResponse$(){
    return this.faceAlreadyCapturedObject.asObservable();
  }

  public faceAlreadyCapturedObjectUnsuscribe(){
    this.faceAlreadyCapturedObject.unsubscribe();
    this.faceAlreadyCapturedObject = new BehaviorSubject<any>('');
  }

  public async addFinger(params: any) {
    await this.invokeMethod('addFinger', params);
  }

  public async getDataFinger() {
    await this.proxy.on('dataFinger', (response: any) => {
      try {
        this.dataFingerResponseObject.next(response)
      } catch (response) {
        console.log('error: ' + response);
      }
    });
  }

  get dataFingerResponse$() {
    return this.dataFingerResponseObject.asObservable();
  }

  public dataFingerResponseObjectUnsucribe(){
    this.dataFingerResponseObject.unsubscribe();
    this.dataFingerResponseObject = new BehaviorSubject<any>('');
  }

  public async getDataFinger2() {
    await this.proxy.on('dataFinger', (response: any) => {
      try {
        this.dataFinger2ResponseObject.next(response)
      } catch (response) {
        console.log('error: ' + response);
      }
    });
  }

  get dataFinger2Response$() {
    return this.dataFinger2ResponseObject.asObservable();
  }

  //#region verificacion escritorio
  //public async notificacionEmail(correoElectronico: string, avisoDePrivacidad: string) {
  //  await this.invokeMethodGeneric('notificacionEmail', correoElectronico, avisoDePrivacidad);
  // }

// Servicios de captura Rostro

  public async faceCaptureCheck(params: any) {
    await this.invokeMethod('FaceCaptureCheck', params);
  }

  public async getShowPreviewCheckICAO() {
    await this.proxy.on('showPreviewCheckICAO', (response: any) => this.showPreviewCheckICAOObject.next(response));
  }

  public showPreviewCheckICAOUnsuscribe(){
    this.showPreviewCheckICAOObject.unsubscribe();
    this.showPreviewCheckICAOObject = new BehaviorSubject<any>('');

  }

  get showPreviewCheckICAOResponse$() {
    return this.showPreviewCheckICAOObject.asObservable();
  }

  public async getShowAttibutesICAOResponse() {
    await this.proxy.on('showAttibutesICAOResponse', (response: any) => this.showAttibutesICAOResponseObject.next(response));
  }

  get showAttibutesICAOResponse$() {
    return this.showAttibutesICAOResponseObject.asObservable();
  }

  public showAttibutesICAOResponseObjectUnsuscribe(){
    this.showAttibutesICAOResponseObject.unsubscribe();
    this.showAttibutesICAOResponseObject = new BehaviorSubject<any>('');
  }

  public async getcaptureCheck() {
    await this.proxy.on('captureCheck', (response: any) => {
      try {
        this.captureCheckObject.next(response)
      } catch (response) {
        console.log('error: ' + response);
      }
    });
  }

  get captureCheck$() {
    return this.captureCheckObject.asObservable();
  }

  public captureCheckObjectUnsuscribe(){
    this.captureCheckObject.unsubscribe();
    this.captureCheckObject = new BehaviorSubject<any>('');

  }

  public async faceCapture(params: any) {
    await this.invokeMethod('FaceCapture', params);
  }

  public async getFacecrop() {
    await this.proxy.on('facecrop', (response: any) => this.facecropObject.next(response));
  }

  get facecrop$() {
    return this.facecropObject.asObservable();
  }

  public facecropObjectUnsuscribe(){
    this.facecropObject.unsubscribe();
    this.facecropObject = new BehaviorSubject<any>('');

  }


  public async getfailICAO() {
    await this.proxy.on('failICAO', (response: any) => this.failICAOObject.next(response));
  }

  get failICAO$() {
    return this.failICAOObject.asObservable();
  }

  public failICAOObjectUnsuscribe(){
    this.failICAOObject.unsubscribe();
    this.failICAOObject = new BehaviorSubject<any>('');

  }

  public async getFaceChances(params: any) {
    await this.invokeMethod('getFaceChances', params);
  }

  public async getShowInstruction() {
    await this.proxy.on('showInstruction', (response: any) => this.showInstructionObject.next(response));
  }

  get showInstruction$() {
    return this.showInstructionObject.asObservable();
  }

  public showInstructionObjectUnsuscribe(){
    this.showInstructionObject.unsubscribe();
    this.showInstructionObject = new BehaviorSubject<any>('');
  }

  //Servicios de Verificacion no pasaporte

  public async ejecutaBat() {
    await this.proxy.on('biocheckEjecutaBat', (response: any) => this.ejecutaBatObject.next(response));
    await this.invokeMethod('EjecutaBat', []);
  }

  get ejecutaBat$() {
    return this.ejecutaBatObject.asObservable();
  }


  public async procesador(params: any[]) {
    await this.invokeMethod('Procesador', params)
  }

  //scan document invoke
  public async invokeScanDocument(params: any) {
    await this.invokeMethod('ScanDocument', params);
  }

  public async invokeScanDocumentManual(params: any) {
    await this.invokeMethod('ScanDocumentManual', params);
  }

  public async getResponseScan() {
    await this.proxy.on('responseScan', (response: any) => {
      console.log('scan ->', response);
      this.responseScanObject.next(response);
    });
  }

  public async getResponseScanIneFacial() {
    let error: any;
    await this.proxy.on('responseScanIneFacial', (Code: string, Message: string, Success: any) => {
      try {
        let response = {Code, Message}
        console.log('scan ->', response);
        this.responseScanObject.next(response);
      } catch (response) {
        console.log('error en responseScan' + error);
      }
    });
  }


  // Fail Scan
  public async getFailScan() {
    await this.proxy.on('failScan', (response: any) => {
      this.responseScanObject.next(response);
    });
  }

  get responseScan$() {
    return this.responseScanObject.asObservable();
  }

  //scan document invoke
//  public async invokeScanDocumentManual(params: any) {
//    await this.invokeMethod('ScanDocumentManual', params);
//  }

  // Instrucciones Scan
  public async getInstructionScan() {
    await this.proxy.on('instructionScan', (code: string, message: string) => {
      const response = {code, message}
      this.instructionScanObject.next(response);
    });
  }

  get instruccionesScaner$() {
    return this.instructionScanObject.asObservable();
  }

  //  Aviso de privacidad
  //#region verificacion escritorio
  public async notificacionEmail(params: any[]) {
    await this.invokeMethod('notificacionEmail', params);
  }

  public async stopCamera(params: any[]) {
    await this.invokeMethod('stopCamera', params);
  }

  public async takePicture(params: any[]) {
    await this.invokeMethod('takePicture', params);
  }

  public async showPreviewIneCapture() {
    var error: any;
    await this.proxy.on('showPreviewIneCapture', (response: any) => {
      try {
        this.showPreviewIneCaptureObject.next(response);
      } catch (response) {
        console.log('error' + error);
      }
    });
  }

  get showPreviewIneCapture$() {
    return this.showPreviewIneCaptureObject.asObservable();
  }

  public async getTipoVerificacion(params: any[]) {
    this.proxy.invoke('getTipoVerificacion').done((res: any) => {
      this.getTipoVerificacionObject.next(res);
      console.log('esto lleva tipoVerificacionFacial: ' + res)
    }).catch((error: any) => {
      console.log('Error de captura' + error);
    })
  }

  get getTipoVerificacion$() {
    return this.getTipoVerificacionObject.asObservable();
  }


  public async checkIfCameraIsConected(params: any) {
    //await this.invokeMethod('checkIfCameraIsConected', params);

    this.proxy.invoke('checkIfCameraIsConected').done((res: any) => {
      this.checkIfCameraIsConectedObject.next(res);
      console.log('esto lleva res' + res)
    }).catch((error: any) => {
      console.log('Error de captura' + error);
    })
  }

  public async isCameraConected() {
    await this.proxy.on('checkIfCameraIsConected', (response: any) => {

      this.checkIfCameraIsConectedObject.next(response);
    });
  }

  get isCameraConected$() {
    return this.checkIfCameraIsConectedObject.asObservable();
  }

  public async getFacialChances() {
    await this.invokeMethod('getFacialChances', []);
  }

  public async facialChances() {
    await this.proxy.on('facialChances', (response: any) => {
      this.facialChancesObject.next(response);
    });
  }

  get facialChances$() {
    return this.facialChancesObject.asObservable();
  }

  public async startCameraPreview() {
    this.proxy.invoke('StartCameraPreview').done((res: any) => {
      this.checkIfCameraIsConectedObject.next(res);
      console.log('esto lleva StartCameraPreview' + res)
    }).catch((error: any) => {
      console.log('Error de captura' + error);
    })
  }

  public async showPreviewIne() {
    await this.proxy.on('showPreviewIne', (response: any) => {
      this.showPreviewIneObject.next(response);
    });
  }

  public async reiniciarshowPreview() {
    this.showPreviewIneObject = new BehaviorSubject<any>('');
  }

  get showPreviewIne$() {
    return this.showPreviewIneObject.asObservable();
  }

  public async verificacionFacialMotor() {
    await this.invokeMethod('verificacionFacialMotor', []);
  }

  public async ineFacialMotorResponse() {
    await this.proxy.on('ineFacialMotorResponse', (response: any) => {
      this.ineFacialMotorResponseObject.next(response);
    })
  }

  get ineFacialMotorResponse$() {
    return this.ineFacialMotorResponseObject.asObservable();
  }


  //ondestroy
  public destruirDialogCapturaUnsubscribe() {
    this.ineFacialMotorResponseObject.unsubscribe();
    this.showPreviewIneObject.unsubscribe();
    this.checkIfCameraIsConectedObject.unsubscribe();

  }

  public async verificacionINEFacial(curp: string, ocr: string, nombre: string, apellidoPaterno: string,
                                     apellidoMaterno: string, claveElector: string, codigoEmision: string, cic: string, anioEmision: string,
                                     anioRegistro: string) {
    const dataine = {curp, ocr, nombre, apellidoPaterno, apellidoMaterno, claveElector, codigoEmision, cic, anioEmision}
    await this.invokeMethod('verificacionINEFacial', [dataine])
  }

  public async ineFacialResponse() {
    await this.proxy.on('ineFacialResponse', (response: any) => {
      this.ineFacialResponseObject.next(response);
    })
  }

  get ineFacialResponse$() {
    return this.ineFacialResponseObject.asObservable();
  }

  public async checkRenapo() {
    await this.invokeMethod('checkRenapo', []);
  }

  public async getresponseRenapo() {
    await this.proxy.on('responseRenapo', (response: any) => this.responseRenapoObject.next(response));
  }

  get responseRenapoRespuesta$() {
    return this.responseRenapoObject.asObservable();
  }

  public async checkRenapoCustomCurp(params: any) {
    await this.invokeMethod('checkRenapoCustomCurp', params);
  }

  public async verifyINE() {
    await this.invokeMethod('verifyINE', []);
  }

}
