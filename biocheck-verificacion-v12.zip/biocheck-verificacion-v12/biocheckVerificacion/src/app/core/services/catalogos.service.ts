import {Injectable} from '@angular/core';
import {EstadosRenapoModel, GenericModel, nacionalidadesSinSegundoApellido} from "../models/estados-renapo.model";

@Injectable({
  providedIn: 'root'
})
export class CatalogosService {

  public estadosRenapo: EstadosRenapoModel[] = [
    {"value": "AS", "nombre": "AGUASCALIENTES"},
    {"value": "BC", "nombre": "BAJA CALIFORNIA"},
    {"value": "BS", "nombre": "BAJA CALIFORNIA SUR"},
    {"value": "CC", "nombre": "CAMPECHE"},
    {"value": "CS", "nombre": "CHIAPAS"},
    {"value": "CH", "nombre": "CHIHUAHUA"},
    {"value": "DF", "nombre": "CIUDAD DE MEXICO"},
//    {"value": "DF", "nombre": "DISTRITO FEDERAL"},
    {"value": "CL", "nombre": "COAHUILA"},
    {"value": "CM", "nombre": "COLIMA"},
    {"value": "DG", "nombre": "DURANGO"},
    {"value": "GT", "nombre": "GUANAJUATO"},
    {"value": "GR", "nombre": "GUERRERO"},
    {"value": "HG", "nombre": "HIDALGO"},
    {"value": "JC", "nombre": "JALISCO"},
    {"value": "MC", "nombre": "ESTADO DE MEXICO"},
    {"value": "MN", "nombre": "MICHOACAN"},
    {"value": "MS", "nombre": "MORELOS"},
    {"value": "NT", "nombre": "NAYARIT"},
    {"value": "NL", "nombre": "NUEVO LEON"},
    {"value": "OC", "nombre": "OAXACA"},
    {"value": "PL", "nombre": "PUEBLA"},
    {"value": "QO", "nombre": "QUERETARO"},
    {"value": "QR", "nombre": "QUINTANA ROO"},
    {"value": "SP", "nombre": "SAN LUIS POTOSI"},
    {"value": "SL", "nombre": "SINALOA"},
    {"value": "SR", "nombre": "SONORA"},
    {"value": "TC", "nombre": "TABASCO"},
    {"value": "TS", "nombre": "TAMAULIPAS"},
    {"value": "TL", "nombre": "TLAXCALA"},
    {"value": "VZ", "nombre": "VERACRUZ"},
    {"value": "YN", "nombre": "YUCATAN"},
    {"value": "ZS", "nombre": "ZACATECAS"}
  ];


  public estadosRenapoG: GenericModel[] = [
    // { "value": "AS", "nombre": "AGUASCALIENTES" },
    // { "value": "BC", "nombre": "BAJA CALIFORNIA" },
    // { "value": "BS", "nombre": "BAJA CALIFORNIA SUR" },
    // { "value": "CC", "nombre": "CAMPECHE" },
    // { "value": "CS", "nombre": "CHIAPAS" },
    // { "value": "CH", "nombre": "CHIHUAHUA" },
    // { "value": "DF", "nombre": "CIUDAD DE MEXICO" },
    // { "value": "DF", "nombre": "DISTRITO FEDERAL" },
    // { "value": "CL", "nombre": "COAHUILA" },
    // { "value": "CM", "nombre": "COLIMA" },
    // { "value": "DG", "nombre": "DURANGO" },
    // { "value": "GT", "nombre": "GUANAJUATO" },
    // { "value": "GR", "nombre": "GUERRERO" },
    // { "value": "HG", "nombre": "HIDALGO" },
    // { "value": "JC", "nombre": "JALISCO" },
    { "value": "MC", "nombre": "ESTADO DE MEXICO" },
    // { "value": "MN", "nombre": "MICHOACAN" },
    // { "value": "MS", "nombre": "MORELOS" },
    // { "value": "NT", "nombre": "NAYARIT" },
    // { "value": "NL", "nombre": "NUEVO LEON" },
    // { "value": "OC", "nombre": "OAXACA" },
    // { "value": "PL", "nombre": "PUEBLA" },
    // { "value": "QO", "nombre": "QUERETARO" },
    // { "value": "QR", "nombre": "QUINTANA ROO" },
    // { "value": "SP", "nombre": "SAN LUIS POTOSI" },
    // { "value": "SL", "nombre": "SINALOA" },
    // { "value": "SR", "nombre": "SONORA" },
    // { "value": "TC", "nombre": "TABASCO" },
    // { "value": "TS", "nombre": "TAMAULIPAS" },
    // { "value": "TL", "nombre": "TLAXCALA" },
    // { "value": "VZ", "nombre": "VERACRUZ" },
    // { "value": "YN", "nombre": "YUCATAN" },
    // { "value": "ZS", "nombre": "ZACATECAS" }
  ];

  public nacionalidadesSinSegundoApellido: string[] = ["ARG"];
  // Array de Nationality Code desde OCR

  public domains: string[] = ["@gmail.com", "@yahoo.com", "@outlook.com", "@hotmail.com", "Otro"];

  constructor() {
  }
}
