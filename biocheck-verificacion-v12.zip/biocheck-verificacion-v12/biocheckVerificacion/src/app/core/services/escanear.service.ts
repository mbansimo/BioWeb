import { Injectable } from '@angular/core';
import { BcstorageService } from "./bcstorage.service";
import { CatalogosService } from "./catalogos.service";
import { EstadosRenapoModel } from "../models/estados-renapo.model";
import * as unorm from 'unorm';
import * as $ from "jquery";
import { RespuestaControlErroresModel } from "../models/respuesta-control-errores.model";



@Injectable({
  providedIn: 'root'
})
export class EscanearService {

  constructor(
    private storageService: BcstorageService,
    public catalogosService: CatalogosService
  ) { }


  public guardarDatos(escanerRespuesta: any, documento: number) {

    //documento  1 = ife/ine   2 = FM   3 = Pasaporte
    switch (documento) {
      case 1:
        escanerRespuesta.Values.forEach((val: { Name: any; Value: any; }) => { //Esto es para la clave de lector de INE
          if (val?.Name === 'CIC') {
            this.storageService.bcStorage.isCIC = true; //Bandera de que la INE tiene CIC
            this.storageService.bcStorage.cic = val?.Value;
          }
          if (val?.Name == "FrontImage") {
            let frente = $("#frente");
            if (frente.length > 0) {
              frente.attr("src", "data:image/png;base64," + val.Value);
              frente.css("opacity", "1");
              this.storageService.bcStorage.imagenFrente = true;
              this.storageService.bcStorage.imgFrontBase64 = val?.Value;
            }
          }
          if (val?.Name == "BackImage") {
            let atras = $("#atras");
            if (atras.length > 0) {
              atras.attr("src", "data:image/png;base64," + val.Value);
              atras.css("opacity", "1");
              this.storageService.bcStorage.imagenAtras = true;
              this.storageService.bcStorage.imgBackBase64 = val?.Value;
            }
          }
          if (val?.Name == "VIZ Given Name") {
            this.storageService.bcStorage.nombre = val?.Name == "VIZ Given Name" && val?.Value;
          }
          if (val?.Name == "VIZ Surname") {
            this.storageService.bcStorage.apellidos = val?.Name == "VIZ Surname" && val?.Value;
          }
          if (val?.Name == "VIZ Father's Surname") {
            this.storageService.bcStorage.apellidoP = val?.Value;
          }
          if (val?.Name == "VIZ Mother's Surname") {
            this.storageService.bcStorage.apellidoM = val?.Value;
          }
          if (val?.Name == "Birth Date Day") {
            this.storageService.bcStorage.dia = val?.Value;
          }
          if (val?.Name == "Birth Date M") {
            this.storageService.bcStorage.mes = val?.Value;
          }
          if (val?.Name == "Birth Date Year") {
            this.storageService.bcStorage.ano = val?.Value;
          }
          if (val?.Name == "BirthCode") {
            this.storageService.bcStorage.entidadNacimiento = val?.Value;
          }
          if (val?.Name == "Type") {
            this.storageService.bcStorage.type = val?.Value;
          }
          if (val?.Name == "OCR") {
            this.storageService.bcStorage.ocr = val?.Value;
          }
          if (val?.Name == "Sex") {
            this.storageService.bcStorage.sexo = val?.Value; //val?.Name == "Sex" && val?.Value.indexOf("M") != -1 ? "H" : "M";
          }
          if (val?.Name == "Personal Number") {
            this.storageService.bcStorage.personalNumber = val?.Value; //Para una IFE aquí viene la clave de lector, Para una INE viene el CIC
          }
          if (val?.Name == "VIZ Registration Number") {
            this.storageService.bcStorage.claveElector = val?.Value;
          }
          if (val?.Name == "Verification Number") {
            this.storageService.bcStorage.codigoEmision = val?.Value;
          }
          if (val?.Name == "ExisteVigencia") {
            this.storageService.bcStorage.existenciaVigencia = !!(val?.Name == "ExisteVigencia" && val?.Value); //Existencia Vigencia   val?.Name == "ExisteVigencia" && val?.Value ? true : false;
          }
          if (val?.Name == "VIZ Expiration Date") {
            this.storageService.bcStorage.vigencia = this.limpiarVigencia(val?.Value);
            //            this.storageService.bcStorage.vigencia = val?.Value;  //En caso de querer entrar al modal de error abilitar esta linea
          }
          if (val?.Name == "CURP") {
            this.storageService.bcStorage.curp = val?.Value;
          }
          if (val?.Name == "Nationality Name") {
            this.storageService.bcStorage.nacionalidad = val?.Value;
          }
          if (val?.Name == "CP") {
            this.storageService.bcStorage.CP = val?.Value;
          }
          if (val?.Name == "Colonia") {
            this.storageService.bcStorage.Colonia = val?.Value;
          }
          if (val?.Name == "Edo") {
            this.storageService.bcStorage.EDO = val?.Value;
          }
          if (val?.Name == "Calle") {
            this.storageService.bcStorage.Calle = val?.Value;
          }
          if (val?.Name == "DelMun") {
            this.storageService.bcStorage.DelMun = val?.Value;
          }

          if (val?.Name == "VIZ Address") {
            this.storageService.bcStorage.direccionCalle = '';
            this.storageService.bcStorage.direccionColonia = '';
            this.storageService.bcStorage.direccionMunicipio = '';
            let dir = val?.Value.split('<');
            this.storageService.bcStorage.direccionCalle = dir.length >= 1 && dir[0];
            this.storageService.bcStorage.direccionColonia = dir.length >= 2 && dir[1];
            this.storageService.bcStorage.direccionMunicipio = dir.length >= 3 && dir[2];
          }
          if (val?.Name == "ClaveEntidad") {
            this.storageService.bcStorage.ClaveEntidad = val?.Value;
          }
          if (val?.Name == "VIZ Issue Year") {
            this.storageService.bcStorage.AnioEmision = val?.Value;
          }
          if (val?.Name == "AnioRegistro") {
            this.storageService.bcStorage.AnioRegistro = val?.Value;
          }
        });
        break;
      case 2:
        escanerRespuesta.Values.forEach((val: { Name: any; Value: any; }) => {
          if (val?.Name == "FrontImage") {
            this.storageService.bcStorage.imagenFrente = true;
            $("#frente").css("opacity", "1");
            $("#frente").attr("src", "data:image/png;base64," + val?.Value);

            $("#fmFrente").css("opacity", "1");
            $("#fmFrente").attr("src", "data:image/png;base64," + val?.Value);
            this.storageService.bcStorage.imgFrontBase64 = val?.Value;
          }
          if (val?.Name == "BackImage") {
            this.storageService.bcStorage.imagenAtras = true;
            $("#atras").css("opacity", "1");
            $("#atras").attr("src", "data:image/png;base64," + val?.Value);

            $("#fmAtras").css("opacity", "1");
            $("#fmAtras").attr("src", "data:image/png;base64," + val?.Value);
            this.storageService.bcStorage.imgBackBase64 = val?.Value;
          }
          if (val?.Name == "VIZ Given Name") {
            this.storageService.bcStorage.nombre = val?.Value;
          }
          if (val?.Name == "VIZ Surname") {
            this.storageService.bcStorage.apellidos = val?.Value;
          }
          if (val?.Name == "VIZ Birth Date") {
            this.storageService.bcStorage.fehaNacimiento = val?.Value;
          }
          if (val?.Name == "Birth Date Day") {
            this.storageService.bcStorage.dia = val?.Value;
          }
          if (val?.Name == "Birth Date M") {
            this.storageService.bcStorage.mes = val?.Value;
          }
          if (val?.Name == "VIZ CURP") {
            this.storageService.bcStorage.curp = val?.Value;
          }
          if (val?.Name == "VIZ Nationality Name") {
            this.storageService.bcStorage.nacionalidad = val?.Value;
          }
          if (val?.Name == "Nationality Code") {
            this.storageService.bcStorage.nacionalidadCode = val?.Value;
          }
          if (val?.Name == "Nationality Name") {
            this.storageService.bcStorage.nacName = val?.Value;
          }
          if (val?.Name == "VIZ Expiration Date") {
            this.storageService.bcStorage.vigencia = val?.Value;
          }
          if (val?.Name == "VIZ Issue Date") {
            this.storageService.bcStorage.emision = val?.Value;
          }
          if (val?.Name == "Sex") {
            this.storageService.bcStorage.sexo = val?.Value.indexOf("M") != -1 ? "H" : "M";
          }
          if (val?.Name == "1D Document Number" || val?.Name == "VI Document Number") {
            //Numero de Documento Forma migratoria
            this.storageService.bcStorage.numDocument = val?.Value;
            this.storageService.bcStorage.nue = val?.Value;
          }

          if (val?.Name == "Nationality Code") {
            this.storageService.bcStorage.nacionalidadCode = val?.Value;
          }
          if (val?.Name == "VIZ Nationality Name") {
            this.storageService.bcStorage.nacionalidad = val?.Value;
          }
          if (val?.Name == "Nationality Name") {
            this.storageService.bcStorage.nacName = val?.Value;
          }
          if (val?.Name == "EsPermanente") {
            if (val?.Value == 'True') {
              this.storageService.bcStorage.EsPermanente = true;
            } else {
              this.storageService.bcStorage.EsPermanente = false;
            }
          }//Existencia Vigenciav
          if (val?.Name == "VIZ Expiration Date") {
            this.storageService.bcStorage.vigencia = val?.Value;
          }
          if (val?.Name == "VIZ Issue Date") {
            this.storageService.bcStorage.emision = val?.Value;
          }
          if (val?.Name == "Sex") {
            this.storageService.bcStorage.sexo = val?.Value.indexOf("M") != -1 ? "H" : "M";
          }

          //ADD NEW VALUES
          if (val?.Name == "ft_Special_Notes") {
            this.storageService.bcStorage.Observacion = val?.Value;
          }
          if (val?.Name == "ft_Reference_Number") {
            this.storageService.bcStorage.folioNumber = val?.Value;
          }
          if (val?.Name == "Mother's Surname") {
            this.storageService.bcStorage.apellidoM = val?.Value;
          }
          if (val?.Name == "Father's Surname") {
            this.storageService.bcStorage.apellidoP = val?.Value;
          }
          if (val?.Name == "VI MRZ") {
            this.storageService.bcStorage.mrz = val?.Value;
          }
          if (val?.Name == "VI Document Number") {
            this.storageService.bcStorage.numeroPasaporte = val?.Value;
          }

        });
        break;
      case 3:
        const itemFrontImage = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "FrontImage";
        });
        const itemGivenName = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "Given Name";
        });
        const itemSurname = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VI Surname";
        });
        const itemBirthDate = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "Birth Date";
        });
        const itemVIBirthDate = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VI Birth Date";
        });
        const itemVIZBirthDate = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VIZ Birth Date";
        });
        const itemDocumentNumber = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "Document Number";
        });
        const itemPersonalNumber = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VIZ Personal Number";
        });
        const itemVINationalityCode = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VI Nationality Code";
        });
        const itemSex = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VIZ Sex";
        });
        const itemBirthPlace = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "Birth Place";
        });
        const itemVIZBirthPlace = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VIZ Birth Place";
        });

        const itemFolioNumber = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "ft_Folio_Number";
        });
        const itemObservations = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "ft_Observations";
        });
        const itemBackImage = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "BackImage";
        });
        const itemEstatusListaNegra = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "EstatusListaNegra";
        });
        const itemExpirationDate = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VIZ Expiration Date";
        });
        const itemExpiditionDate = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "VIZ Issue Date";
        });
        const itemMRZ = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "MRZ";
        });
        const itemDocumentSeries = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "Document Series";
        });
        const itemOCR = escanerRespuesta.Values.find((value: any) => {
          return value.Name == "OCR";
        });


        if (itemFrontImage != null && itemFrontImage != "") {
          this.storageService.bcStorage.pasaporteFrente = itemFrontImage.Value;
          this.storageService.bcStorage.imagenFrente = true;
          $("#pasaporteFrente").css("opacity", "1");
          $("#pasaporteFrente").attr("src", "data:image/png;base64," + itemFrontImage.Value);
        } else {
          this.storageService.bcStorage.imagenFrente = false;
          this.storageService.bcStorage.pasaporteFrente = "";
        }
        //imagen back
        if (itemBackImage != null && itemBackImage != "") {
          this.storageService.bcStorage.pasaporteAtras = itemBackImage.Value;
          this.storageService.bcStorage.imagenAtras = true;
          $("#pasaporteAtras").css("opacity", "1");
          $("#pasaporteAtras").attr("src", "data:image/png;base64," + itemBackImage.Value);
          // bcstorage.imgBackBase64 = itemBackImage.Value;
        } else {
          this.storageService.bcStorage.imagenAtras = false;
          this.storageService.bcStorage.pasaporteAtras = "";
        }

        if (itemGivenName != null && itemGivenName != "") {
          this.storageService.bcStorage.nombrePasaporte = itemGivenName.Value;
        }
        if (itemSurname != null && itemSurname != "") {
          this.storageService.bcStorage.apellidosPasaporte = itemSurname.Value;
        }
        if (itemVIZBirthDate != null && itemVIZBirthDate != "") {
          this.storageService.bcStorage.fehaNacimientoPasaporte = itemVIZBirthDate.Value;
        } else if (itemVIBirthDate != null && itemVIBirthDate != "") {
          this.storageService.bcStorage.fehaNacimientoPasaporte = itemVIBirthDate.Value;
        } else if (itemBirthDate != null && itemBirthDate != "") {
          this.storageService.bcStorage.fehaNacimientoPasaporte = itemBirthDate.Value;
        } else {
          this.storageService.bcStorage.fehaNacimientoPasaporte = "";
        }

        if (itemVIZBirthPlace != null && itemVIZBirthPlace != "") {
          this.storageService.bcStorage.entidadNacimiento = itemVIZBirthPlace.Value;
        } else if (itemBirthPlace != null && itemBirthPlace != "") {
          this.storageService.bcStorage.entidadNacimiento = itemBirthPlace.Value;
        } else {
          this.storageService.bcStorage.entidadNacimiento = "";
        }

        if (this.storageService.bcStorage.entidadNacimiento != "") {
          // mapear el catálogo
          let itemCatalogo!: EstadosRenapoModel | undefined;
          const entidadNacimientoSinAcentos = unorm.nfd(this.storageService.bcStorage?.entidadNacimiento).replace(/[\u0300-\u036f]/g, "").toUpperCase();
          itemCatalogo = this.catalogosService.estadosRenapo.find(value => value.nombre === entidadNacimientoSinAcentos);
          if (itemCatalogo == undefined || itemCatalogo == null) {
            itemCatalogo = this.catalogosService.estadosRenapo.find(value => value.nombre.replace(/[^A-Z0-9]+/gi, "") === entidadNacimientoSinAcentos.replace(/[^A-Z0-9]+/gi, ""));
          }
          if (itemCatalogo != undefined && itemCatalogo != null) {
            this.storageService.bcStorage.entidadNacimiento = itemCatalogo.value;
          }
        }

        if (this.storageService.bcStorage.fehaNacimientoPasaporte != null && this.storageService.bcStorage.fehaNacimientoPasaporte != "" && /-/ig.test(this.storageService.bcStorage.fehaNacimientoPasaporte)) {
          const arrayFecha = this.storageService.bcStorage.fehaNacimientoPasaporte.split('-');
          this.storageService.bcStorage.dia = arrayFecha[0];
          this.storageService.bcStorage.mes = arrayFecha[1];
          this.storageService.bcStorage.ano = arrayFecha[2];
        }

        if (itemDocumentNumber != null && itemDocumentNumber != "") {
          this.storageService.bcStorage.numeroPasaporte = (itemDocumentNumber != null && itemDocumentNumber != "") ? itemDocumentNumber.Value : '';
        }
        if (itemVINationalityCode != null && itemVINationalityCode != "") {
          this.storageService.bcStorage.nacionalidadCode = (itemVINationalityCode != null && itemVINationalityCode != "") ? itemVINationalityCode.Value : '';
        }
        if (itemPersonalNumber != null && itemPersonalNumber != "" && (this.storageService.bcStorage.nacionalidadCode == "MEX" || itemPersonalNumber.Value.length == 18)) {
          this.storageService.bcStorage.curp = (itemPersonalNumber != null && itemPersonalNumber != "" &&
            (this.storageService.bcStorage.nacionalidadCode == "MEX" || itemPersonalNumber.Value.length == 18)) ? itemPersonalNumber.Value : '';
        }
        if (itemSex != null && itemSex != "") {
          this.storageService.bcStorage.sexo = (itemSex != null && itemSex != "") ? itemSex.Value.indexOf("M") != -1 ? "H" : "M" : undefined;
        }
        this.storageService.bcStorage.apellidoP = this.storageService.bcStorage.apellidosPasaporte;
        this.storageService.bcStorage.apellidoM = "";

        if (this.storageService.bcStorage.apellidosPasaporte != "") {
          let posInicioSegundoApellido;
          try {
            posInicioSegundoApellido = 0;
            let caracterEspaciador = " ";
            if (this.storageService.bcStorage.apellidosPasaporte?.indexOf("^") !== -1) {
              caracterEspaciador = "^";
            }
            if (this.storageService.bcStorage.curp != "") {
              // Obtiene el apellido paterno con la letra de la curp correspondiente a la inicial del segundo apellido
              let terceraLetraCurp = this.storageService.bcStorage?.curp?.substr(2, 1);
              posInicioSegundoApellido = this.storageService.bcStorage?.apellidosPasaporte?.lastIndexOf(caracterEspaciador + terceraLetraCurp);
            } else {
              // Obtiene el apellido paterno conm el ultimo espacio
              posInicioSegundoApellido = this.storageService.bcStorage?.apellidosPasaporte?.lastIndexOf(caracterEspaciador);
            }
            if (posInicioSegundoApellido !== undefined && posInicioSegundoApellido >= 0) {
              this.storageService.bcStorage.apellidoP = this.storageService.bcStorage?.apellidosPasaporte?.substr(0, posInicioSegundoApellido).trim();
              this.storageService.bcStorage.apellidoM = this.storageService.bcStorage?.apellidosPasaporte?.substr(posInicioSegundoApellido, this.storageService.bcStorage.apellidosPasaporte.length - 1).trim();
            }
          } catch (errorApellidos) {
          }
        }

        this.storageService.bcStorage.apellidoP = this.storageService.bcStorage?.apellidoP?.replace(/^\^+/, '').replace(/\^+$/, '').trim();
        this.storageService.bcStorage.apellidoM = this.storageService.bcStorage?.apellidoM?.replace(/^\^+/, '').replace(/\^+$/, '').trim();

        //ADD NEW VALUES
        if (itemFolioNumber != null && itemFolioNumber != "") {
          this.storageService.bcStorage.folioNumber = itemFolioNumber.Value;
        } else {
          this.storageService.bcStorage.folioNumber = "";
        }
        if (itemObservations != null && itemObservations != "") {
          this.storageService.bcStorage.Observacion = itemObservations.Value;
        } else {
          this.storageService.bcStorage.Observacion = "";
        }
        if (itemEstatusListaNegra != null && itemEstatusListaNegra != "") {
          this.storageService.bcStorage.EstatusListaNegra = itemEstatusListaNegra.Value;
        } else {
          this.storageService.bcStorage.EstatusListaNegra = "";
        }

        if (itemExpiditionDate != null && itemExpiditionDate != "")
          this.storageService.bcStorage.vigencia = itemExpiditionDate.Value;
        if (itemExpirationDate != null && itemExpirationDate != "")
          this.storageService.bcStorage.expedicion = itemExpirationDate.Value;
        if (itemMRZ != null && itemMRZ != "")
          this.storageService.bcStorage.mrz = itemMRZ.Value;
        if (itemDocumentSeries != null && itemDocumentSeries != "")
          this.storageService.bcStorage.DocumentSeries = itemDocumentSeries.Value;
        if (itemOCR != null && itemOCR != "")
          this.storageService.bcStorage.ocr = itemOCR.Value;

        // se oculta DIV para segunda imagen en pasaportes extranjeros
        if (this.storageService.bcStorage.nacionalidadCode != 'MEX') {
          $("#dvVueltaPasaporte").hide();
          $("#dvPasaporteB").hide(); //verificar variable
        }
        break;

      default:
        break;
    }
  }

  public controlErrores(escanerRespuesta: any, documento: number) {
    let respuesta: RespuestaControlErroresModel = { //Es lo que regresaremos para imprimirlo en el front
      mensajeError: '',
      mensajeErrorLegible: '',
      msjBoton: ''
    };
    let documentoEsperadado = '';//Nos dice en que flujo esta 1)INE/IFE 2)FM 3)Pasaporte
    let mensajeDocumentoEsperado = '';//Nos ayuda como variable auxiliar para los mensajes de error
    let mensajeDocumentoEscaneado = '';//Nos ayuda como variable auxiliar para los mensajes de error
    let mensajeEscaneadoa = 'escaneada';//Nos ayuda como variable auxiliar para los mensajes de error
    let imgDocumentoSrc = '';
    let claseDocumento = ''; // en el proyecto no estaba declarada antes de usarse
    //Guardamos que tipo de documento vamos a trabajar
    switch (documento) {
      case 1:
        documentoEsperadado = 'Voter Identification';
        mensajeDocumentoEsperado = 'una credencial para votar';
        mensajeDocumentoEscaneado = 'la credencial para votar';
        break;
      case 2:
        documentoEsperadado = 'Documento de residencia';
        mensajeDocumentoEsperado = 'una forma migratoria';
        mensajeDocumentoEscaneado = 'la forma migratoria';
        break;
      case 3:
        documentoEsperadado = 'Pasaporte';
        mensajeDocumentoEsperado = 'un pasaporte';
        mensajeDocumentoEscaneado = 'el pasaporte';
        mensajeEscaneadoa = 'escaneado';
        imgDocumentoSrc = 'img/pasaporte.png';
        break;
      default:
        documentoEsperadado = 'Desconocido';
        mensajeDocumentoEsperado = 'una credencial para votar';
        mensajeDocumentoEscaneado = 'la credencial para votar';
        break;
    }

    let identificacionIncorrecta = ` Identificación incorrecta.
          Para continuar con la validación favor de proporcionar ${mensajeDocumentoEsperado}. `;

    const errorVigencia = `
          Indica al cliente que la identificación no está vigente
          que es importante que actualice su identificación
          para realizar cualquier trámite con el banco.`;

    var errorGenerico = `
          Muestra una actitud amable con el cliente y coméntale que ${mensajeDocumentoEscaneado} ${mensajeEscaneadoa}
          no ha cumplido con los candados de seguridad establecidos, por lo que no podrás llevar a cabo el proceso.`;

    if (escanerRespuesta) {
      if (escanerRespuesta.Success) {
        switch (escanerRespuesta.Message) {
          case 'Debe escanear ambos lados de la identificación':
          case 'Voltear documento':
            respuesta.mensajeError = escanerRespuesta.Message;
            if (claseDocumento == 'Pasaporte') {
              respuesta.mensajeError = identificacionIncorrecta;
              respuesta.mensajeErrorLegible = "Identificación incorrecta";
            }
            respuesta.msjBoton = 'Repetir';
            break;
          case 'Identificación no detectada.':
            respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
            respuesta.mensajeErrorLegible = "Identificación incorrecta";
            respuesta.msjBoton = 'Repetir';
            break;
          case null:
          default:
            claseDocumento = escanerRespuesta.ClassName;
            let values = escanerRespuesta.Values;
            if (claseDocumento == undefined || claseDocumento == null || claseDocumento == "" || values == undefined || values == null || values.length <= 0) {
              respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
              respuesta.mensajeErrorLegible = "Identificación incorrecta";
              respuesta.msjBoton = 'Repetir';
              break;
            }
            let documentoCaducado = false;
            let vigencia = '';
            values.forEach((v: any, i: number) => { // Esto es para la clave de lector de INE
              // vigencia
              if (v.Name == "VIZ Expiration Date") {
                vigencia = v.Value;
                if (claseDocumento === "Voter Identification") {
                  if (this.limpiarVigencia(v.Value) < (new Date()).getFullYear()) {
                    documentoCaducado = true;
                  }
                } else if (claseDocumento === "Documento de residencia" || claseDocumento === "Pasaporte") {
                  const fechaDeHoy = new Date();
                  const date_regex = /^(0[1-9]|1\d|2\d|3[01])\-(0[1-9]|1[0-2])\-(19\d{2}|2\d{3})$/; // Esta epresion regular revisa que la vigencia tenga el formato correcto
                  // aqui evaluamos que la vigencia sea valida
                  if (date_regex.test(vigencia)) {
                    const fecha = v.Value.split('-');
                    const anioEscan = parseInt(fecha[2]);
                    const mesEscan = parseInt(fecha[1]) - 1;
                    const diaEscan = parseInt(fecha[0]);
                    const vigenciafecha = new Date(anioEscan, mesEscan, diaEscan);
                    documentoCaducado = vigenciafecha < fechaDeHoy && true;
                  }
                }
              }
            });

            switch (claseDocumento) {
              case 'Documento de residencia':
              case 'Pasaporte':
              case 'Voter Identification':
                if (documentoEsperadado == claseDocumento) {
                  //Checamos la vigencia del FM o si es Documento falso
                  if (documentoCaducado) {
                    respuesta.mensajeError = errorVigencia;
                    respuesta.mensajeErrorLegible = "La identificación no está vigente";
                    respuesta.msjBoton = 'Finalizar';
                  } else {
                    respuesta.mensajeError = errorGenerico;
                    respuesta.mensajeErrorLegible = escanerRespuesta.Message;
                    respuesta.msjBoton = 'Finalizar';
                  }
                } else {
                  if (documentoEsperadado == 'Documento de residencia' && claseDocumento == 'Voter Identification') {
                    //Checamos la vigencia del FM o si es Documento falso
                    if (documentoCaducado) {
                      respuesta.mensajeError = errorVigencia;
                      respuesta.mensajeErrorLegible = "La identificación no está vigente";
                      respuesta.msjBoton = 'Finalizar';
                    } else {
                      if (escanerRespuesta.Message == 'DocumentoErroneo') {
                        respuesta.mensajeError = identificacionIncorrecta;
                        respuesta.mensajeErrorLegible = "Identificación incorrecta";
                        respuesta.msjBoton = 'Repetir';
                      } else {
                        respuesta.mensajeError = errorGenerico;
                        respuesta.mensajeErrorLegible = escanerRespuesta.Message;
                        respuesta.msjBoton = 'Finalizar';
                      }
                    }
                  } else {
                    respuesta.mensajeError = identificacionIncorrecta;
                    respuesta.mensajeErrorLegible = "Identificación incorrecta";
                    respuesta.msjBoton = 'Repetir';
                  }
                }
                break;
              case 'Desconocido':
                respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
                respuesta.mensajeErrorLegible = "Identificación incorrecta";
                respuesta.msjBoton = 'Repetir';
                break;
              default:
                respuesta.msjBoton = 'Repetir';
                if (escanerRespuesta.Message == 'DocumentoErroneo') {
                  respuesta.mensajeError = identificacionIncorrecta;
                  respuesta.mensajeErrorLegible = "Identificación incorrecta";
                } else {
                  respuesta.mensajeError = escanerRespuesta.Message;
                  respuesta.mensajeErrorLegible = respuesta.mensajeError;
                }
                break;
            }
            break;
        }
      } else { // repuesta no success
        switch (escanerRespuesta.Message) {
          case 'Debe escanear ambos lados de la identificación':
          case 'Voltear documento':
            respuesta.mensajeError = escanerRespuesta.Message;
            if (claseDocumento == 'Pasaporte' || documento == 3) {
              respuesta.mensajeError = identificacionIncorrecta;
              respuesta.mensajeErrorLegible = "Identificación incorrecta";
            }
            respuesta.mensajeErrorLegible = escanerRespuesta.Message;
            respuesta.msjBoton = 'Repetir';
            break;
          case 'Identificación no detectada.':
          case 'Undefined':
            respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
            respuesta.mensajeErrorLegible = "Identificación no detectada";
            respuesta.msjBoton = 'Repetir';
            break;
          case 'Ha excedido el tiempo de espera del dispositivo.':
            respuesta.mensajeError = escanerRespuesta.Message;
            respuesta.mensajeErrorLegible = escanerRespuesta.Message;
            respuesta.msjBoton = 'Repetir';
            break;
          case null:
            respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
            respuesta.mensajeErrorLegible = "Identificación incorrecta";
            respuesta.msjBoton = 'Repetir';
            break;
          default:
            respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
            respuesta.mensajeErrorLegible = "Error interno: " + escanerRespuesta.Message;
            respuesta.msjBoton = 'Repetir';
            break;
        }
      }
    } else { // no hay respuesta del escaner
      respuesta.mensajeError = 'Por favor vuelva a escanear ' + mensajeDocumentoEscaneado;
      respuesta.mensajeErrorLegible = "Identificación incorrecta";
      respuesta.msjBoton = 'Repetir';
    }

    return respuesta;
  }

  public limpiarVigencia(fecha: any) {
    let fechas = [];
    if (!fecha) {
      return '';
    }
    fechas = fecha.split("-");
    return fechas[fechas.length - 1];
  }


}
