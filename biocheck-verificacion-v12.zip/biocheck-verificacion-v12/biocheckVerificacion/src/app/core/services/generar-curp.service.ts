import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GenerarCurpService {

  constructor() { }

  public primerVocalInternaRgx = /^.(?:[B-DF-HJ-NP-TV-ZÑ]*)([^B-DF-HJ-NP-TV-ZÑ]{1}).*$/;
  public  ultimaConsonanteRgx = /([B-DF-HJ-NP-TV-ZÑ]{1})(?:[^B-DF-HJ-NP-TV-ZÑ]*)$/;
  public primerConsonanteInternaRgx = /^.(?:[^B-DF-HJ-NP-TV-ZÑ]*)([B-DF-HJ-NP-TV-ZÑ]{1})/;
  public caracteresEspecialesRgx = /(?:[^A-Z]|[Ñ])/;

  bccurp(){

    const primerVocalInternaRgx = /^.(?:[B-DF-HJ-NP-TV-ZÑ]*)([^B-DF-HJ-NP-TV-ZÑ]{1}).*$/;
    const ultimaConsonanteRgx = /([B-DF-HJ-NP-TV-ZÑ]{1})(?:[^B-DF-HJ-NP-TV-ZÑ]*)$/;
    const primerConsonanteInternaRgx = /^.(?:[^B-DF-HJ-NP-TV-ZÑ]*)([B-DF-HJ-NP-TV-ZÑ]{1})/;
    const caracteresEspecialesRgx = /(?:[^A-Z]|[Ñ])/;

  }


   reemplazarCaracteres(letra:string) {
    if (letra.match(this.caracteresEspecialesRgx)) {
      letra = 'X';
    }
    return letra;
  }

  matchOrDefault(string:string, regex:any, def:string) {
    if (string == '') {
      return def;
    }
    var match = null;
    if ((match = string.match(regex))) {
      return match[1];
    }
    return def;
  }

  esPrimerNombreValido(string:string) {

    var listaPrimerNombreInvalido = ['MARIA', 'MA.', 'MA', 'JOSE', 'J', 'J.', 'DA', 'DAS', 'DE', 'DEL', 'DER', 'DI', 'DIE', 'DD', 'EL', 'LA', 'LOS', 'LAS', 'LE', 'LES', 'MAC', 'MC', 'VAN', 'VON', 'Y'];

    var valido: boolean = true;

    listaPrimerNombreInvalido.forEach(function (n) {

      if (string == n) {
        valido = false;
        return;
      }
    });

    return valido;
  };

  primerNombreValido(string: string) {
    var chunks = string.split(/\s/);

    if (chunks.length == 1) {
      return string;
    }

    for (var i = 0; i < chunks.length; i++) {
      if (this.esPrimerNombreValido(chunks[i])) {
        return chunks[i];
      }
    }
    return null;
  };

  letraInicial(string:string) {
    if (string == '') {
      return 'X';
    }
    return string[0];
  };

  pad(str:string) {

    str += '';
    if (str.length == 1) {
      str = '0' + str;
    }
    return str;
  };

  limpiar(string:any) {
    string = string.toUpperCase();
    string = string.replace('Ü', 'U');
    string = this.primerNombreValido(string);

    return string;
  };

  replaceCharacterAt(original:string, index: number, replace: string) {

    return original.substring(0, index) + replace + original.substring(index + 1);
  };

  limpiarAltizonante(curp: string) {

    var palabrasInconvenientes = ['BACA', 'BAKA', 'BUEI', 'BUEY', 'CACA', 'CACO', 'CAGA', 'CAGO', 'COGI', 'COJA', 'COJE', 'COJI', 'COJO', 'COLA', 'CULO', 'FALO', 'FETO', 'GETA', 'GUEI', 'GUEY', 'JETA', 'JOTO', 'KACA', 'KACO', 'KAGA', 'KAGO', 'KAKA', 'KAKO', 'KOGE', 'KOGI', 'KOJA', 'KOJE', 'KOJI', 'KOJO', 'KOLA', 'KULO', 'LILO', 'LOCA', 'LOCO', 'LOKA', 'LOKO', 'MAME', 'MAMO', 'MEAR', 'MEAS', 'MEON', 'MIAR', 'MION', 'MOCO', 'MOKO', 'MULA', 'MULO', 'NACA', 'NACO', 'PEDA', 'PEDO', 'PENE', 'PIPI', 'PITO', 'POPO', 'PUTA', 'PUTO', 'QULO', 'RATA', 'ROBA', 'ROBE', 'ROBO', 'RUIN', 'SENO', 'TETA', 'VACA', 'CAGA', 'VAGO', 'VAKA', 'VUEI', 'VUEY', 'WUEI', 'WUEY'];
    palabrasInconvenientes.forEach((palabraInc: string) => {
      if (curp == palabraInc) {
        curp =  this.replaceCharacterAt(curp, 1, 'X');
        return;
      }
    });
    return curp;
  };

  identificadorEntidadFederativa(entidad: any) {

    entidad = entidad || 'AGUASCALIENTES';

    entidad = entidad.toUpperCase();
    entidad = entidad.replace('Á', 'A');
    entidad = entidad.replace('É', 'E');
    entidad = entidad.replace('Í', 'I');
    entidad = entidad.replace('Ó', 'O');
    entidad = entidad.replace('Ú', 'U');

    var clavesEstados = {
      'AGUASCALIENTES': 'AS',
      'MORELOS': 'MS',
      'BAJA CALIFORNIA': 'BC',
      'NAYARIT': 'NT',
      'BAJA CALIFORNIA SUR': 'BS',
      'NUEVO LEON': 'NL',
      'CAMPECHE': 'CC',
      'OAXACA': 'OC',
      'COAHUILA': 'CL',
      'PUEBLA': 'PL',
      'COLIMA': 'CM',
      'QUERETARO': 'QT',
      'CHIAPAS': 'CS',
      'QUINTANA ROO': 'QR',
      'CHIHUAHUA': 'CH',
      'SAN LUIS POTOSI': 'SP',
      'DISTRITO FEDERAL': 'DF',
      'SINALOA': 'SL',
      'DURANGO': 'DG',
      'SONORA': 'SR',
      'GUANAJUATO': 'GT',
      'TABASCO': 'TC',
      'GUERRERO': 'GR',
      'TAMAULIPAS': 'TS',
      'HIDALGO': 'HG',
      'TLAXCALA': 'TL',
      'JALISCO': 'JC',
      'VERACRUZ': 'VZ',
      'ESTADO DE MEXICO': 'MC',
      'YUCATAN': 'YN',
      'MICHOACAN': 'MN',
      'ZACATECAS': 'ZS',
      'NACIDO EN EL EXTRANJERO': 'NE'
    };

    // @ts-ignore
    return clavesEstados[entidad];
  };

  calcularHomoclave(c:string) {
    //Está función fue tomada del script que se carga en el sitio
    //s://consultas.curp.gob.mx/CurpSP/gobmx/inicio.jsp
    //
    //Existe un bug, ya que no diferencia entre A y 0 (cero) en el
    //primer dígito de verificación v.g. AX = 0X
    //
    //Mayo de 2018

    var segRaiz = c.substring(0, 17),
      chrCaracter = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ",
      intFactor = new Array(17),
      lngSuma = 0.0,
      lngDigito = 0.0;

    for (var i = 0; i < 17; i++) {
      for (var j = 0; j < 37; j++) {
        if (segRaiz.substring(i, i + 1) == chrCaracter.substring(j, j + 1)) {
          intFactor[i] = j;
        }
      }

    }
    for (var k = 0; k < 17; k++) {

      lngSuma = lngSuma + ((intFactor[k]) * (18 - k));
    }

    lngDigito = (10 - (lngSuma % 10));
    if (lngDigito == 10) {
      lngDigito = 0;
    }

    return lngDigito;
  };

  identificadorDeSiglo(ano: number) {
    //El penúltimo dígito de la CURP es llamado identificador de sigo
    //Tiene un valor de 0 (cero) si el año de nacimiento es entre 1900 y 1999
    // y de A entre 2000 y 2099
    if (ano < 2000) {
      return '0';
    }
    return 'A';
  };

//  bccurp = {};

  nombreEstado(idEstado: string) {
    var clavesEstadosInv = {
      'OO': '---- Selecciona Estado ----',
      'AS': 'Aguascalientes',
      'MS': 'Morelos',
      'BC': 'Baja California',
      'NT': 'Nayarit',
      'BS': 'Baja California Sur',
      'NL': 'Nuevo León',
      'CC': 'Campeche',
      'OC': 'Oaxaca',
      'CL': 'Coahuila',
      'PL': 'Puebla',
      'CM': 'Colima',
      'QT': 'Querétaro',
      'CS': 'Chiapas',
      'QR': 'Quintana Roo',
      'CH': 'Chihuahua',
      'SP': 'San Luis Potosí',
      'DF': 'Distrito Federal',
      'SL': 'Sinaloa',
      'DG': 'Durango',
      'SR': 'Sonora',
      'GT': 'Guanajuato',
      'TC': 'Tabasco',
      'GR': 'Guerrero',
      'TS': 'Tamaulipas',
      'HG': 'Hidalgo',
      'TL': 'Tlaxcala',
      'JC': 'Jalisco',
      'VZ': 'Veracruz',
      'MC': 'Estado de México',
      'YN': 'Yucatán',
      'MN': 'Michoacán',
      'ZS': 'Zacatecas',
      'NE': 'Nacido en el extranjero'
    };

    // @ts-ignore
    return clavesEstadosInv[idEstado];

  };

  generar(nombre: string, primerApellido: string,
          segundoApellido: string, ano: number, mes: string, dia: string,
          sexo: string, entidad: string) {

    /*
    En este if nos exige que todos los datos no esten vacios, pero pueden aver nombres sin apellido materno
    if (!(nombre && primerApellido && segundoApellido && ano && mes && dia && sexo && entidad)) {

        return '';
    }
    */

    var curp = '';
    const primerVocalInternaRgx = /^.(?:[B-DF-HJ-NP-TV-ZÑ]*)([^B-DF-HJ-NP-TV-ZÑ]{1}).*$/;


    nombre = this.limpiar(nombre);
    primerApellido = this.limpiar(primerApellido);
    segundoApellido = this.limpiar(segundoApellido);
    sexo = sexo.toUpperCase();
    if (entidad)
      entidad = entidad.toUpperCase();

    //Letra inicial del primer apellido
    curp += this.reemplazarCaracteres(this.letraInicial(primerApellido));
    //Primera vocal interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido,
      primerVocalInternaRgx,
      'X'));
    //Letra inicial del segundo apellido
    curp += this.reemplazarCaracteres(this.letraInicial(segundoApellido));
    //Primera letra del nombre
    curp += this.reemplazarCaracteres(this.letraInicial(nombre));

    //evalúa palabras altizonante
    curp = this.limpiarAltizonante(curp);

    //Dos dígitos del año
    curp += ano.toString(2);
    //Dos dígitos del mes
    curp += this.pad(mes);
    //Dos dígitos del día
    curp += this.pad(dia);
    //el caracter de género
    curp += sexo;

    //Dos letras de la entidad federativa
    curp += this.identificadorEntidadFederativa(entidad);

    //Primer consonante interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerConsonanteInternaRgx, 'X'));
    //Primer consonane interna del segundo apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(segundoApellido, this.primerConsonanteInternaRgx, 'X'));

    //Primer consonane interna del nombre
    curp += this.reemplazarCaracteres(this.matchOrDefault(nombre, this.primerConsonanteInternaRgx, 'X'));

    //Consecutivo
    curp += this.identificadorDeSiglo(ano);

    //Digito verificador
    curp += this.calcularHomoclave(curp);

    return curp;
  };

  generar2(nombre: string, primerApellido: string, segundoApellido:any, ano:any, mes:any, dia:any, sexo:string, entidad:string) {

    /*
    En este if nos exige que todos los datos no esten vacios, pero pueden aver nombres sin apellido materno
    if (!(nombre && primerApellido && segundoApellido && ano && mes && dia && sexo && entidad)) {

        return '';
    }
    */
    var curp = '';

    nombre = this.limpiar(nombre);
    primerApellido = this.limpiar(primerApellido);
    segundoApellido = this.limpiar(segundoApellido);
    sexo = sexo.toUpperCase();
    if (entidad)
      entidad = entidad.toUpperCase();

    //Letra inicial del primer apellido
    curp += this.reemplazarCaracteres(this.letraInicial(primerApellido));
    //Primera vocal interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerVocalInternaRgx, 'X'));
    //Letra inicial del segundo apellido
    curp += this.reemplazarCaracteres(this.letraInicial(segundoApellido));
    //Primera letra del nombre
    curp += this.reemplazarCaracteres(this.letraInicial(nombre));

    //evalúa palabras altizonante
    curp = this.limpiarAltizonante(curp);

    //Dos dígitos del año
    curp += ano.substring(2);
    //Dos dígitos del mes
    curp += this.pad(mes);
    //Dos dígitos del día
    curp += this.pad(dia);
    //el caracter de género
    curp += sexo;

    //Dos letras de la entidad federativa
    curp += entidad;

    //Primer consonante interna del primer apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(primerApellido, this.primerConsonanteInternaRgx, 'X'));
    //Primer consonane interna del segundo apellido
    curp += this.reemplazarCaracteres(this.matchOrDefault(segundoApellido, this.primerConsonanteInternaRgx, 'X'));

    //Primer consonane interna del nombre
    curp += this.reemplazarCaracteres(this.matchOrDefault(nombre, this.primerConsonanteInternaRgx, 'X'));

    //Consecutivo
    curp += this.identificadorDeSiglo(ano);

    //Digito verificador
    curp += this.calcularHomoclave(curp);

    return curp;
  };












}
