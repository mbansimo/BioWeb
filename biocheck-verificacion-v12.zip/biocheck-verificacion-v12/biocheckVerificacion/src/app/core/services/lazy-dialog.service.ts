import { Injectable } from '@angular/core';
import {MatDialog, MatDialogConfig, MatDialogRef} from "@angular/material/dialog";
import {ComponentType} from "@angular/cdk/overlay";
import {VerificacionSimpleComponent} from "../../website/verificacion-simple/verificacion-simple.component";

@Injectable({
  providedIn: 'root'
})
export class LazyDialogService {

  constructor(private dialog: MatDialog) { }

  async openDialog(dialogName:string): Promise<MatDialogRef<any>>{

    const chunk = await import(`../../shared/dialogs/${dialogName}/${dialogName}.component`);
    const dialogComponent = Object.values(chunk)[0] as ComponentType<unknown>;
    return this.dialog.open(dialogComponent);


  }

  showDialogVerificacionSimple() {
    let dialogConfig: MatDialogConfig = new MatDialogConfig();

    dialogConfig.id = 'verificionSimple';
    dialogConfig.role = 'alertdialog';
    dialogConfig.minWidth = '70%';
    dialogConfig.minHeight = '590px';
    dialogConfig.maxHeight = '80%';
    dialogConfig.panelClass = 'myapp-no-padding-dialog'; //se agrego la clase para quitar el espacio del padding externo  en archivo style.scss
    dialogConfig.hasBackdrop = false; //Se ocupa para que no pueda cerrar el dialog dando clic fuera de este


//    dialogConfig.disableClose = true;
//    dialogConfig.panelClass = ['animate__animated','animate__fadeIn'];

    return this.dialog.open(VerificacionSimpleComponent, dialogConfig);
  }



}
