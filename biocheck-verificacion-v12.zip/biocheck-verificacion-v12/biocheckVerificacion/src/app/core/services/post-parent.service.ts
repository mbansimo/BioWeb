import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PostParentService {

  constructor() { }

  postTokenParent() {
    window.parent.postMessage({ event_id: "my_cors_message" }, "*")
  };

  postCancelarConteoller() {
    window.parent.postMessage({ event_id: "my_cors_message" }, "*")
  };

  postAvisoPrivacidad() {
    window.parent.postMessage({ event_id: "my_cors_message" }, "*")
  };

  postFinalizar(e: any) {
    window.parent.postMessage(e, "*")
  };

}
