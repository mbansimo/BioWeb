import { CustomTooltipDirective } from './custom-tooltip.directive';

describe('CustomTooltipDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomTooltipDirective();
    expect(directive).toBeTruthy();
  });
});
