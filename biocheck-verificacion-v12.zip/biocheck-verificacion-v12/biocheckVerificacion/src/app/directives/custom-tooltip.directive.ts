import { Directive, ElementRef, HostListener, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { ComponentType, Overlay, OverlayPositionBuilder, OverlayRef } from "@angular/cdk/overlay";
import { ComponentPortal, TemplatePortal } from "@angular/cdk/portal";

@Directive({ selector: '[customTooltip]' })
export class CustomTooltipDirective {

  @Input('customTooltip')
  tooltipContent!: TemplateRef<any> | ComponentType<any>;

  private _overlayRef!: OverlayRef;

  constructor(
    private overlay: Overlay,
    private overlayPositionBuilder: OverlayPositionBuilder,
    private elementRef: ElementRef,
    private viewContainerRef: ViewContainerRef,
  ) {
  }

  ngOnInit(): void {
    if (this.tooltipContent) {

      const position = this.overlayPositionBuilder

        .flexibleConnectedTo(this.elementRef)

        .withPositions([
          {
            originX: 'center',
            originY: 'bottom',
            overlayX: 'center',
            overlayY: 'top',
            offsetX: 0,
            offsetY: 8,
          },
          {
            originX: 'center',
            originY: 'top',
            overlayX: 'center',
            overlayY: 'bottom',
            offsetX: 0,
            offsetY: 8
          }
        ]);

      this._overlayRef = this.overlay.create({
        positionStrategy: position,
        scrollStrategy: this.overlay.scrollStrategies.close(),
        panelClass: 'custom-tooltip',
      })
    } else {
      console.error('[ERROR] la directiva tiene que recibir el contenido a mostrar...');
    }
  }

  @HostListener('mouseenter')
  private _show(): void {
    // si existe overlay se enlaza con el contenido

    if (this._overlayRef) {
      let containerPortal: TemplatePortal<any> | ComponentPortal<any>;
      //Creacion del template
      if (this.tooltipContent instanceof TemplateRef) {
        containerPortal = new TemplatePortal(this.tooltipContent, this.viewContainerRef);
      }
      // en caso contrario creamos un componentPortal
      else {
        containerPortal = new ComponentPortal(this.tooltipContent, this.viewContainerRef)
      }
      //enlace delportal
      this._overlayRef.attach(containerPortal);
    }
  }

  @HostListener('mouseout')
  private _hide(): void {
    //Si existe un overlay se desenlaza del contenido
    if (this._overlayRef) {
      this._overlayRef.detach();
    }
  }

}
