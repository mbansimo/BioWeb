import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatSliderModule } from '@angular/material/slider';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';

const MaterialModules = [
  MatDialogModule,
  MatSliderModule,
  MatCardModule,
];

const ImportModules = [
  CommonModule,
  ...MaterialModules
];

@NgModule({
  declarations: [],
  imports: ImportModules,
  exports: MaterialModules
})

export class MaterialModule { }
