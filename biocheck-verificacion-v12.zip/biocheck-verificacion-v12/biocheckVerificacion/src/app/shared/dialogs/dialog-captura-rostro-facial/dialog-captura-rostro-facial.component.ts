import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {BcstorageService} from "../../../core/services/bcstorage.service";
import {BiocheckService} from "../../../core/services/biocheck.service";
import {Router} from "@angular/router";
import {UtilDialogs} from "../../../common/util-dialogs";
import {FinalDateModel} from "../../../core/models/final-date.model";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import * as $ from "jquery";
import {BiocheckPasosService} from "../../../core/services/biocheck-pasos.service";
import {DataDialogModel} from "../../../core/models/msg-dialog.model";

;

@Component({
  selector: 'app-dialog-captura-rostro-facial',
  templateUrl: './dialog-captura-rostro-facial.component.html',
  styleUrls: ['./dialog-captura-rostro-facial.component.scss']
})
export class DialogCapturaRostroFacialComponent implements OnInit {

  public label1: string = 'Captura de rostro del cliente';
  public intentosModal: number = 3;
  public labelIntentos: string = 'El cliente tiene ' + this.intentosModal + ' intentos(s)';
  public btnCancelar: string = 'Cancelar';
  public btnCapturar: string = 'Capturar';
  public btnContinuar: string = 'Continuar';
  public btnRepetir: string = 'Repetir';
  public imgIndicador: string = 'assets/img/corchetes.png';
  public imgUsuario: string = 'assets/img/usuario.png';

  public captura: boolean = true;
  public continua: boolean = false;

//  public dialogRef: MatDialogRef<DialogCapturaRostroFacialComponent, any> | undefined;
  public dialogGen: MatDialogRef<any, any> | undefined;


  constructor(
    private bcService: BiocheckService,
    public dialogRef: MatDialogRef<DialogCapturaRostroFacialComponent>,
    private dialogs: UtilDialogs,
    private storageService: BcstorageService,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: DataDialogModel,
  ) {
  }

  ngOnInit(): void {
    console.log(':::: Iniciando Dialog captura Rostro Facial ::::');
    this.getFacialChances();
  }

  iniciarVariables() {
    console.log('reiniciando variables ')
    this.imgIndicador = 'assets/img/corchetes.png';
    this.imgUsuario = 'assets/img/usuario.png';
    this.label1 = 'Captura de rostro del cliente';
    this.continua = false;
    this.captura = true;
    this.bcService.reiniciarshowPreview();
  }

  ngOnDestroy() {
    console.log('________Observable cerrado_______');
//    this.bcService.destruirDialogCapturaUnsubscribe();
  }

  Capturar() {
    console.log('Cap_1');
    console.log('esto es el nombre del proceso ' + this.storageService.bcStorage.nombreProceso)
    if (this.storageService.bcStorage.nombreProceso == 'verifica_ine_facial') {
      console.log('Cap_2:: Verificacion facial');
      this.takePicture();
    } else if (this.storageService.bcStorage.nombreProceso == 'verifica_motor'
      || this.storageService.bcStorage.nombreProceso == 'verificacion_Ine_simple') {
      console.log('Cap_3:: motor');
      this.verificacionFacialMotor()
    }
  }

  verificacionFacialMotor() {
    console.log('VerFaMotor_1');
    this.bcService.verificacionFacialMotor();
    this.bcService.ineFacialMotorResponse();
    this.bcService.ineFacialMotorResponse$.subscribe(response => {
      if (response) {
        console.log('VerFaMotor_2:: Response');
        console.log(response);
//        this.cerrarModal();
//        this.getFinalDate();
        this.pictureTaken();
      }
    })
    console.log('VerFaMotor_3:: Fin');
  }

  getFacialChances() {
    this.bcService.getFacialChances();
    this.bcService.facialChances();
    this.bcService.facialChances$.subscribe(response => {
      console.log('FChances_1:: ' + response)
      if (response) {
        if (response != this.intentosModal) {
          console.log('FChances_1::_intentos::' + this.intentosModal);
          response = this.intentosModal;
        }
        if (response == 0) {
          console.log('FChances_3::');
          this.cerrarModal();
          this.bcService.stopCamera([]);
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = 'EVD05';
          this.storageService.bcStorage.mensajeflujo = 'Proceso no concluido satisfactoriamente';
          this.getFinalDate();
        } else {
          console.log('FChances_2::');
          this.bcService.startCameraPreview();
          this.labelIntentos = 'El cliente tiene ' + response + ' intentos(s)';
          this.showPreviewIne();
        }

      }
    })

  }

  public imgUsuarioCapturada: any;

  showPreviewIne() {
    console.log('ShPreview_1::');
    this.bcService.showPreviewIne();
    this.bcService.showPreviewIne$.subscribe(response => {
      if (response) {
        console.log('ShPreview_2::Response::');
        var img = document.getElementById("video") as HTMLImageElement;
        img.src = "data:image/png;base64," + response;
        if (response != '') {
          console.log('ShPreview_3::Response_imagen');
          this.tomaDeUsuario(response);
        }
        response = "";
      }
    })
  }

  tomaDeUsuario(response: any) {
    this.imgUsuarioCapturada = response;
  }

  takePicture() {
    this.bcService.takePicture([]);
    this.bcService.showPreviewIneCapture();
    this.bcService.showPreviewIneCapture$.subscribe(response => {
      if (response) {
        console.log('showPreview:::' + response);
        var img = document.getElementById("videoTaken") as HTMLImageElement;
//        img.src = "data:image/png;base64," + response;
        if (response != '') {
          console.log('showPreviewIneCapture::Response_imagen');
          this.tomaDeUsuario(response);
        }
        response = "";
        this.bcService.stopCamera([]);
        this.pictureTaken();
      }
    });

  }

  pictureTaken() {
    console.log('PicTaken_1');
    this.label1 = 'Verifica que la captura haya sido correcta, si no, repite el proceso';
    this.continua = true;
    this.captura = false;

    if (this.continua) {
      console.log('PicTaken_1::Imagen');
      this.imgUsuario = "data:image/png;base64," + this.imgUsuarioCapturada;
    }
    console.log('PicTaken_1:: Fin');
  }


  continuar() {
    console.log('Continuar_1')
    this.cerrarModal();
    this.bcService.getTipoVerificacion([]);
    this.bcService.getTipoVerificacion$.subscribe(response => {
      if (response) {
        console.log('Continuar_2::Response ' + response);
        this.bcService.stopCamera([]);
        if (response == "FACIALFULL") {
          this.router.navigateByUrl('escanearRostroIne');
        } else if (response == "FACIALSIMPLE") {
          this.router.navigateByUrl('capturaIdManual');
        } else {
          console.log('Continuar_3::getFinal');
          this.getFinalDate();
        }
      } else if (response == '' && this.storageService.bcStorage.tipoVerificacion == 'verifica_motor') {
        console.log('Continuar_4::getFinal_else');
        this.getFinalDate();
      }
    })
  }

  Repetir() {
    this.intentosModal--;
    this.getFacialChances();
    this.iniciarVariables();
  }


  public cerrarModal() {
    this.dialogGen?.close();
    this.dialogRef?.close();
    console.log('cerramos modales')
  }

  cancelar() {

    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.dialogRef?.close();
        this.bcService.stopCamera([]);
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    console.log('Getfinal_1::');
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        console.log('Getfinal_2::Response:');
        console.log(response);
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.router.navigateByUrl('/finalizar');
  }


  //  escribir en los logs

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "PaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

}
