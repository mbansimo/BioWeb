import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {DataFaceCaptureCheck} from "../../../core/models/msg-dialog.model";
import {BcstorageService} from "../../../core/services/bcstorage.service";
import * as $ from "jquery";
import {BiocheckService} from "../../../core/services/biocheck.service";
import {UtilDialogs} from "../../../common/util-dialogs";
import {MessagesDialogProcesando} from "../../../common/msgs-dialog";
import {FinalDateModel} from "../../../core/models/final-date.model";
import {Router} from "@angular/router";
import {BiocheckErrorService} from "../../../core/services/biocheck.error.service";


@Component({
  selector: 'app-dialog-captura-rostro',
  templateUrl: './dialog-captura-rostro.component.html',
  styleUrls: ['./dialog-captura-rostro.component.scss']
})
export class DialogCapturaRostroComponent implements OnInit {

  public imgUsuario = 'assets/img/usuario.png';
  public botonCancelar: string = 'Cancelar';
  public titulo_1: string = '';

  public imgCara_check = 'assets/img/cara_check.svg';
  public imgBiometrico = 'assets/img/cara_check.svg';

  public verModalPruebaVida: boolean = false;
  public verFaceCaptureCheck: boolean = false;
  public intentoNumero: string = '';

  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    public dialogRef: MatDialogRef<DialogCapturaRostroComponent>,
    private dialogs: UtilDialogs,
    private router: Router,
    private biocheckError: BiocheckErrorService,
    @Inject(MAT_DIALOG_DATA) public data: DataFaceCaptureCheck
  ) {
  }

  ngOnInit(): void {
    console.log('ingreso al dialogo de captura de rostro');
    this.initVariables();
    this.verModal(this.data);
    if (this.storageService.bcStorage.intentosRestantes != null) {
      this.intentoNumero = this.storageService.bcStorage.intentosRestantes;
    }
  }

  initVariables() {
    this.storageService.bcStorage.reintentarFaceCaptureCheck = false;
    this.storageService.bcStorage.continuarFaceCaptureCheck = false;
  }

  public fotoMini: any;

  onCaptureCheck(response: any) {
    this.fotoMini = response;
    //$("#imgCheckmini").css("opacity", "1");
    //var img = document.getElementById("imgCheckmini") as HTMLImageElement;
    //img.src = "data:image/png;base64," + response;
    this.imgUsuario = "data:image/png;base64," + response;

  }


  verModal(data: DataFaceCaptureCheck) {
    if (data.modal == 'PruebaVida') {
      console.log(data);
      this.verModalPruebaVida = true;
      this.imgUsuario = data.imagen;
    } else {
      console.log('verFaceCaptureCheck::::');
      this.onCaptureCheck(data.imagen);
      this.verFaceCaptureCheck = true;
      if (this.data.title != null) {
        this.titulo_1 = this.data.title;
      }
    }
  }

  reintentarFaceCaptureCheck() {
    this.storageService.bcStorage.reintentarFaceCaptureCheck = true;
    this.cerrarModal();
  }

  continuarFaceCaptureCheck() {
    this.storageService.bcStorage.continuarFaceCaptureCheck = true;
    this.cerrarModal();
    //biocheck.sendGtmTag("Paso-4", "Enrolamiento", "Captura-Rostro", "biocheck", "prueba_de_ambiente", "captura_de_rostro", "iniciar_prueba");
    //$scope.capturarRostro();
    let miniface = document.getElementById("miniface") as HTMLImageElement;
    miniface.src = "data:image/png;base64," + this.fotoMini;
//    this.capturarRostro();
  }


  public impedimento: boolean = false;
  public guid: string = '';
  public faceLivenessChances: number = 0; //Contador de intentos de prueba de vida
  public resetearIntentos: boolean = false;

  capturarRostro() {
    this.dialogRef = this.dialogs.showDialogPruebaVida();
    console.log('impedimento:: ' + this.impedimento)
    if (this.impedimento) {
//      $scope.sig(9);
      //$(location).attr('href', '#!escanearife');
    } else {
      if (this.resetearIntentos === undefined || this.resetearIntentos == null) {
        this.resetearIntentos = false;
      }
      if (this.resetearIntentos) {
        this.faceLivenessChances = 0;
      }
      this.bcService.borradoShowPreview();
      this.bcService.getFaceChances([false]);
      this.bcService.faceCapture([this.guid, true]);

      this.showPreview();

    }
  }

  facecrop(response: any) {
    console.log('ingreso a faceCrop::::')
    if (response.code == 0) {
      this.cerrarModal();
//      $('#capturarostro').modal('hide');
      $('.marco').css('box-shadow', 'inset 3px 2px 5px 0 #63BA68');

      var img = document.getElementById("video") as HTMLImageElement;
      img.src = "data:image/png;base64," + response.result;
      response = "";
      console.log('antes de prueba de vida exitosa')
      this.pruebaVidaExitosa();
    }
  }

  showPreview() {
    this.bcService.getshowPreview();
    this.bcService.showPreviewRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('showPreviewRespuesta');
          var img = document.getElementById("Biometrico") as HTMLImageElement;
          img.src = "data:image/png;base64," + response;
          this.imgBiometrico = "data:image/png;base64," + response;
//          response = "";
        }
      }
    });

    this.bcService.getShowInstruction();
    this.bcService.showInstruction$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('showInstruction$')
          this.onShowInstruction(response);
        }
      }
    });

    this.bcService.getFacecrop();
    this.bcService.facecrop$.subscribe({
      next: (response: any) => {
        this.facecrop(response);
      }
    });

  }

  public intentoInstruccion: boolean = false;
  public anteriorInstruccion: string = '';

  onShowInstruction(Instruction: any) {

    if (this.intentoInstruccion === true &&
      this.anteriorInstruccion === Instruction) {
      this.resultadoCaptura(false);
    }
    //Pintamos la instruccion
    switch (Instruction) {
      case "blink":
        $('#instruccion').text(this.numeroInstruccion + ".Parpadeé");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "turnleft":
        $('#instruccion').text(this.numeroInstruccion + ".Volteé a la izquierda y mire al frente");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "turnright":
        $('#instruccion').text(this.numeroInstruccion + ".Volteé a la derecha y mire al frente");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "keepstill":
        $('#instruccion').text(this.numeroInstruccion + ".Mire fijamente la cámara");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "frente":
        $('#instruccion').text(this.numeroInstruccion + ".Mire al frente");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "turndown":
        this.resultadoCaptura(true);//Pintamos en el front el marco de verde y la palabra listo
        if (this.intentoInstruccion)
          this.numeroInstruccion++; //aumentamos el numero para mostrarlo en la siguiente instruccion
        this.intentoInstruccion = false;
        break;
      //case "none":
      //    $('#instruccion').text("No se detecta rostro del cliente");
      //    break;
      default:

        break;
    }

  }

  public numeroInstruccion: number = 1;

  resultadoCaptura(exito: any) {
    if (exito) {
      $('#capturaExitosa').css('color', '#63BA68');// pintamos el texto ¡Listo! de color verde
      $('#capturaExitosa').text('¡Listo!');// Le colocamos el texto
      $('.tamanolgAzul').css('border', '3px solid #63BA68');//pintamos el marco de verde
      if (this.numeroInstruccion == 1) {
        //biocheck.sendGtmTag("Paso-4", "Enrolamiento", "Captura-Rostro", "biocheck", "prueba_de_ambiente", "prueba_vida1", "Listo");
      }
      if (this.numeroInstruccion == 2) {
        //biocheck.sendGtmTag("Paso-4", "Enrolamiento", "Captura-Rostro", "biocheck", "prueba_de_ambiente", "prueba_vida2", "Listo");
      }
    } else {
      $('#capturaExitosa').css('color', '#ec0000');// pintamos el texto ¡Repetir! de color rojo
      $('#capturaExitosa').text('Repetir');// Le colocamos el texto
      $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
    }
    $('.instrucciones').css('visibility', 'visible');
    $('.capturaExitosa').css('visibility', 'visible');
  }//con esta funcion pintamos en el front cuando se tomo correctamente una instruccion o no

  pruebaVidaExitosa() {
    this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatos);
    this.bcService.verify();
    this.bcService.getverifyResponse();
    this.bcService.verifyResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('VerifyResponse:::');
          console.log(response);
          this.verifyResponse(response);

        }
      }
    })
  }

  verifyResponse(response: any) {
    this.cerrarModal();
    //$.connection.hub.stop()
    if (response.code == 0) {
      if (response.result) {
        if (response.result.code === "OK0000") {
          this.storageService.bcStorage.proceso = true;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          //$(location).attr('href', '#!finalizar');
        } else {
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          //$(location).attr('href', '#!finalizar');
        }
      }
    } else {
      if (response.code == 400) {
        var obj = JSON.parse(response.message);
        if (obj.errores)
          if (obj.errores.length > 0) {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = obj.errores[0].code;
            this.storageService.bcStorage.mensajeflujo = obj.errores[0].message;
            this.storageService.bcStorage.mensajeinternoflujo = obj.errores[0].description;
          }
        if (obj.errors)
          if (obj.errors.length > 0) {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = obj.errors[0].code;
            this.storageService.bcStorage.mensajeflujo = obj.errors[0].message;
            this.storageService.bcStorage.mensajeinternoflujo = obj.errors[0].description;
          }
      } else if (response.code == 404) {
        this.storageService.bcStorage.proceso = false;
        this.storageService.bcStorage.codigoflujo = "EVB02";
      } else {
        this.storageService.bcStorage.proceso = false;
        this.storageService.bcStorage.codigoflujo = "EVB00";
      }
    }
    this.getFinalDate();
  };

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.cerrarModal();
    this.bcService.getFinalDate();
    this.bcService.getfinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    console.log('ingreso a onFinalDato');
    this.router.navigateByUrl('/finalizar');
  }


  cerrarModal() {
    console.log('Cierra modales::::')
    this.dialogRef?.close();
//    this.dialogGen?.close();
  }


}
