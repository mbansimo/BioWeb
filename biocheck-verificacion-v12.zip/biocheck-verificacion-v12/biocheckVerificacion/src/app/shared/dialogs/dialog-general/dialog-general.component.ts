import {Component, Inject, OnInit} from '@angular/core';
import {DataDialogModel} from 'src/app/core/models/msg-dialog.model';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {BcstorageService} from "../../../core/services/bcstorage.service";
import {BiocheckService} from "../../../core/services/biocheck.service";
import {Router} from "@angular/router";
import {UtilDialogs} from "../../../common/util-dialogs";
import {FinalDateModel} from "../../../core/models/final-date.model";


@Component({
  selector: 'app-dialog-general',
  templateUrl: './dialog-general.component.html',
  styleUrls: ['./dialog-general.component.scss']
})
export class DialogGeneralComponent implements OnInit {
  imgStd = 'assets/img/santander.png';
  imgWarn = 'assets/img/advertencia.png';
  imgIne = 'assets/img/INE(Front).png';
  errorDispositivo = 'assets/img/error/lector_conexion.png';
  botonCancelar = 'Cancelar';
  verGeneral: boolean = false;
  verComprobacion: boolean = false;
  verSimple: boolean = false;
  verEscaneo: boolean = false;
  verImgIne: boolean = false;
  verWarn: boolean = true;
  tituloError200: string = 'El tiempo para realizar la captura se ha excedido, por favor repítela';


  public dialogGen: MatDialogRef<any, any> | undefined;

  constructor(
    private bcService: BiocheckService,
    private router: Router,
    private storageService: BcstorageService,
    private dialogs: UtilDialogs,
    public dialogRef: MatDialogRef<DialogGeneralComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DataDialogModel
  ) {
  }

  ngOnInit(): void {
    this.tipoError(this.data);
    console.log('DATA =>', this.data);
  }

  tipoError(data: DataDialogModel) {

    this.imagenErrorFlujo();
    if (data.labelButton == 'Repetir') {
      this.verGeneral = false;
      this.verComprobacion = true;
    } else {
      this.verGeneral = true;
      this.verComprobacion = false;
    }
    //Logica en Boton cancelar
    if (data.labelButton == 'Si') {
      this.botonCancelar = 'No';
    }
    //Error 200
    if (this.tituloError200 == data.message
      || this.storageService.bcStorage.codigoflujo == 'EOB00') {
      this.verGeneral = false;
      this.verComprobacion = false;
      this.verSimple = true;
    }
    if (data.labelButton == 'Finalizar') {
      this.verGeneral = false;
      this.verComprobacion = false;
      this.verSimple = true;
    }
  }

  imagenErrorFlujo() {
    let codigo = this.storageService.bcStorage.codigoflujo;
    if (codigo == '320') {
      this.errorDispositivo = 'assets/img/error/lector_conexion.png';
      this.verWarn = true;
    }
    console.log(codigo)
    codigo = this.storageService.bcStorage.codigoImagenFlujo;
    if (codigo == 'E0001'){
      this.errorDispositivo = '';
      this.verWarn = false;
    }
    if (codigo == 'LS001'){
      this.errorDispositivo = '';
    }
    console.log('codigoError'+ codigo);
  }

  cancelar() {
//    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    console.log(data);
    this.cerrarDailogs();

    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    if (data.trasaction != '') {
      this.storageService.bcStorage.foliopros = data.trasaction;
    } else {
      this.storageService.bcStorage.foliopros = data.trasaction == null ? '-' : '-';
    }
    this.router.navigateByUrl('finalizar');
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  cerrarDailogs() {
    this.dialogRef?.close();
    this.dialogGen?.close();
  }

}
