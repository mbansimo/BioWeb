import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogHuellasComponent } from './dialog-huellas.component';

describe('DialogHuellasComponent', () => {
  let component: DialogHuellasComponent;
  let fixture: ComponentFixture<DialogHuellasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DialogHuellasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogHuellasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
