import {Component, NgZone, Inject, OnInit} from '@angular/core';
import {DataDialogModel} from 'src/app/core/models/msg-dialog.model';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {BcstorageService} from "../../../core/services/bcstorage.service";
import {FinalDateModel} from 'src/app/core/models/final-date.model';
import {BiocheckService} from 'src/app/core/services/biocheck.service';
import {UtilDialogs} from 'src/app/common/util-dialogs';
import {Router} from '@angular/router';
import {PostParentService} from 'src/app/core/services/post-parent.service';
import {MessagesDialogProcesando} from 'src/app/common/msgs-dialog';
import {Errors} from 'src/app/enums/errors.msg';
import {BiocheckErrorService} from 'src/app/core/services/biocheck.error.service';
//import { setTimeout } from 'timers';
import {BiocheckUtils} from 'src/app/core/services/biocheck-utils.service';


@Component({
  selector: 'app-dialog-huellas',
  templateUrl: './dialog-huellas.component.html',
  styleUrls: ['./dialog-huellas.component.css']
})
export class DialogHuellasComponent implements OnInit {
  public tituloInstruccion: string = "Verificar índice derecho";
  public dedoImg = 'assets/img/combinaciones/2.png';
  public idImg?: string;

  public verCancelar: boolean = true;//Muestra u oculta el boton cancelar
  public verVerificar: boolean = true;//Muestra u oculta el boton de verificar
  //public instruccion: string = ''; //Instruccion que se mostrara en la cabecera y modal
  public intentosCapturaHuella: number = 3; //Intentos para capturar la huella
  public intentosVerificar: string = "El cliente tiene 3 intentos"; //Intentos para verificar la huella

  public guid: string = ''; // Se envia al servicio
  public dedos: any[] = []; //Lista de dedos enrolados
  public dedosManoDerechaPrincipales: any[] = []; //Dedos disponibles para la mano derecha principales
  public dedosManoIzquierdaPrincipales: any[] = [];//Dedos disponibles para la mano izquierda principales
  public dedosManoDerechaOpcional: any[] = []; //Dedos disponibles para la mano derecha opcionales
  public dedosManoIzquierdaOpcional: any[] = [];//Dedos disponibles para la mano izquierda opcionales
  // bcstorage.esEjecutivo = getParameterByName('isPreVerif') == "true"; //Indica si se está realizando una preverificación
  public mano: number = 0; //1)mano derecha 2)Mano izquierda 0)Mano sin definir
  public dedoEnviar: number = 0; //Es el dedo que enviaremos a verificar
  public arrayIntentoHuellas: any[] = [];

  //Elementos del DOM
  public versionComercial: string = '';
  public versionInstalador: string = '';
  public statusCaptura: string = '';  //Captura exitosa  o no exitosa
  public marcoHuella: string = ''; //Marco que cambia de color dependiendo la captura
  public procesando: string = 'Captura huellas';  //Modal de procesando
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public dedoSelec = $('#dedoSelec');//Imagen de la huella seleccionada
  public dialogRef: MatDialogRef<any, any> | undefined;
  public dialogGen: MatDialogRef<any, any> | undefined;
  //public dialogFingerRef: MatDialogRef<any, any> | undefined;

  public ArrayAusenciasSelect = [0, 2, 0, 0, 0, 0, 7, 0, 0, 0];
  public intentosModal?: string;
  public FingerNeuro: number = 0;
  public Position: any[] = [];
  public ArrayAusencias = [];
  public winPros = null;
  public intentosINE: number = 3;
  public contadorIzquierdo: number = 0;
  public contadorDerecho: number = 0;
  public GetTwoFingers: boolean = false;
  public fingerCapturesCount: number = 0;

  public tieneApMat = (this.storageService.bcStorage.apicApellidoM) ? true : false;
  public tieneApPat = (this.storageService.bcStorage.apicApellidoP) ? true : false;
  public isCIC?: boolean = false;
  public contAusencias: number = 0;
  public EstatusCaptura: string = "";


  constructor(
    private bcService: BiocheckService,
    private dialogs: UtilDialogs,
    private router: Router,
    private postParentService: PostParentService,
    private storageService: BcstorageService,
    private biocheckError: BiocheckErrorService,
    public dialogFingerRef: MatDialogRef<DialogHuellasComponent, any>,
    private zone: NgZone,
    private Utils: BiocheckUtils,
    //@Inject(MAT_DIALOG_DATA) public data: null
  ) {
  }

  ngOnInit(): void {
    $('#exitosa').css('color', 'white');
    $('.marcoHuella').css('border-color', '  #DEEDF2');
    this.storageService.bcStorage.esEjecutivo = this.getParameterByName('isPreVerif') == "true";
    this.consultaInit();
  }

  consultaInit() {
    this.mostrarVista();
  }

  public mostrarVista() {
    this.Utils.cambiarPaso(2, "Capturar huellas");
    for (var pos6 = 1; pos6 < 11; pos6++) {
      this.clickFunction(pos6);
    }
    this.startSignalR();
  }

  startSignalR() {
    this.isCIC = this.storageService.bcStorage.esINE;
    this.ArrayAusenciasSelect = [0, 2, 0, 0, 0, 0, 7, 0, 0, 0];
    this.capturarHuellas();
  }

  capturarHuellas() {
    this.bcService.getfingerChances();
    this.bcService.fingerChances();
    this.bcService.fingerChancesRespuesta$.subscribe(response => {
      if (response) {
        this.fingerChances(response.intentos);
      }
    });
  }

  fingerChances(intentos: number) {
    if (intentos == 0) {
      this.storageService.bcStorage.proceso = false;
      this.storageService.bcStorage.codigoflujo = "EOB00";
      this.storageService.bcStorage.mensajeflujo = "Proceso no concluido satisfactoriamente";
      this.Utils.getFinalDate();
    } else {
      this.intentosModal = "El cliente tiene " + intentos + " intento(s)";
      var flag = true;
      this.indices();//revisar no hace nada
      var resder = this.ArrayAusenciasSelect[1] + '' + this.ArrayAusenciasSelect[2] + '' + this.ArrayAusenciasSelect[3] + '' + this.ArrayAusenciasSelect[4];
      this.FingerNeuro = 0;

      switch (resder) {
        case '2000':
          var obj = [2];
          this.Position = obj;
          this.tituloInstruccion = "Verificar índice derecho";
          this.dedoImg = 'assets/img/combinaciones/2.png';
          this.storageService.bcStorage.fingerCapture = 2;
          this.FingerNeuro = 2;
          this.idImg = "Id" + 2;
          // this.Position = [2];
          break;
        case '0000':
          var resizq = this.ArrayAusenciasSelect[6] + '' + this.ArrayAusenciasSelect[7] + '' + this.ArrayAusenciasSelect[8] + '' + this.ArrayAusenciasSelect[9];
          switch (resizq) {
            case '7000':
              var obj = [7];
              this.Position = obj;
              this.tituloInstruccion = "Verificar índice izquierdo";
              this.dedoImg = 'assets/img/combinaciones/18.png';
              // this.instruccion('índice izquierdo', '18');
              this.FingerNeuro = 7;
              this.Position = [7];
              this.idImg = "Id" + 7;
              break;
            default:
              break;
          }

          break;
        default:
          break;

      }
    }

  }

  indices() {
    // var elem2 = document.querySelector('.js-switch3');
    // var switchery = new switchery(elem2, {
    //   size: 'small',
    //   jackColor: '#eC0000',
    //   color: '#800000',
    //   secondaryColor: '#c2c2c2',
    //   jackSecondaryColor: '#ffffff'
    // });
    // var changeCheckbox = document.querySelector('.js-switch3');
  }

  dialogCapturaHuella(dedo: any, img: any) {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCaupturaHuellas(dedo, img);
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {

        }
      }
    );
  }

  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.dialogFingerRef.close();
    this.Utils.getFinalDate();
  };

  public captura = false;

  capturar() {
    if (this.showPreviewObser != undefined) {
      this.showPreviewObser.unsubscribe();
      //this.showPreviewObser.closed();
    }
    if (this.loadingObservable != undefined) {
      //this.loadingObservable.unsubscribe();
      // this.loadingObservable.closed();
    }
    if (this.captura) {
      console.log('ingreso a capturar')
      this.captura = false;
      // huellas.close(); va cerrar el modal
      for (var pos11 = 0; pos11 < this.Position.length; pos11++) {
        this.ArrayAusenciasSelect[this.Position[pos11] - 1] = 0;
      }
      this.capturarHuellas();
      return true;
    } else {
      $('#exitosa').css('color', 'white');
      $('#exitosa').text('Huellas Capturadas');
      $('.marcoHuella').css('border-color', '#DEEDF2');
      $('#marcoHuella').css('border-color', '#DEEDF2');
      console.log('cambio color.....')
      this.addFingerVerifyINE(this.guid, this.FingerNeuro);
      $(".botonVerificar").css('visibility', 'hidden');
      $(".botonCancelar").css('visibility', 'hidden');
      $(".std-separaSwitch").css('visibility', 'hidden');
      this.captura = true;
      this.codeError = "0";
      return false;
    }
  }

  public capturaHuella = "";
  public showPreviewObser: any;

  addFingerVerifyINE(guid: string, FingerNeuro: number) {
    $('.marcoHuella').removeClass('border-color');
    $('.marcoHuella').css('border-color', '#DEEDF2');

    const params = [
      guid,
      FingerNeuro
    ];
    this.bcService.addFingerVerifyINE(params);

    this.bcService.getshowPreview();
    this.showPreviewObser = this.bcService.showPreviewRespuesta$.subscribe({
      next: (response: any) => {
        if (response != "") {
          $("#preview").css("opacity", "1");
          var img = document.getElementById("preview") as HTMLImageElement;
          img.src = "data:image/png;base64," + response;
          this.capturaHuella = response;
          response = "";
        } else {
          this.fingerFail();
        }
      },
      error(err) {
        console.log("error en show preoview" + err);
      },
      complete() {
        console.log('done');
      }


    });


    this.load();

    //showPreviewObser.unsubscribe();
  }

  public loadingObservable: any;

  load() {
    this.bcService.getloading();
    this.loadingObservable = this.bcService.loadingRespuesta$.subscribe(res => {
      if (res == undefined) {
        this.loading();
      } else
        this.fingerFail();
      // next: (response: any) => {
      //   if (response == undefined) {
      //     this.loadingObservable.take(1);
      //     this.loading();
      //   }
      //   else {
      //     this.fingerFail();
      //   }
      // }
    });

  }

  noCuentaConHuella() {
    if (this.FingerNeuro == 2) {
      var obj = [7];
      this.Position = obj;
      this.tituloInstruccion = "Verificar índice izquierdo";
      this.dedoImg = 'assets/img/combinaciones/18.png';
      this.FingerNeuro = 7;
      this.Position = [7];
      this.idImg = "Id" + 7;
      this.contAusencias++;
      for (var pos11 = 0; pos11 < this.Position.length; pos11++) {
        this.ArrayAusenciasSelect[this.Position[pos11] - 1] = 0;
      }
      $("#ckbNoCuentaHuella").prop("checked", false);
    } else if (this.FingerNeuro == 7) {
      this.contAusencias++;
      var obj = [7];
      this.Position = obj;
      for (var pos11 = 0; pos11 < this.Position.length; pos11++) {
        this.ArrayAusenciasSelect[this.Position[pos11] - 1] = 0;
      }

      if (this.contAusencias == 2) {
        this.dialogFingerRef.close();
        this.modalErrorGeneral('<p class="textoErrorModal"> No es posible verificar al cliente </p>', "Finalizar");
      } else {
        this.checkIne();
      }
    }

  }

  public codeError: string = "0";
  public messageError: string = "";

  fingerFail() {
    this.bcService.getfailBuro();
    this.bcService.failBuroRespuesta$.subscribe(response => {
      if (response) {
        if (this.codeError == undefined || this.codeError == "0") {
          this.codeError = response.Code;
          for (var pos7 = 0; pos7 < 11; pos7++) {
            this.ArrayAusenciasSelect[pos7] = pos7 + 1;
          }
          if (this.ArrayAusencias.length > 0) {
            for (var pos8 = 0; pos8 < this.ArrayAusencias.length; pos8++) {
              this.ArrayAusenciasSelect[this.ArrayAusencias[pos8] - 1] = 0;
            }
          }
          $('#exitosa').css('color', '#ec0000');
          $('#exitosa').text('Captura no exitosa');
          $('.marcoHuella').css('border-color', '#EC0000');
          this.timeOutFailBuro(response.Code, response.Message);
        }
      }
    });
  }

  timeOutFailBuro(code: any, message: string) {
    var ErrorRepetir = false;
    var ErrorSalir = false;

    if (parseInt(code) == 270) {
      var partsOfStr = message.split(',');
      var message = "No se pudo capturar dedo(s):</br> ";
      for (var pos9 = 0; pos9 < partsOfStr.length; pos9++) {
        if (partsOfStr[pos9] != "" && partsOfStr[pos9] != null) {
          switch (parseInt(partsOfStr[pos9])) {
            case 1:
            case 6:
              message += "pulgar ";
              break;
            case 2:
            case 7:
              message += "índice ";
              break;
            case 3:
            case 8:
              message += "medio ";
              break;
            case 4:
            case 9:
              message += "anular ";
              break;
            case 5:
            case 10:
              message += "meñique ";
              break;
          }
          if (parseInt(partsOfStr[pos9]) <= 5)
            message += "derecho";
          else
            message += "izquierdo";
          if (partsOfStr.length > 1)
            message += ",</br>";
        }
      }
      ErrorRepetir = true;
    } else if (parseInt(code) == 300) {
      message = "Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5";
      ErrorRepetir = true;
    } else if (parseInt(code) == 200) {
      message = "El tiempo para realizar la captura</br> se ha excedido, por favor repítela.";
      ErrorRepetir = true;
    } else if (parseInt(code) == 280) {
      message = "Indica al cliente que la captura <strong>ha </br>excedido el número de intentos</strong> que</br> no es posible concluir el proceso de </br>registro y tendrá que hacerlo en otra visita a sucursal. </br> Agradece su tiempo.</div>";
      ErrorSalir = true;
    } else if (parseInt(code) == 290) {
      message = "Las huellas no cuentan con la calidad suficiente.";
      ErrorRepetir = true;
    } else if (parseInt(code) == 230) {
      message = "Se encontraron huellas previamente capturadas.";
      ErrorRepetir = true;
    } else {
      message = "Ocurrió un error inesperado en la captura de huellas.";
      ErrorRepetir = true;
    }
    if (ErrorRepetir) {
      var img = document.getElementById("preview") as HTMLImageElement;
      img.src = this.dedoImg;
      $('#exitosa').css('color', 'white');
      $('#dialogHuellasIne').css('visibility', 'hidden');
      $('.marcoHuella').css('border-color', '  #DEEDF2');
      this.modalErrorGeneral(message, 'Repetir');
    } else if (ErrorSalir) {
      $('#exitosa').css('color', 'white');
      $('#dialogHuellasIne').css('visibility', 'hidden');
      $('.marcoHuella').css('border-color', '  #DEEDF2');
      this.modalErrorGeneral(message, 'Salir');
    }
  }

  errorFunction() {
    this.reloadValuesInit();
    this.startSignalR();
  }

  reloadValuesInit() {
    var obj = [2];
    this.Position = obj;
    this.tituloInstruccion = "Verificar índice derecho";
    this.dedoImg = 'assets/img/combinaciones/2.png';
    this.storageService.bcStorage.fingerCapture = 2;
    this.FingerNeuro = 2;
    this.captura = false;

    var img = document.getElementById("preview") as HTMLImageElement;
    img.src = this.dedoImg; //"";

    $(".BtnCaptura").html('Siguiente');
    $('.BtnCaptura').prop("disabled", false);
    $(".BtnCaptura").addClass('sigbtn');
    $('#dialogHuellasIne').css('visibility', 'visible');
    $(".botonVerificar").css('visibility', 'visible');
    $(".botonCancelar").css('visibility', 'visible');
    $(".std-separaSwitch").css('visibility', 'visible');


    $('#exitosa').text('Huellas Capturadas');
    $('#exitosa').css('color', 'white');
    $('.marcoHuella').css('border-color', '#DEEDF2');
    $('.sigbtn').prop("disabled", false);

  }

  loading() {
    $('#exitosa').text('Huellas Capturadas');
    $('#exitosa').css('color', '#63BA68');
    $('.marcoHuella').css('border-color', '#63BA68');

    setTimeout(() => {
      this.fingerCapturesCount += 1;
      if (this.contAusencias > 0)
        this.checkIne();
      else {
        if (this.FingerNeuro != 7)
          this.timeOutLoading();
      }

      //  debugger;
      if (this.fingerCapturesCount == 6)
        this.checkIne();
    }, 2000);

  }

  timeOutLoading() {
    // debugger;
    this.reloadValues();
    this.captura = false;
    for (var pos11 = 0; pos11 < this.Position.length; pos11++) {//ajusta contador para tomar indice izquierdo
      this.ArrayAusenciasSelect[this.Position[pos11] - 1] = 0;
    }

  }

  reloadValues() {
    $(".botonVerificar").css('visibility', 'visible');
    $(".botonCancelar").css('visibility', 'visible');
    $(".std-separaSwitch").css('visibility', 'visible');
    $('#exitosa').text('Huellas Capturadas');
    $('#exitosa').css('color', 'white');
    $('.marcoHuella').css('border-color', '#DEEDF2');

    this.FingerNeuro = 7;
    var obj = [7];
    this.Position = obj;
    this.tituloInstruccion = "Verificar índice izquierdo";
    this.dedoImg = 'assets/img/combinaciones/18.png';
    var img = document.getElementById("preview") as HTMLImageElement;
    img.src = this.dedoImg;
  }


  checkIne() {
    if (this.storageService.bcStorage.tipoFlujoVerificacion == 3 ||
      this.storageService.bcStorage.tipoFlujoVerificacion == 5) {//verificacion no cliente ventanilla
      if (parseInt(this.Position[0]) == 7) {
        $("#dialogHuellasIne").css('dialog', 'close');
        this.dialogGen = this.dialogs.showDialogProcesando(MessagesDialogProcesando.ifeRenapo);
        this.dialogFingerRef.close();
        this.intentosINE--;
        this.storageService.bcStorage.tipoIdentificacion = "INE"
        this.verifyINENoEnrolled();
      }
    } else { //verificacion no cliente escritorio flujo 4
      this.dialogFingerRef.close();
      var path = "escaner-ine";
      this.zone.run(() => {
        this.router.navigateByUrl(`/${path}`);
      });
    }
  }


  verifyINENoEnrolled() {
    this.bcService.getineResponse();
    const params = [
      this.storageService.bcStorage.tipoIdentificacion
    ];
    this.bcService.verifyINENoEnrolled(params);
    console.log("ENTRA A INE RESPONSE");
    const locationsSubscription = this.bcService.ineResponseRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          this.ineResponse(response);
          locationsSubscription.unsubscribe();
          locationsSubscription.closed;
        }
      }
    });
  }


  ineResponse(response: any) {
    this.storageService.bcStorage.hash = "";
    if (response.result != null && response.result != undefined && response.result.hash != null && response.result.hash != undefined) {
      this.storageService.bcStorage.hash = response.result.hash;
    }
    if (response.code == 0) {
      var msg = "";

      if (parseInt(response.result.response.codigoRespuesta) == 0) {
        if (response.result.response.minutiaeResponse != "" && response.result.response.minutiaeResponse != null) {
          var result2: number | null = 0;
          var result7: number | null = 0;
          //#region VALIDACIONES RESPUESTA INE
          if (response.result.response.minutiaeResponse.similitud2)
            if (response.result.response.minutiaeResponse.similitud2 != "" && response.result.response.minutiaeResponse.similitud2 != null) {
              // result2 = response.result.response.minutiaeResponse.similitud2.replace('%', '');
              result2 = parseFloat(response.result.response.minutiaeResponse.similitud2.replace('%', ''));
            }
          if (response.result.response.minutiaeResponse.similitud7)
            if (response.result.response.minutiaeResponse.similitud7 != "" && response.result.response.minutiaeResponse.similitud7 != null) {
              // result7 = response.result.response.minutiaeResponse.similitud7.replace('%', '');
              result7 = parseFloat(response.result.response.minutiaeResponse.similitud7.replace('%', ''));
            }
          if ((result2 >= 98 && result7 >= 98) || (result2 == 0 && result7 >= 98) || (result2 >= 98 && result7 == 0)) {
            //result2 indice derecho
            //result7 indice izquierdo

            //Aqui evaluamos que nombre y ApellidoP vengan en TRUE y ademas, si tiene Apellido Materno, "apellidoMaterno" debera de venir en TRUE
            //Si no tiene apellido materno, se omite la validacion
            var respcom = response.result.response.dataResponse.respuestaComparacion;
            // MXSLBIOM-1264: Al momento de validar sus datos del sistema vs INE, si 1 de los 3 campos (Nombre/ Apellido paterno/ apellido materno) de "True", la verificación sea exitosa.
            // Bug 2020PI06_SPRINT03_D003: Se solicita no se tome el null como true en la validación de una verificación en los campos Apellido Paterno y Materno.
            //Evaluar campo CURP enviado al INE
            var situacion = response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral;
            var OmitirVigencia = this.Utils.validaOmitirVigencia(situacion);
            if (!OmitirVigencia && situacion == "NO_VIGENTE") {
              var msg = this.biocheckError.codigoError("EOB09");
              this.modalErrorGeneral(msg, "Salir");
              return;
            }
            var timeStamp = response.result.timeStamp
            debugger;
            if (timeStamp !== null && timeStamp !== undefined) {
              var indice = response.result.timeStamp.indice;
              if (indice !== null && indice !== undefined) {
                this.storageService.bcStorage.indice = indice;
              }
            }
            var EvaluarCurp = false;
            if (respcom.curp != "" && respcom.curp != null) {
              EvaluarCurp = true;
              console.log('evaluo curp')
            }
            var camposCorrectos = 0;
            if (this.tieneApPat && respcom.apellidoPaterno == "true") {
              camposCorrectos++;
            }
            if (this.tieneApMat && respcom.apellidoMaterno == "true") {
              camposCorrectos++;
            }
            if (respcom.nombre == "true") {
              camposCorrectos++;
            }
            //#endregion
            if (EvaluarCurp) {// evalua CURP
              console.log('evaluando metodo curp')
              if ((this.isCIC || (respcom.ocr == "true" && respcom.claveElector == "true"
                && respcom.numeroEmisionCredencial == "true"
              )) && respcom.curp == "true" && camposCorrectos >= 2) {
                this.storageService.bcStorage.proceso = true;
                this.storageService.bcStorage.codigoflujo = "OK0000";
                this.storageService.bcStorage.mensajeflujo = "Validación Correcta";
                this.storageService.bcStorage.ineRespuesta = true;

                this.Utils.getFinalDate();
              } else {
                this.storageService.bcStorage.proceso = false;
                this.storageService.bcStorage.codigoflujo = "EVD09";
                this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
                this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
                this.Utils.getFinalDate();
              }
            } else { ///no evalua CURP flujo viejito
              console.log('flujo viejito')
              if ((this.isCIC || (respcom.ocr == "true" &&
                respcom.claveElector == "true"
                && respcom.numeroEmisionCredencial == "true"
              )) && camposCorrectos >= 2) {
                this.storageService.bcStorage.proceso = true;
                this.storageService.bcStorage.codigoflujo = "OK0000";
                this.storageService.bcStorage.mensajeflujo = "Validación Correcta";
                this.storageService.bcStorage.ineRespuesta = true;
                this.Utils.getFinalDate();
              } else {
                this.storageService.bcStorage.proceso = false;
                this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
                this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
                this.Utils.getFinalDate();
              }
            }

          } else {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
            this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
            this.Utils.getFinalDate();
          }
        } else {
          /* !!! MXSLBIOM-1265 / MXSLBIOM-1638:
           * tipoReporteRoboExtravio: debe ser distinto de: REPORTE_DE_EXTRAVIO | REPORTE_DE_ROBO | REPORTE_DE_ROBO_TEMPORAL | REPORTE_DE_EXTRAVIO_TEMPORAL ====================================== */
          if (
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_EXTRAVIO" ||
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_ROBO" ||
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_ROBO_TEMPORAL" ||
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_EXTRAVIO_TEMPORAL") {
            var msg = this.biocheckError.codigoError("EOB09");
            this.modalErrorGeneral(msg, "Salir");
          } else {
            /* !!! MXSLBIOM-2448 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2019 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. Se deberá modificar la bandera no eliminarla, es decir, cuando termine la prórroga del INE se puede volver hacer las validaciones de las vigencias actuales.
             * !!! MXBIOC-193 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2020 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. ====================================== */
            var vigencia = parseInt(this.storageService.bcStorage.vigencia == undefined ? "0" : this.storageService.bcStorage.vigencia);
            var entidad = this.storageService.bcStorage.ClaveEntidad == undefined ? "" : this.storageService.bcStorage.ClaveEntidad;
            var anioVigencia = (vigencia) ? vigencia : 0;
            var listEstadosVigencia = this.storageService.bcStorage.EstadosVigenciaIne !== undefined ? this.storageService.bcStorage.EstadosVigenciaIne.split(',') : "";
            var ExisteEstado = listEstadosVigencia !== "" ? listEstadosVigencia.includes(entidad) : false; //.find(f => f.value == this.storageService.bcStorage.ClaveEntidad) : false;
            var FechaAplicaVigencia = this.storageService.bcStorage.FechaVigenciaProrroga !== undefined ? (this.storageService.bcStorage.FechaVigenciaProrroga !== "" ? new Date(this.storageService.bcStorage.FechaVigenciaProrroga) : new Date("01/01/1990")) : new Date("01/01/1990")
            var fechaDeHoy = new Date();
            var anio = fechaDeHoy.getFullYear(); //año valido vigente
            var FechaTerminoProrroga = true;
            if (anioVigencia < anio && FechaAplicaVigencia < fechaDeHoy)
              FechaTerminoProrroga = false
            var reglaOmitirVigencia = this.storageService.bcStorage.OmitirVigenciaIne === true && FechaTerminoProrroga && ExisteEstado != undefined;
            if (response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral == "NO_VIGENTE") {
              var msg = this.biocheckError.codigoError("EOB09");
              this.modalErrorGeneral(msg, "Finalizar");
            } else if (response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral == "DATOS_NO_ENCONTRADOS") {
              var errores = "";
              var mensajefinal = "Favor de validar la información que no sea un error de captura, en caso de que no sea así sugiere que acuda al INE para actualizar su información";
              if (this.storageService.bcStorage.tipoIdentificacion === "INE")
                errores += "<li>Número de Credencial para votar - <a class='listErrorIne'>" + this.storageService.bcStorage.cic + "</a></li>";
              else {
                errores += "<li>Número de Credencial para votar - <a class='listErrorIne'>" + this.storageService.bcStorage.ocr + "</a></li>";
                errores += "<li>Clave de Elector - <a class='listErrorIne'>" + this.storageService.bcStorage.claveElector + "</a></li>";
              }
              msg = "<div class='dvListErrorIne'>Respuesta del INE</div><br />"
                + "<div class='dvMsgCliente'>Indica al cliente que debes finalizar el proceso, por que no se ha logrado validar los siguientes datos con el INE: <br><br>"
                + "<ul class='dvUlList'>" + errores + "</ul>" + mensajefinal + "</div>"
              this.storageService.bcStorage.proceso = false;
              this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
              this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
              // this.getFinalDate();
              this.modalErrorGeneral(msg, "Finalizar");
            } else {
              this.storageService.bcStorage.codigoflujo = "EVD05";
              this.storageService.bcStorage.proceso = false;
              this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
              var resp = this.parseResponse(response.message);
              if (resp != null && resp != null)
                this.modalErrorGeneral(resp, "Finalizar");
              else
                this.modalErrorGeneral("El servicio de INE no esta disponible", "Finalizar");
            }
          }
        }
      } else {
        this.storageService.bcStorage.codigoflujo = "EVD05";
        this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
        this.storageService.bcStorage.proceso = false;
        var resp = this.parseResponse(response.message);
        if (resp != null && resp != null)
          this.modalErrorGeneral(resp, "Finalizar");
        else
          this.modalErrorGeneral("El servicio de INE no esta disponible", "Finalizar");
      }
    } else {
      this.storageService.bcStorage.codigoflujo = "EVD05";
      this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
      this.storageService.bcStorage.proceso = false;
      var resp = this.parseResponse(response.message);
      if (resp != null && resp != null)
        this.modalErrorGeneral(resp, "Finalizar");
      else
        this.modalErrorGeneral("El servicio de INE no esta disponible", "Finalizar");
    }
  }

  IsJsonString(str: any) {
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  parseResponse(e: any) {

    var obj = JSON.parse(e);
    console.log(obj);
    var msg = "";
    try {
      if (obj != null) {
        var dato = obj.errors[0];
        msg = dato.message + ", " + dato.description;
      }
    } catch {
      msg = "";
    }
    console.log('msg::' + msg)
    return msg;
  }

  modalErrorGeneral(msg: string, accion: string) {
    debugger;
    this.dialogGen?.close();
    if (accion == "Salir" || accion == "Finalizar") {//salir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, accion);
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.dialogFingerRef.close();
          this.Utils.getFinalDate();
        }
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    } else {//repetir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.errorFunction();
        } else {
          this.cancelarinfo();
        }
        try {
          this.Utils.sendLog('warning', 'PaaS [" + window.location.href + "]', msg);
          // const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          // this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    }
  }

  clickFunction(pos1: number) {
    var huellaStri = '#f' + pos1;
    this.huellaStri(pos1);
  }

  public id: any = "";

  huellaStri(pos1: number) {
    this.id = $(this).attr('id');
    var numid = this.id.substring(1);
    if (this.ArrayAusenciasSelect[numid - 1] != 0) {
      $(this).removeClass("inactivo");
      $(this).addClass("ausencia");
      this.ArrayAusenciasSelect[numid - 1] = 0;
      this.ajustarContador(pos1, 1);
    } else {
      $(this).removeClass("ausencia");
      $(this).addClass("inactivo");
      this.ArrayAusenciasSelect[numid - 1] = numid;
      this.ajustarContador(pos1, -1);
    }
  }

  ajustarContador(id: number, sort: any) {
    switch (id) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        //Mano derecha
        this.contadorDerecho += (1 * sort);
        break;
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
        //Mano izquierda
        this.contadorIzquierdo += (1 * sort);
        break;
    }

  }

  getParameterByName(name: string) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null)
      return "";
    else
      return decodeURIComponent(results[1].replace(/\+/g, " "));
  }

}
