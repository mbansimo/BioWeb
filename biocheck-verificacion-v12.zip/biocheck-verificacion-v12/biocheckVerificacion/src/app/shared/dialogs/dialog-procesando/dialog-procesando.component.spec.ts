import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogProcesandoComponent } from './dialog-procesando.component';

describe('DialogProcesandoComponent', () => {
  let component: DialogProcesandoComponent;
  let fixture: ComponentFixture<DialogProcesandoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DialogProcesandoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogProcesandoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
