import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {CarouselComponent} from '../carousel/carousel.component';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AnimationType} from "../carousel/carousel.animations";
import {MsgDialogModel} from 'src/app/core/models/msg-dialog.model';
import {interval} from "rxjs";
import {BcstorageService} from "../../../core/services/bcstorage.service";


@Component({
  selector: 'app-dialog-procesando',
  templateUrl: './dialog-procesando.component.html',
  styleUrls: ['./dialog-procesando.component.css']
})
export class DialogProcesandoComponent implements OnInit {
  @ViewChild(CarouselComponent, {static: true}) carousel!: CarouselComponent;
  animationType = AnimationType.Flip;
  imgStd = 'assets/img/santander.png';
  //emit value in sequence every 1 second
  source = interval(1000);

  constructor(
    public dialogRef: MatDialogRef<DialogProcesandoComponent>,
    private storageService: BcstorageService,
    @Inject(MAT_DIALOG_DATA) public data: MsgDialogModel
  ) {
  }

  ngOnInit(): void {

    console.log('DATA =>', this.data);
    console.log(this.storageService.bcStorage.tiempoMaximo);

    if (this.storageService.bcStorage.tiempoMaximo) {
      this.source = interval(2500);
      this.source.subscribe(val => {
        if (val === 25) {
          this.dialogRef.close();
        }
      });
    } else {
      this.source.subscribe(val => {
        if (val === 10) {
          this.dialogRef.close();
        }
      });
    }

  }

}
