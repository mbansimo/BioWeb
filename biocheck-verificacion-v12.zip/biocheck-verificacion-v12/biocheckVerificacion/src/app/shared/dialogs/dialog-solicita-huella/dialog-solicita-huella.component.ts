import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {BcstorageService} from "../../../core/services/bcstorage.service";
import {BiocheckService} from "../../../core/services/biocheck.service";
import {UtilDialogs} from "../../../common/util-dialogs";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {DataDialogModel, DataDialogSolicitudHuella} from "../../../core/models/msg-dialog.model";
import * as $ from "jquery";
import {FormatoCapturaModel} from "../../../core/models/formatoCaptura.model";

@Component({
  selector: 'app-dialog-solicita-huella',
  templateUrl: './dialog-solicita-huella.component.html',
  styleUrls: ['./dialog-solicita-huella.component.scss']
})
export class DialogSolicitaHuellaComponent implements OnInit {
  imgHuellaModal: string = '';
  dialogInstruccionText: string = '';
  intentosRestantes: number | undefined = 3;

  constructor(
    private storageService: BcstorageService,
    @Inject(MAT_DIALOG_DATA) public data: DataDialogSolicitudHuella
  ) {
  }

  ngOnInit(): void {

    this.cargarVista();
    console.log('DATA =>',this.data);

  }

  cargarVista(){
    if (this.data.imagen != null) {
      this.imgHuellaModal = this.data.imagen;
    }
    if (this.data.title != null) {
      this.dialogInstruccionText = this.data.title;
    }
    this.intentosRestantes = this.data.numeroIntentos;
  }





}
