import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {DialogProcesandoComponent} from "./dialog-procesando/dialog-procesando.component";
import {CarouselComponent} from "./carousel/carousel.component";
import {DialogGeneralComponent} from "./dialog-general/dialog-general.component";
import {MaterialModule} from "../../material/material.module";
import { DialogSolicitaHuellaComponent } from './dialog-solicita-huella/dialog-solicita-huella.component';
import { DialogCapturaRostroComponent } from './dialog-captura-rostro/dialog-captura-rostro.component';
import {MatTableModule} from "@angular/material/table";
import { DialogCapturaRostroFacialComponent } from './dialog-captura-rostro-facial/dialog-captura-rostro-facial.component';
import { DialogHuellasComponent } from './dialog-huellas/dialog-huellas.component';



@NgModule({
  declarations:[
    DialogProcesandoComponent,
    CarouselComponent,
    DialogGeneralComponent,
    DialogSolicitaHuellaComponent,
    DialogCapturaRostroComponent,
    DialogCapturaRostroFacialComponent,
    DialogHuellasComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    MatTableModule
  ],
  exports:[
    DialogSolicitaHuellaComponent
  ]
})

export class DialogsModule{}
