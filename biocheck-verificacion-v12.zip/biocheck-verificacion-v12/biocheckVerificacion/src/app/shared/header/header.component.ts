import {Component, NgZone, OnInit} from '@angular/core';
import {BiocheckService} from 'src/app/core/services/biocheck.service';
import {BcstorageService} from "../../core/services/bcstorage.service";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public imgLogo = 'assets/img/logo.png';
  public versionInstalador!: string;
  public versionComercial!: string | undefined;

  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private zone: NgZone
  ) {
  }

  ngOnInit(): void {
    this.getVersion();
  }


  getVersion() {
    this.bcService.versionInstalador$.subscribe({
      next: response => {
        if (response) {
          this.zone.run(() => {
            this.versionInstalador = 'v' + response;
            this.versionComercial = 'v' + this.storageService.bcStorage.versionBiocheck;
          })
        }
      },
      error: error => console.error(error)
    })
  }


}
