import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {AusenciaycapturaComponent} from "./ausenciaycaptura.component";

const routes: Routes = [
  {path: '', component: AusenciaycapturaComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AusenciaycapturaRoutingModule {
}


