import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ausenciaycaptura',
  templateUrl: './ausenciaycaptura.component.html',
  styleUrls: ['./ausenciaycaptura.component.scss']
})
export class AusenciaycapturaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
