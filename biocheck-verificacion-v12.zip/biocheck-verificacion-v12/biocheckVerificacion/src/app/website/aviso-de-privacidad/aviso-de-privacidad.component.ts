import {Component, OnInit} from '@angular/core';
import {CatalogosService} from "../../core/services/catalogos.service";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {BiocheckService} from "../../core/services/biocheck.service";
import {UtilDialogs} from "../../common/util-dialogs";
import {Router} from "@angular/router";
import {BiocheckErrorService} from "../../core/services/biocheck.error.service";
import {MatDialogRef} from "@angular/material/dialog";
import {FinalDateModel} from "../../core/models/final-date.model";
import * as $ from "jquery";
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";

@Component({
  selector: 'app-aviso-de-privacidad',
  templateUrl: './aviso-de-privacidad.component.html',
  styleUrls: ['./aviso-de-privacidad.component.scss']
})
export class AvisoDePrivacidadComponent implements OnInit {

  // carga de inicio
  public imagenCara = 'assets/img/cara_check.svg';
  public imagenManos = 'assets/img/credencial.png';
  public imagenMas = 'assets/img/signo_mas.png';
  public nombreCliente?: string;
  public idImg?: string;


  //Controla la versión del front
  public procesando: string = "Captura rostro";
  //public correos = this.bccatalogos.domains;//Catalogos de email
  public correos: any[] = [
    {"id": 0, "name": "Seleccionar Dominio"},
    {"id": 1, "name": "@gmail.com"},
    {"id": 2, "name": "@yahoo.com"},
    {"id": 3, "name": "@yahoo.com.mx"},
    {"id": 4, "name": "@outlook.com"},
    {"id": 5, "name": "@hotmail.com"},
    {"id": 6, "name": "Otro"}];
  public email: any = ''; //guardamos texto del campo de texto
  public dominio!: string;  //guardamos dominio seleccionado
  public mostrarCorreoElectronico: boolean = false; //Aparece y desaparece el campo de email
  public cargaCompleta: boolean = true; //Se debe activar a true cuando todo los componentes se carguen y se muestra el boton Siguiente
  public msjerror!: string;

//  modalerrormensaje = biocheck.modalerrormensaje;
//  modalerrormensaje2 = biocheck.modalerrormensaje2;
  public cont: number = 0;
  //$.connection.hub.url = bcstorage.hubUrl;
//  public cancelar = biocheck.cancelar;
  public isnotwhitelist: boolean = true;

  public ejecutivo: any = null;
  public winPros: any = null;
  public guid: string = ''; //null valor determinado
  public obtenerVersionDespliegueExito: boolean = false;
  public respuestaCargada: boolean = false;

  //Variables reset escaner
  public intentosReiniciarEscaner: number = 0;
  public intentosResetEscanerDoc: number = 3;
  public esReintentoEscaner: boolean = false;

  public dialogGen: MatDialogRef<any, any> | undefined;

  constructor(
    private storageService: BcstorageService,
    private bcService: BiocheckService,
    private Pasos: BiocheckPasosService,
    private bccatalogos: CatalogosService,
    private dialogs: UtilDialogs,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
    this.mostrarCorreoElectronico = false;
    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    this.controlDePasos();
  }

  public simboloMas: boolean = true;
  public imagenIne: boolean = true;
  public columna: boolean = false;
  public tituloProceso: string = '';
  public controlPasos: boolean = true;
  public pasos: number = 4;

  controlDePasos() {
    if (this.controlPasos) {
      this.numeroPasosyVista();
      var lista = this.Pasos.totalPasos(this.pasos);
      $('#listaPasos').append(lista);
      this.cambiarPaso(1, "Aviso de privacidad"); // revisar
      this.controlPasos = false;
    } else {
      console.log('ya se cargaron los pasos::::');
    }
  }

  numeroPasosyVista() {
    if (this.storageService.bcStorage.tipoVerificacion == 'verifica_motor') {
      this.pasos = 2;
      this.simboloMas = false;
      this.imagenIne = false;
      this.columna = true;
      this.tituloProceso = 'Esta iniciando el proceso de verificación biométrica facial a MOTOR';
    } else {
      this.tituloProceso = 'Esta iniciando el proceso de verificación biométrica facial INE';
      this.pasos = 4;
    }
  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');

    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  changeCheck(value: any) {
    //se ejecuta al activar o desactivar el switch del enviar email
//    if (this.storageService.bcStorage.tipoVerificacion == 'verifica_ine_facial'){
      this.mostrarCorreoElectronico = !this.mostrarCorreoElectronico;
//    }else {
//      console.log('no activado para este proceso');
//    }

  };

  emailChange() {
    var correo = $('#correo').val();
    this.dominio = correo as string;
    $("#correo").blur();
  };

  public iniciar() {
    this.email = $("#compania").val() as string;
    if (this.mostrarCorreoElectronico == true) {
      if (this.emailValido()) {
        this.msjerror = '';
        var correoElectronico = "";
        if (this.dominio === 'Otro') {
          correoElectronico = this.email;
        } else {
          if (this.email != null && this.email != undefined && this.email != '') {
            correoElectronico = this.email + this.dominio;
          } else {
            correoElectronico = '';
          }
        }
        // MXSLBIOM-1631: Enviar el aviso de privacidad al correo electronico del cliente en el flujo de no enrolados escritorio
        this.bcService.notificacionEmail([correoElectronico, 'AvisoDePrivacidad']);
        this.pasarSiguientePagina();
      } else {
        this.msjerror = 'Correo electrónico erróneo';
      }
    } else {
      this.pasarSiguientePagina();
    }
  };

  pasarSiguientePagina() {
    //biocheck.onStopSignalR(); TODO: verificar las url a donde redirecciona
    //  this.router.navigateByUrl('#!/NoEnrolado/facialIneRostroCaptura');
      this.router.navigateByUrl('capturaRostroIne');


  }

  emailValido() {
    var correoElectronico = ''; //variable auxiliar
    var emailValido = true;
    if (this.mostrarCorreoElectronico) {
      if (this.email.length !== 0) {
        if (this.dominio === 'Otro') {
          correoElectronico = this.email;
        } else {
          correoElectronico = this.email.concat(this.dominio);
        } //acomodamos el correo electronico para poder trabajarlo
        emailValido = this.validacionEmail(correoElectronico);
      } else {
        correoElectronico = '';
        emailValido = false;
      }
    }
    return emailValido;
  }

  validacionEmail(email: string) {
    var estructuraValida = true;
    var regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/igm;
    if (email === '') {
      this.msjerror = '';
      estructuraValida = true;
      //$('#emailform').css('border', 'solid 1px rgb(27, 179, 188)');
      $('#emailform').css('border', 'solid 1px #ced4da');
    } else {
      if (!email.match(regex)) {
        this.msjerror = 'El correo electr\u00F3nico es inv\u00E1lido';
        setTimeout(function () {
          $('#compania').css('border', '1px solid #ec0000');
          $('#msj-error').css('color', '#ec0000');
        }, 100);
        estructuraValida = false;
      } else {
        this.msjerror = '';
        estructuraValida = true;
        //$('#emailform').css('border', 'solid 1px rgb(27, 179, 188)');
        $('#compania').css('border', 'solid 1px #ced4da');
      }
    }
    return estructuraValida;
  }


  public cancelar() {
    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    if (this.storageService.bcStorage.proceso) {
      this.router.navigateByUrl('/finalizar');
    } else {
      this.respuesta();
    }
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  sendMessage(msg: string) {
    //postFinalizar(msg); no existe funcionalidad
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }


}
