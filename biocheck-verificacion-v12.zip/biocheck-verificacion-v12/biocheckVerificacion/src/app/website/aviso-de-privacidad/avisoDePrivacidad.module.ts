import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {AvisoDePrivacidadComponent} from "./aviso-de-privacidad.component";
import {AvisoDePrivacidadRoutingModule} from "./avisoDePrivacidad-routing.module";
import {FormsModule} from "@angular/forms";


@NgModule({
  declarations: [
    AvisoDePrivacidadComponent
  ],
    imports: [
        CommonModule,
        AvisoDePrivacidadRoutingModule,
        MaterialModule,
        SharedModule,
        MatTooltipModule,
        MatButtonModule,
        DialogsModule,
        FormsModule,
    ],
  exports:[],
  bootstrap:[AvisoDePrivacidadComponent]
})
export class AvisoDePrivacidadModule{}

