import {Component, OnInit} from '@angular/core';
import {BcstorageService} from "../../core/services/bcstorage.service";
import {BiocheckService} from "../../core/services/biocheck.service";
import {UtilDialogs} from "../../common/util-dialogs";
import {Router} from "@angular/router";
import {BiocheckErrorService} from "../../core/services/biocheck.error.service";
import * as $ from "jquery";
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";
import {FinalDateModel} from "../../core/models/final-date.model";
import {MatDialogRef} from "@angular/material/dialog";
import {data} from "jquery";

@Component({
  selector: 'app-captura-id-manual',
  templateUrl: './captura-id-manual.component.html',
  styleUrls: ['./captura-id-manual.component.scss']
})
export class CapturaIdManualComponent implements OnInit {

  //Inicializacion de variables
  public seleccionIdentificacion: boolean = false; //Muestra la seccion de datos
  public identificaionINE: boolean = true; //Muestra los campos para ine o para ife

  //Inicializacion    //Variables de los campos
  public cic: string = '';
  public claveElector: string = '';
  public ocr: string = '';
  public codigoEmision: string = '';
  public anioRegistro: string = '';
  public anioEmision: string = '';
  public seccionAnos: boolean = false;

  //Variables de los mensajes de error de inputs
  public msjcic: any = '';
  public msjocr: any = '';
  public msjemision: any = '';
  public msjclaveElector: any = '';
  public nombrefront: any = '';
  public appatfront: any = '';
  public apmatfront: any = '';
  public aniodeEmision?: any = '';
  public aniodeRegistro?: any = '';


  public msjAnioRegister: any = '';
  public msjAnioemision: any = '';
  public identificaionINE_s: string = '';


  //Variables de consulta
  public nombre: string = this.storageService.bcStorage.apicNombre || '';
  public apellidoPaterno: string = this.storageService.bcStorage.apicApellidoP || '';
  public apellidoMaterno: string = this.storageService.bcStorage.apicApellidoM || '';

  //variables a usar
  public curp: string = this.storageService.bcStorage.curp || '';
  public identificacion: string = this.identificaionINE_s ? 'INE' : 'IFE';
  public imagenAyuda: string = 'assets/img/ayuda.svg';
  public imagenIfeEscaner: string = 'assets/img/ifeEscanear.png';
  public imagenIne: string = 'assets/img/INE.png';
  public imagenCic: string = 'assets/img/cic.png';
  public imagenClave: string = 'assets/img/clave.png';
  public nombreCliente?: string;
  public pasos: number = 4;
  public controlPasos: boolean = true;

  public dialogGen: MatDialogRef<any, any> | undefined;


  public toolTipClaveElector = "assets/img/clave.png";
  public toolTipOCR_i = 'assets/img/ocr.png';
  public toolTipEmision = 'assets/img/emision.png';
  public toolTipFechaEmision = 'assets/img/ine_emision.png';
  public toolTipFechaRegistro = 'assets/img/ine_Registro.png';
  public toolTipCIC = 'assets/img/cic.png';


  constructor(
    private storageService: BcstorageService,
    private bcService: BiocheckService,
    private Pasos: BiocheckPasosService,
    private dialogs: UtilDialogs,
    private router: Router,
    private biocheckError: BiocheckErrorService,
  ) {
  }

  ngOnInit(): void {
    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    this.iniciarCampos();
    this.iniciarVista();
//    this.controlDePasos();

  }

  controlDePasos() {
    if (this.controlPasos) {
      this.numeroPasosyVista();
      var lista = this.Pasos.totalPasos(this.pasos);
      $('#listaPasos').append(lista);
      this.cambiarPaso(3, "Seleccionar identificación");
      this.controlPasos = false;
    } else {
      console.log('ya se cargaron los pasos::::');
    }
  }

  numeroPasosyVista() {
    if (this.storageService.bcStorage.tipoVerificacion == 'verifica_motor') {
      this.pasos = 2;
    } else {
      this.pasos = 4;
    }
  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');

    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  ayudaTooltip() {
    $('.ayudaTooltip').attr({
      position: 'top-right',
      background: 'rgb(111,119,121)',
      color: '#000',
      useTitle: false,
      tooltipHover: true,
      width: 350
    })
  }

  iniciarVista() {
    this.ayudaTooltip();
  }

  iniciarCampos() {
//Variables de los campos
    this.cic = '';
    this.claveElector = '';
    this.ocr = '';
    this.codigoEmision = '';
    this.anioRegistro = '';
    this.anioEmision = '';

    //Variables de los mensajes de error de inputs
    this.msjcic = '';
    this.msjocr = '';
    this.msjemision = '';
    this.msjclaveElector = '';
    this.msjemision = '';


    this.msjAnioRegister = '';
    this.msjAnioemision = '';


    //Variables de consulta
    this.nombre = this.storageService.bcStorage.apicNombre || '';
    this.apellidoPaterno = this.storageService.bcStorage.apicApellidoP || '';
    this.apellidoMaterno = this.storageService.bcStorage.apicApellidoM || '';

    //variables a usar
    this.curp = this.storageService.bcStorage.curp || '';
    this.identificacion = this.storageService.bcStorage.identificaionINE ? 'INE' : 'IFE';
  }


  //Inicia la vista
  //Funciones
  DataEditable(curp: any, ocr: any, nombrefront: any, appatfront: any, apmatfront: any, claveElector: any, codigoEmision: any, cic: any, anioEmision: any, anioRegistro: any) {
    this.curp = curp == '' ? null : curp;
    this.ocr = ocr == '' ? null : ocr;
    this.nombrefront = nombrefront == '' ? null : nombrefront;
    this.appatfront = appatfront == '' ? null : appatfront;
    this.apmatfront = apmatfront == '' ? null : apmatfront;
    this.claveElector = claveElector == '' ? null : claveElector;
    this.codigoEmision = codigoEmision == '' ? null : codigoEmision;
    this.cic = cic == '' ? null : cic;
    this.aniodeEmision = anioEmision == '' ? null : anioEmision;
    this.aniodeRegistro = anioRegistro == '' ? null : anioRegistro;

  }

  mostrarCampos(identificacion: any) {
    if (identificacion == 'INE') {
      this.identificaionINE = true;
      this.storageService.bcStorage.esIne = true;
    } else {
      this.identificaionINE = false;
      this.storageService.bcStorage.esIne = false;
    }
    if (this.seleccionIdentificacion) {
      this.camposCorrectos();
    }
    this.seleccionIdentificacion = true;
    this.iniciarCampos();
  } //Se encarga de mostrar los campos dependiendo el documento seleccionado

  public datosValidos: any = false;

  //Validacion de campos

  validacionCic() {
    let cicCorrecto = true;
    var estructuraCic = this.cic.match(/^[0-9]*$/i);
    if (this.cic.length == 0) {
      this.msjcic = 'Campo vacío';
      cicCorrecto = false;
    } else if (this.cic.length != 9) {
      this.msjcic = 'Requiere 9 caracteres';
      cicCorrecto = false;
    } else if (estructuraCic == null) {
      this.msjcic = 'Solo se aceptan números';
      cicCorrecto = false;
    } else {
      this.msjcic = null;
    }

    return cicCorrecto;
  }  //Devuelve si es correcto el campo de cic

  validacionClaveElector() {
    let claveElectorCorrecto = true;
    if (this.claveElector.length == 0 || this.claveElector == undefined) {
      this.msjclaveElector = 'Campo vacío';
      claveElectorCorrecto = false;
    } else if (this.claveElector.length == 18) {
      if (this.claveElector === this.claveElector.toUpperCase()) {
        if (this.claveElector.match(/[A-Z]{6}[0-9]{8}[A-Z]{1}[0-9]{3}/)) {
          this.msjclaveElector = null;
        } else {
          this.msjclaveElector = 'Estructura incorrecta';
          claveElectorCorrecto = false;
        }
      } else {
        this.msjclaveElector = 'Solo se aceptan números y letras en mayúsculas';
        claveElectorCorrecto = false;
      }
    } else {
      this.msjclaveElector = 'Requiere 18 caracteres';
      claveElectorCorrecto = false;
    }
    return claveElectorCorrecto;
  } //Devuelve si es correcto el campo clave de elector

  validacionCodigoEmision() {
    var emisionCorrecto = true;
    if (this.codigoEmision.length == 0) {
      this.msjemision = 'Campo vacío';
      emisionCorrecto = false;
    } else if (this.codigoEmision.length != 2) {
      this.msjemision = 'Formato incorrecto';
      emisionCorrecto = false;
    } else if (!this.codigoEmision.match(/^[0-9]*$/i)) {
      this.msjemision = 'Solo se aceptan números';
      emisionCorrecto = false;
    } else {
      this.msjemision = null;
    }
    return emisionCorrecto;
  } //Validacion del campo de codigo de emision

  validacionOcr() {
    var ocrCorrecto = true;
    var estructuraOcr = this.ocr.match(/^[0-9]*$/i);
    if (this.ocr.length === 0) {
      this.msjocr = 'Campo vacío';
      ocrCorrecto = false;
    } else if (estructuraOcr == null) {
      this.msjocr = 'Solo se aceptan números';
      ocrCorrecto = false;
    } else if (!this.ocr.match(/^(?:[\d]{13})$/)) {
      this.msjocr = 'Requiere 13 caracteres';
      ocrCorrecto = false;
    } else {
      this.msjocr = null;
    }
    return ocrCorrecto;
  } //Validacion del campo de ocr

  validacionAnioRegistro() {
    var AnioRegistroCorrecto = true;
    if (this.anioRegistro.length == 0) {
      this.msjAnioRegister = 'Campo vacío';
      AnioRegistroCorrecto = false;
    } else if (this.anioRegistro.length != 4) {
      this.msjAnioRegister = 'Formato incorrecto';
      AnioRegistroCorrecto = false;
    } else if (!this.anioRegistro.match(/^[0-9]*$/i)) {
      this.msjAnioRegister = 'Solo se aceptan números';
      AnioRegistroCorrecto = false;
    } else {
      this.msjAnioRegister = null;
    }
    return AnioRegistroCorrecto;
  }//Validacion del Año de registro

  validacionAnioEmision() {
    var AnioEmisionCorrecto = true;
    if (this.anioEmision.length == 0) {
      this.msjAnioemision = 'Campo vacío';
      AnioEmisionCorrecto = false;
    } else if (this.anioEmision.length != 4) {
      this.msjAnioemision = 'Formato incorrecto';
      AnioEmisionCorrecto = false;
    } else if (!this.anioEmision.match(/^[0-9]*$/i)) {
      this.msjAnioemision = 'Solo se aceptan números';
      AnioEmisionCorrecto = false;
    } else {
      this.msjAnioemision = null;
    }
    return AnioEmisionCorrecto;
  }//Validacion del Año de emision

  camposCorrectos() {
    var camposCorrectos = true;
    if (this.identificaionINE) {
      if (!this.validacionCic()) {
        camposCorrectos = false;
      }
      if (!this.validacionClaveElector()) {
        camposCorrectos = false;
      }
      if (!this.validacionCodigoEmision()) {
        camposCorrectos = false;
      }
      if (!this.validacionAnioRegistro()) {
        camposCorrectos = false;
      }
      if (!this.validacionAnioEmision()) {
        camposCorrectos = false;
      }
    } else {
      if (!this.validacionClaveElector()) {
        camposCorrectos = false;
      }
      if (!this.validacionOcr()) {
        camposCorrectos = false;
      }
      if (!this.validacionCodigoEmision()) {
        camposCorrectos = false;
      }
      if (!this.validacionAnioRegistro()) {
        camposCorrectos = false;
      }
      if (!this.validacionAnioEmision()) {
        camposCorrectos = false;
      }
    }
    this.datosValidos = camposCorrectos;
    if (this.datosValidos && this.seleccionIdentificacion) {
      $("#escanearBtn").removeClass("boton_Inactivo");
      $("#escanearBtn").addClass("boton_Positivo");
    } else {
      $("#escanearBtn").removeClass("boton_Positivo");
      $("#escanearBtn").addClass("boton_Inactivo");
    }

    return camposCorrectos;
  } //Podemos poner en lista todos los campos que deseamos

  validar2() {
//    biochkHub.server.testFacialPeticion();
  }

  public dataine: any[]= [];
  validar() {
    if (this.camposCorrectos()) {
      this.storageService.bcStorage.tipoIdentificacion = this.identificacion; //Guardamos el tipo de documento seleccionado
      if (this.storageService.bcStorage.tipoIdentificacion === "INE") {
        this.storageService.bcStorage.cic = this.cic;
        this.storageService.bcStorage.claveElector = this.claveElector;
        this.storageService.bcStorage.codigoEmision = this.codigoEmision;
//        this.storageService.bcStorage.anioEmision = this.anioEmision;
//        this.storageService.bcStorage.anioRegistro = this.anioRegistro;
      } else {
        this.storageService.bcStorage.ocr = this.ocr;
        this.storageService.bcStorage.claveElector = this.claveElector;
//        this.storageService.bcStorage.codigoEmision = this.codigoEmision;
//        this.storageService.bcStorage.anioEmision = this.anioEmision;
//        this.storageService.bcStorage.anioRegistro = this.anioRegistro;
      }

      this.DataEditable(this.curp, this.ocr, this.nombre, this.apellidoPaterno,
       this.apellidoMaterno, this.claveElector, this.codigoEmision, this.cic, this.anioEmision,
       this.anioRegistro);
      console.log(this.anioRegistro);
      console.log(this.anioEmision)

        this.bcService.verificacionINEFacial(this.curp, this.ocr, this.nombre, this.apellidoPaterno,
          this.apellidoMaterno, this.claveElector, this.codigoEmision, this.cic, this.anioEmision,
          this.anioRegistro);

      this.verificacionINEFacial();
//        biochkHub.server.verificacionINEFacial(dataine);

    }
  }

  verificacionINEFacial() {
    console.log('invocando verificacionINEFacial() ')

    this.bcService.ineFacialResponse();
    this.bcService.ineFacialResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          this.ineFacialResponse(response);
        }
      }
    })
  }


  public yaFueAlIne: boolean = false;

  ineFacialResponse(response: any) {
    console.log("ENTRORESPONSEINEFCIAL");
    this.yaFueAlIne = true;
    var mensajeError = "";
    var mensajeScore1 = "";
    var mensajeScore2 = "";

    this.storageService.bcStorage.hash = "";
    this.dialogGen?.close(); //Se debe cerrar el modal

    if (response.idvCheck != null) {
      if (response.idvCheck.dataVerification != null) {
        if (response.idvCheck.dataVerification.operationData != null) {
          if (response.idvCheck.dataVerification.operationData.data != null) {
            this.storageService.bcStorage.hash = response.idvCheck.dataVerification.operationData.data;
          }
        }
      }
      if (response.idvCheck.biometricVerification != null) {
        if (response.idvCheck.biometricVerification.verificationResult != null) {
          if (response.idvCheck.biometricVerification.verificationResult.result == "HIT") {
            this.storageService.bcStorage.proceso = true;
            this.storageService.bcStorage.codigoflujo = "OKF000";
            this.storageService.bcStorage.mensajeflujo = "Validación Correcta";
            this.getFinalDate();
          } else if (response.idvCheck.biometricVerification.verificationResult.result == "NOHIT") {

            if (response.idvCheck.biometricVerification.verificationResult.reasonDescription != null || response.idvCheck.biometricVerification.verificationResult.reasonDescription != "") {
              //SACAMOS LAS RAZON DESCRIPTION
              mensajeError = response.idvCheck.biometricVerification.verificationResult.reasonDescription;

            }

            if (response.idvCheck.biometricVerification.verificationResult.reasons != null) {
              if (response.idvCheck.biometricVerification.verificationResult.reasons.length > 0) {
                mensajeScore1 = response.idvCheck.biometricVerification.verificationResult.reasons[0].reasonDescription;
              }

              if (response.idvCheck.biometricVerification.verificationResult.reasons.length > 1) {
                mensajeScore2 = response.idvCheck.biometricVerification.verificationResult.reasons[1].reasonDescription;
              }
            }
            console.log('Error Ine Facial')
            this.errorINEFacial();
          }
        }
      }
    }
  }

//Accion del boton de cancelacion
  public cancelar() {
    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  errorINEFacial() {
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.codigoflujo = "EVDF03";
    this.getFinalDate();
  };

  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
      this.router.navigateByUrl('/finalizar');
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  sendMessage(msg: string) {
    //postFinalizar(msg); no existe funcionalidad
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }


}
