import {RouterModule, Routes} from "@angular/router";
import {CapturaIdManualComponent} from "./captura-id-manual.component";
import {NgModule} from "@angular/core";


const routes: Routes = [
  {
    path:'', component: CapturaIdManualComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CapturaIdManualRoutingModule{}
