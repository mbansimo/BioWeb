import {NgModule} from "@angular/core";
import {CapturaIdManualComponent} from "./captura-id-manual.component";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {CommonModule} from "@angular/common";
import {CapturaIdManualRoutingModule} from "./capturaIdManual-routing.module";
import {FormsModule} from "@angular/forms";
import {CustomTooltipDirective} from "../../directives/custom-tooltip.directive";
import {TooltipModule} from "../tooltip/tooltip.module";
import {VerificacionVentanillaModule} from "../verificacion-ventanilla/verificacion-ventanilla.module";


@NgModule({
  declarations: [
    CapturaIdManualComponent,
  ],
  imports: [
    CommonModule,
    CapturaIdManualRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
    FormsModule,
    VerificacionVentanillaModule,
  ],
  exports: [
  ],
  bootstrap: [CapturaIdManualComponent]
})
export class CapturaIdManualModule{}







