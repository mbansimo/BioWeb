import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {CapturaRostroIneComponent} from "./captura-rostro-ine.component";

const routes: Routes = [
  {path: '', component: CapturaRostroIneComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CapturaRostroIneRoutingModule{}

