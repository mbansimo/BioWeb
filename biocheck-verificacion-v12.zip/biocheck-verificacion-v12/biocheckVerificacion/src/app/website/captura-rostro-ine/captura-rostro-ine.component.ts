import {Component, OnInit} from '@angular/core';
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {BiocheckService} from "../../core/services/biocheck.service";
import {CatalogosService} from "../../core/services/catalogos.service";
import {UtilDialogs} from "../../common/util-dialogs";
import {Router} from "@angular/router";
import {MatDialogRef} from "@angular/material/dialog";
import {DialogCapturaRostroFacialComponent} from "../../shared/dialogs/dialog-captura-rostro-facial/dialog-captura-rostro-facial.component";
import * as $ from "jquery";

@Component({
  selector: 'app-captura-rostro-ine',
  templateUrl: './captura-rostro-ine.component.html',
  styleUrls: ['./captura-rostro-ine.component.scss']
})
export class CapturaRostroIneComponent implements OnInit {

  public nombreCliente?: string;


  public ArrayAusenciasSelect = [0, 2, 0, 0, 0, 0, 7, 0, 0, 0];
  public intentosModal?: string;
  public FingerNeuro: number = 0;
  public Position: any[] = [];
  public ArrayAusencias = [];
  public winPros = null;
  public intentosINE: number = 3;
  public contadorIzquierdo: number = 0;
  public contadorDerecho: number = 0;
  public GetTwoFingers: boolean = false;
  public fingerCapturesCount: number = 0;

  public tieneApMat = (this.storageService.bcStorage.apicApellidoM) ? true : false;
  public tieneApPat = (this.storageService.bcStorage.apicApellidoP) ? true : false;
  public isCIC?: boolean = false;
  public contAusencias: number = 0;
  public EstatusCaptura: string = "";

  public dialogRef: MatDialogRef<DialogCapturaRostroFacialComponent, any> | undefined;


  constructor(
    private storageService: BcstorageService,
    private bcService: BiocheckService,
    private Pasos: BiocheckPasosService,
    private bccatalogos: CatalogosService,
    private dialogs: UtilDialogs,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
    console.log('::: iniciando Captura de Rostro :::');
    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    this.instruccion();
    this.controlDePasos();
//    this.controlDePasos();
  }

  public controlPasos: boolean = false;


  controlDePasos() {
    if (this.storageService.bcStorage.tipoVerificacion != 'verifica_motor' ){
      console.log('son cuatro passos________'+this.storageService.bcStorage.tipoVerificacion)
      this.controlPasos = true;
    }

  }

  public pasos: number = 2;

  numeroPasosyVista() {
    if (this.storageService.bcStorage.tipoVerificacion == 'verifica_motor') {
      this.pasos = 2;
    } else {
      this.pasos = 4;
    }
    console.log('NuPasosyVista_1' + this.pasos);
  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');

    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  //Fin del Header-sub

  clickFunction(pos1: number) {
    var huellaStri = '#f' + pos1;
    this.huellaStri(pos1);
  }

  public id: any = "";

  huellaStri(pos1: number) {
    this.id = $(this).attr('id');
    var numid = this.id.substring(1);
    if (this.ArrayAusenciasSelect[numid - 1] != 0) {
      $(this).removeClass("inactivo");
      $(this).addClass("ausencia");
      this.ArrayAusenciasSelect[numid - 1] = 0;
      this.ajustarContador(pos1, 1);
    } else {
      $(this).removeClass("ausencia");
      $(this).addClass("inactivo");
      this.ArrayAusenciasSelect[numid - 1] = numid;
      this.ajustarContador(pos1, -1);
    }
  }


  ajustarContador(id: number, sort: any) {
    switch (id) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        //Mano derecha
        this.contadorDerecho += (1 * sort);
        break;
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
        //Mano izquierda
        this.contadorIzquierdo += (1 * sort);
        break;
    }

  }

  cierreModal() {
    this.dialogRef?.close();
  }

  instruccion() {
    console.log('CR_1 ')
    setTimeout(() => {
      this.abrirDialog();
    }, 3000);
    console.log('CR_1_termino')
  }

  public abrirDialog(){
    this.dialogRef = this.dialogs.showDialogRostro();
  }


}
