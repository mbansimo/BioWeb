import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {CapturaRostroIneRoutingModule} from "./captura-rostro-ine-routing.module";
import {CapturaRostroIneComponent} from "./captura-rostro-ine.component";


@NgModule({
  declarations: [
    CapturaRostroIneComponent,
  ],
  imports: [
    CommonModule,
    CapturaRostroIneRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
  ],
  exports: [

  ],
  bootstrap: [CapturaRostroIneComponent]
})
export class CapturaRostroIneModule{}

