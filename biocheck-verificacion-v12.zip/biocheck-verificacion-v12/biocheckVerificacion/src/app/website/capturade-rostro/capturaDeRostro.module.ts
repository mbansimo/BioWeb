import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {CapturadeRostroComponent} from "./capturade-rostro.component";
import {CapturaDeRostroRoutingModule} from "./capturaDeRostro-routing.module";


@NgModule({
  declarations: [
    CapturadeRostroComponent,
  ],
  imports: [
    CommonModule,
    CapturaDeRostroRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
  ],
  exports: [

  ],
  bootstrap: [CapturadeRostroComponent]
})
export class CapturaDeRostroModule{}
