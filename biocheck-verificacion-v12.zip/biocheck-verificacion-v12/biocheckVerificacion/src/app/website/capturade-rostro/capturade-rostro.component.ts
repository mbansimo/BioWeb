import {Component, OnInit} from '@angular/core';
import {MatDialogRef} from "@angular/material/dialog";
import {DialogGeneralComponent} from "../../shared/dialogs/dialog-general/dialog-general.component";
import {UtilDialogs} from "../../common/util-dialogs";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {BiocheckService} from "../../core/services/biocheck.service";
import {FinalDateModel} from "../../core/models/final-date.model";
import {Router} from "@angular/router";
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import {DialogCapturaRostroComponent} from "../../shared/dialogs/dialog-captura-rostro/dialog-captura-rostro.component";
import * as $ from "jquery";
import {FormatoCapturaModel} from "../../core/models/formatoCaptura.model";


@Component({
  selector: 'app-capturade-rostro',
  templateUrl: './capturade-rostro.component.html',
  styleUrls: ['./capturade-rostro.component.scss']
})
export class CapturadeRostroComponent implements OnInit {

// variables de vista -------
  public imagenPalomita = 'assets/img/icono_palomita.png';
  public imgCorchetes = 'assets/img/corchetes.png';
  public imgUsuario = 'assets/img/usuario.png';
  public imgCaraCheck = 'assets/img/cara_check.svg'
// variables de vista ------- Fin

  public faceCaptureChances = 3; //Contador de intentos de Captura de Rostro
  public faceLivenessChances = 3; //Contador de intentos de prueba de vida


  //Esta bandera nos ayuda a saber si realizo bien la ultima instruccion
  public intentoInstruccion = false;
  public numeroInstruccion = 1;
  public anteriorInstruccion = '';
  public impedimento: boolean = false;
  public controlPasos: boolean = true;

  //Variables para control de flujo de cada etapa 1.Captura de huellas 2.Captura de Rostro 3. prueba de Vida
  public etapaHuellas: boolean = false; //1.Captura de huellas.
  public etapaRostro: boolean = false;  //2.Captura de Rostro.
  public etapaPruebaVida: boolean = false;  //3. Prueba de Vida.

  public guid: string = '';
  public dialogRef: MatDialogRef<DialogCapturaRostroComponent, any> | undefined;
  public dialogGen: MatDialogRef<DialogGeneralComponent, any> | undefined;
  public dialogPro: MatDialogRef<any, any> | undefined;

  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private dialogs: UtilDialogs,
    private router: Router,
    private Pasos: BiocheckPasosService,
  ) {
  }

  ngOnInit(): void {
    console.log('inicia vista de capturar Rostro')
    this.iniciarVista();
    console.log('Finaliza  vista de capturar Rostro:::::::::')

  }

  iniciarVista() {
    //  this.controlDePasos();
    this.storageService.bcStorage.intentosRestantes = '3';

    setTimeout(() => {
      this.faceCaptureCheck()
    }, 10000);

  }

  controlDePasos() {
    if (this.controlPasos) {
      var lista = this.Pasos.totalPasos(2);
      $('#listaPasos').append(lista);
      this.cambiarPaso(2, "Captura rostro");//revisar
      this.controlPasos = false;
    } else {
      console.log('ya se cargaron los pasos::::')
    }

  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');
    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

//-----------------Captura de rostro -------------------

  faceCaptureCheck() {
    this.etapaRostro = true;
    this.capturaDeRostro = false;
    $('#btnReintent').addClass('invisible');
    this.bcService.faceCaptureCheck([this.guid, true]);
    this.showPreviewCheckICAO();
  }

  showPreviewCheckICAO() {
    this.bcService.getShowPreviewCheckICAO();
    this.bcService.showPreviewCheckICAOResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          var img = document.getElementById("video") as HTMLImageElement;
          img.src = "data:image/png;base64," + response;
          response = "";
        }
      }
    });

    this.bcService.getShowAttibutesICAOResponse();
    this.bcService.showAttibutesICAOResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          this.showAttibutesICAOResponse(response);
        }
      }
    });
    this.failProcesador();
  }

  //recibe el dato a evaluar y su estado para pintarlo en el front
  attributeState(id: any, evaluacion: any) {
    if (evaluacion) {
      $("#evaluar" + id).css("color", "#ec0000");
      $("#imgevaluar" + id).attr("src", "assets/img/icono_tache.png");
    } else {
      $("#evaluar" + id).css("color", "#000");
      $("#imgevaluar" + id).attr("src", "assets/img/icono_palomita.png");
    }
    this.evaluarAjustes();
  };

  //revisa si algun algun parametro no es ideal para tomar el rostro
  public falloVideo: boolean = false;

  evaluarAjustes() {
    for (var x = 1; x <= 13; x++) {
      if ($("#imgevaluar" + x).attr("src") == "assets/img/icono_tache.png") {
        this.falloVideo = true;
      }
    }
  };

  showAttibutesICAO() {
    this.bcService.getShowAttibutesICAOResponse();
    this.bcService.showAttibutesICAOResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('getShowAttibutesICAOResponse::::::::')
          this.showAttibutesICAOResponse(response);
        }
      }
    });

    this.captureCheck();

  }

  //Valida los puntos de captura del rostro
  showAttibutesICAOResponse(response: any) {

    if (response.Status) {
      console.log("Condiciones favorables para la captura.");

      this.attributeState(1, false);
      this.attributeState(2, false);
      this.attributeState(3, false);
      this.attributeState(4, false);
      this.attributeState(5, false);
      this.attributeState(6, false);
      this.attributeState(7, false);
      this.attributeState(8, false);
      this.attributeState(9, false);
      this.attributeState(10, false);
      this.attributeState(11, false);
      this.attributeState(12, false);
      this.attributeState(13, false);
      this.captureCheck();
    } else {

      this.attributeState(1, response.Attributes.FaceDetected);
      this.attributeState(2, (response.Attributes.MouthOpen || response.Attributes.Expression || response.Attributes.LookingAway));
      this.attributeState(3, response.Attributes.Blink);
      this.attributeState(4, response.Attributes.RedEye);
      this.attributeState(5, (response.Attributes.Sharpness || response.Attributes.GrayscaleDensity ||
        response.Attributes.UnnaturalSkinTone || response.Attributes.ColorsWashedOut ||
        response.Attributes.Pixelation || response.Attributes.SkinReflection ||
        response.Attributes.Saturation || response.Attributes.ColorsWashedOut ||
        response.Attributes.FaceDarkness));

      this.attributeState(6, (response.Attributes.RollRight));
      this.attributeState(7, (response.Attributes.RollLeft));
      this.attributeState(8, (response.Attributes.YawRight || response.Attributes.YawLeft));

      this.attributeState(9, (response.Attributes.PitchUp || response.Attributes.PitchDown));

      this.attributeState(10, (response.Attributes.DarkGlasses || response.Attributes.GlassesReflection || response.Attributes.Hat || response.Attributes.BackgroundUniformity));
      this.attributeState(11, response.Attributes.TooFar);
      this.attributeState(12, response.Attributes.TooNear);
      this.attributeState(13, (response.Attributes.TooWest || response.Attributes.TooEast ||
        response.Attributes.TooNorth || response.Attributes.TooSouth));

    }
  }

  public fotoMini: any;
  public banderaDialogPruebaVida: boolean = true;

  //muestra la imagen captura de rostro y abre el cuadro de iniciar la prueba de vida
  captureCheck() {
    this.bcService.getcaptureCheck()
    this.bcService.captureCheck$.subscribe({
      next: (response: any) => {
        if (response != undefined && response != '') {
          this.capturaDeRostro = false;
          this.fotoMini = response;
          if (this.banderaDialogPruebaVida) {   //Bandera utilizada ya que el navegador da doble check y abreb dialigos de mas
            this.banderaDialogPruebaVida = false;             //Captura realizada con exito
            this.dialogRef = this.dialogs.showDialogFaceCaptureCheck(response, 'Iniciar prueba'); //diaogo de prueba de vida
            this.dialogRef.afterClosed().subscribe(response => {
              console.log('inicia la prueba de vida ::: o reinicia la captura');
              if (this.storageService.bcStorage.continuarFaceCaptureCheck) {  //Variable de iniciar prueba de vida
                this.continuarFaceCaptureCheck();
              } else if (this.storageService.bcStorage.reintentarFaceCaptureCheck) { //Variable para reintentar la toma
                this.reintentarFaceCapture();
              }
            });
          }
        } else {
          this.failProcesador();
        }
      }
    });
  }

  onCaptureCheck(response: any) {
    this.fotoMini = response;
    console.log('imagen::' + this.fotoMini);
    $("#imgCheckmini").css("opacity", "1");
    var img = document.getElementById("imgCheckmini") as HTMLImageElement;
    img.src = "data:image/png;base64," + response;
    response = '';
  }

  continuarFaceCaptureCheck() {
    this.storageService.bcStorage.intentosRestantes = this.faceLivenessChances.toString();
    this.etapaRostro = false;
    this.etapaPruebaVida = true;
    this.pruebaDeVida = true;
    this.cerrarModal();
    this.bcService.borradoShowPreview();
    this.bcService.faceCapture([this.guid, true]);
    this.showPreview();
    this.capturarRostro();
  }

  reintentarFaceCapture() {
    this.faceCaptureChances--;
    this.storageService.bcStorage.intentosRestantes = this.faceCaptureChances.toString();
    this.banderaDialogPruebaVida = true;
    this.bcService.showPreviewCheckICAOUnsuscribe();
    this.bcService.captureCheckObjectUnsuscribe();
    this.imgUsuario = 'assets/img/usuario.png';
    this.faceCaptureCheck();
  }


  public imgBiometrico = 'assets/img/cara_check.svg';
  public flujoStartEvaluation: boolean = true;

  showPreview() {
    this.bcService.getshowPreview();
    this.bcService.showPreviewRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('showPreviewRespuesta');
          var img = document.getElementById("Biometrico") as HTMLImageElement;
          img.src = "data:image/png;base64," + response;
          this.imgBiometrico = "data:image/png;base64," + response;
//          response = "";
        }
      }
    });

    this.bcService.getShowInstruction();
    this.bcService.showInstruction$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('showInstruction$')
          this.onShowInstruction(response);
        }
      }
    });

    this.bcService.getFacecrop();
    this.bcService.facecrop$.subscribe({
      next: (response: any) => {
        this.facecrop(response);
      }
    });

    this.fail()


  }

  public aprobadoRostroCaptura: boolean = false;
  public aprobadoHuellas: boolean = false;
  public aprobadoFail: boolean = false;

  modulosAprobados() {
    console.log('modulo aporbacion.....')
    if (this.flujoStartEvaluation) {
      this.storageService.bcStorage.tiempoMaximo = true;
      // this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatosFinal);
      this.flujoStartEvaluation = false;
      this.bcService.startEvaluation();
    }

    this.bcService.getEvaluateSuccess();
    this.bcService.evaluateSuccessResponse$.subscribe({

      next: (response: any) => {
        console.log('ingreso' + response)
        if (response || response == undefined) {
          console.log(':::getEvaluateSuccess:::');
          console.log(response);
          this.aprobadoHuellas = true;
          this.aprobadoRostroCaptura = true;
        }
      }
    });

    this.bcService.FaceAlreadyCaptured;
    this.bcService.FaceAlreadyCapturedResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log(':::FaceAlreadyCaptured:::');
          console.log(response);
          this.aprobadoRostroCaptura = true;
        }
      }
    });
  }

  public vueltaNumero: number = 0;

  pruebaVidaExitosa() {
    this.modulosAprobados();
    this.vueltaNumero++;

    this.bcService.FaceAlreadyCaptured;
    this.bcService.FaceAlreadyCapturedResponse$.subscribe(response => {
      if (response) {
        console.log(':::FaceAlreadyCaptured:::');
        console.log(response);
        this.aprobadoRostroCaptura = true;
      }

    });


    console.log('metodo prueba de vida vuelta: ' + this.vueltaNumero + 'estatus de aprobado' + this.aprobadoRostroCaptura);
    if (this.aprobadoRostroCaptura) {
      this.bcService.verify();
      this.bcService.getverifyResponse();
      this.bcService.verifyResponse$.subscribe({
        next: (response: any) => {
          if (response) {
            console.log('VerifyResponse:::');
            console.log(response);
            this.verifyResponse(response);
          }
        }
      })
    } else if (this.aprobadoFail) {
      console.log('Se invoco Fail...')
      this.dialogPro?.close();
      this.dialogPro?.close();
    } else if (!this.aprobadoRostroCaptura) {
      this.dialogPro?.close();
      this.dialogPro = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatosFinal);
      this.fail();
      setTimeout(() => {
        this.pruebaVidaExitosa();
      }, 25000);
    }
  }

  verifyResponse(response: any) {
    this.cerrarModal();
    //$.connection.hub.stop()
    if (response.code == 0) {
      if (response.result) {
        if (response.result.code === "OK0000") {
          this.storageService.bcStorage.proceso = true;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          //$(location).attr('href', '#!finalizar');
        } else {
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          //$(location).attr('href', '#!finalizar');
        }
      }
    } else {
      if (response.code == 400) {
        var obj = JSON.parse(response.message);
        if (obj.errores)
          if (obj.errores.length > 0) {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = obj.errores[0].code;
            this.storageService.bcStorage.mensajeflujo = obj.errores[0].message;
            this.storageService.bcStorage.mensajeinternoflujo = obj.errores[0].description;
          }
        if (obj.errors)
          if (obj.errors.length > 0) {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = obj.errors[0].code;
            this.storageService.bcStorage.mensajeflujo = obj.errors[0].message;
            this.storageService.bcStorage.mensajeinternoflujo = obj.errors[0].description;
          }
      } else if (response.code == 404) {
        this.storageService.bcStorage.proceso = false;
        this.storageService.bcStorage.codigoflujo = "EVB02";
      } else {
        this.storageService.bcStorage.proceso = false;
        this.storageService.bcStorage.codigoflujo = "EVB00";
      }
    }
    this.getFinalDate();
  };

  public capturaDeRostro: boolean = true;
  public pruebaDeVida: boolean = false;

  capturarRostro() {
    //Todo: iniciamos la captura de manera manual despues de la captura de huellas
    console.log('metodo CapturaRostro_>>')
    console.log(this.capturaDeRostro);
    console.log(this.impedimento);
    console.log(this.pruebaDeVida);
    if (this.capturaDeRostro) {
      this.faceCaptureCheck();
    } else if (this.impedimento) {
      this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatos);
      this.bcService.verify();

    } else if (this.pruebaDeVida) {
//      this.storageService.bcStorage.intentosRestantes = this.faceCaptureChances.toString();
      this.dialogRef = this.dialogs.showDialogPruebaVida();
    }
  }

  onShowInstruction(Instruction: any) {

    if (this.intentoInstruccion === true &&
      this.anteriorInstruccion === Instruction) {
      this.resultadoCaptura(false);
    }
    //Pintamos la instruccion
    switch (Instruction) {
      case "blink":
        $('#instruccion').text(this.numeroInstruccion + ".Parpadeé");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "turnleft":
        $('#instruccion').text(this.numeroInstruccion + ".Volteé a la izquierda y mire al frente");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "turnright":
        $('#instruccion').text(this.numeroInstruccion + ".Volteé a la derecha y mire al frente");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "keepstill":
        $('#instruccion').text(this.numeroInstruccion + ".Mire fijamente la cámara");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "frente":
        $('#instruccion').text(this.numeroInstruccion + ".Mire al frente");
        this.intentoInstruccion = true;
        this.anteriorInstruccion = Instruction;
        if ($("#capturaExitosa").text() === '¡Listo!') {
          $('.capturaExitosa').css('visibility', 'hidden');
          $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
        }
        $('#instruccion').css('color', '#000');
        $('.instrucciones').css('visibility', 'visible');
        break;
      case "turndown":
        this.resultadoCaptura(true);//Pintamos en el front el marco de verde y la palabra listo
        if (this.intentoInstruccion)
          this.numeroInstruccion++; //aumentamos el numero para mostrarlo en la siguiente instruccion
        this.intentoInstruccion = false;
        break;
      //case "none":
      //    $('#instruccion').text("No se detecta rostro del cliente");
      //    break;
      default:

        break;
    }

  }


  resultadoCaptura(exito: any) {
    if (exito) {
      $('#capturaExitosa').css('color', '#63BA68');// pintamos el texto ¡Listo! de color verde
      $('#capturaExitosa').text('¡Listo!');// Le colocamos el texto
      $('.tamanolgAzul').css('border', '3px solid #63BA68');//pintamos el marco de verde
    } else {
      $('#capturaExitosa').css('color', '#ec0000');// pintamos el texto ¡Repetir! de color rojo
      $('#capturaExitosa').text('Repetir');// Le colocamos el texto
      $('.tamanolgAzul').css('border', '3px solid rgba(195, 222, 231, 1)');
    }
    $('.instrucciones').css('visibility', 'visible');
    $('.capturaExitosa').css('visibility', 'visible');
  }//con esta funcion pintamos en el front cuando se tomo correctamente una instruccion o no

  facecrop(response: any) {
    console.log('ingreso a faceCrop::::')
    if (response.code == 0) {
      this.cerrarModal();
//      $('#capturarostro').modal('hide');
      $('.marco').css('box-shadow', 'inset 3px 2px 5px 0 #63BA68');

      var img = document.getElementById("video") as HTMLImageElement;
      img.src = "data:image/png;base64," + response.result;
      response = "";
      console.log('antes de prueba de vida exitosa')
      this.pruebaVidaExitosa();
    }
  }

//-----------------Seccion de reintentos en Captura de rostro -------------------


  reintentarFlujoCasos() {
    console.log('reintentarFlujoCasos()......')
    let tipoReintento = '';

    if (this.etapaRostro) {
      tipoReintento = 'capturaRostro';
    } else if (this.etapaPruebaVida) {
      tipoReintento = 'pruebaVida';
    } else {
      console.log('default');
    }


    switch (tipoReintento) {

      case "capturaRostro":
        this.iniciarVista();
        break;

      case "pruebaVida":
        this.faceLivenessChances--;
        this.storageService.bcStorage.intentosRestantes = this.faceCaptureChances.toString();
        this.bcService.failProcesadorUnsubscribe();
        this.continuarFaceCaptureCheck()

        break;

      default:
        break;

    }
  }


//-----------------Fin de Captura de rostro -------------------


  cerrarModal() {
    this.dialogRef?.close();
    this.dialogGen?.close();
    this.dialogPro?.close();
  }

//---------------Seccion cancelar ------------------
  cancelar() {
    this.cerrarModal();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.cerrarModal();
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.getfinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.dialogPro?.close();
    this.cerrarModal();

    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    console.log('ingreso a onFinalDato');
    this.router.navigateByUrl('/finalizar');
  }


//:::::::::Seccion de errores ::::::::

  failProcesador() {
    console.log('ingresamos a failProcesador..')
    this.bcService.getfailICAO();
    this.bcService.failICAO$.subscribe(response => {
      if (response) {
        this.failICAO(response.code, "");
      }
    });
  }

  fail() {
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      if (response) {
        this.failICAO(response.code, response.message);
      }
    })
  }

  public controlDialog: boolean = true;

  failICAO(code: any, message: any) {
    console.log('failiCao en error...')
    this.storageService.bcStorage.codigoImagenFlujo = 'LS001';
    var msg = '';
    var boton = '';
    if (parseInt(code) == 270) {
      msg = "Indica al cliente que es importante que mantenga su rostro relajado, sin sonrisas o guiños";
      boton = 'Repetir';
    }
    //alert("Indicarle al cliente que evite sonrisas, guiños.");
    else if (parseInt(code) == 262) {
      msg = "Se detectaron ojos cerrados. Indícale al cliente que: trate de parpadear suavemente; recuérdale que es sólo por un momento mientras tomas la foto.";
      boton = "Repetir";
    }
    //alert("ERROR CÓDIGO: " + code + ". " + "Se detectó ojos cerrados. Indicarle al cliente que parpadeé lentamente");
    else if (parseInt(code) == 261) {
      msg = "Indica al cliente que es importante que mantenga su rostro relajado, sin sonrisas o guiños "
      boton = "Repetir";
    }
    //alert("ERROR CÓDIGO: " + code + ". " + "Indicarle al cliente que evite sonrisas, guiños.");
    else if (parseInt(code) == 240) {
      msg = "Indica al cliente que la iluminación es escasa. Busca otra zona bien iluminada. Tips: ajusta la distancia de la cámara y/o tripie."
      boton = "Repetir";
      //alert("ERROR CÓDIGO: " + code + ". " + "Iuminación escasa en la fotografía, favor de repetir la captura buscando una zona más iluminada.");
    } else if (parseInt(code) == 280) {
      this.cerrarModal();
      msg = "Indica al cliente que la captura ha excedido el número de intentos que no es posible concluir el proceso de registro y tendrá que hacerlo en otra visita a sucursal. Agradece su tiempo."
      boton = "Finalizar";
    } else if (parseInt(code) == 300) {
      msg = "<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='assets/img/advertencia.png'></div>" +
        "<div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div>" +
        "<div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>"
      boton = "Repetir";
      //alert("ERROR CÓDIGO: " + code + ". " + "Verificar que la cámara esté conectada");
    } else if (parseInt(code) == 200) {
      msg = "Tiempo de espera excedido, favor de repetir la captura."
      boton = "Repetir";
    } else if (parseInt(code) == 250) {
      msg = "Captura no exitosa."
      boton = "Repetir";
      //alert("ERROR CÓDIGO: " + code + ". " + "Se terminaron el número de intentos permitidos, no se puede llevar acabo el registro, gracias.");
    } else if (parseInt(code) == 260) {
      msg = "Se detectó un objeto no válido para la foto."
      boton = "Repetir";
    } else if (parseInt(code) == 230) {
      this.aprobadoFail = true;
      msg = "Se encontraron huellas previamente capturadas.";
      boton = 'Repetir';
    } else {
      msg = "Ocurrió un error inesperado en la captura de rostro."
      boton = "Repetir";
    }
    console.log("codigo: " + code + " mensaje: " + message);
//    $('#btnReintent').removeClass('invisible');
    if (boton != '') {
      if (this.controlDialog) {
        this.flujoFail = false;
        this.controlDialog = false;
        this.dialogGen = this.dialogs.showDialogErrorMensajeDos(msg, boton);
        this.dialogGen.afterClosed().subscribe(response => {
          if (response) {
            this.controlDialog = true;
            this.flujoFail = true;
            if (boton == 'Finalizar') {
              this.errorFunction(code, msg);
            } else if (code == 230){
              console.log('ingrea')
              this.reintentarHuellas();
            } else {
              this.reintentarFlujoCasos()
            }
          } else {
            this.errorFunction(code, msg);
          }
        })
      }

    }
  }

  public flujoFail: boolean = true;
  //public flujoFail_VerificacionFull: boolean = true;


  reintentarHuellas(){
    console.log('ingreso al reintantar Huella...')
    this.cerrarModal();
//    this.dialogPro?.close();
    this.bcService.showPreviewCheckICAOUnsuscribe();
//    this.bcService.showAttibutesICAOResponseObjectUnsuscribe();
//    this.bcService.captureCheckObjectUnsuscribe();
//    this.bcService.showPreviewObjectUnsuscribe();
//    this.bcService.showInstructionObjectUnsuscribe();
//    this.bcService.facecropObjectUnsuscribe();
//    this.bcService.faceAlreadyCapturedObjectUnsuscribe();
//    this.bcService.verifyResponseObjectUnsuscribe();
    this.bcService.dataFingerResponseObjectUnsucribe()
    this.bcService.failICAOObjectUnsuscribe();
    this.bcService.failProcesadorUnsubscribe();
//    this.bcService.borradoShowPreview();
    this.bcService.fingerChancesObjectUnsuscribe();
    this.storageService.bcStorage.terminoFlujoRostro = 'Ok';
//    this.router.navigateByUrl('/full');
    this.intentosRestantes--;
    this.controlFlujo = true;
    this.actualizaDialog = true;
    this.flujoFail = true;
    this.dedosCapturar();

//    this.flujoFail_VerificacionFull = true;
    // @ts-ignore
    this.fingerChances(this.intentosRestantes, this.EsEscanerUnidactilar);


  }


  //// Flujo de captura de huellas

  public intentosRestantes = 3; //formatoCaptura.intentos restantes
  public boton = 'cacnelar';    //modalErrorDispositivo.boton
  public versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
  public versionInstalador = this.storageService.bcStorage.versionSistema;  //Version anterior que se encuentra en el MSI
  public intentosHuellaCliente: number = 0; //Intentos para capturar la huella
  public instruccionText: string = '';
  public combinaciones: string = '';
  public instruccionTitulo = $('#instruccion');
  public combinacion = $('#imgHuellaModal');
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public formatoCaptura!: FormatoCapturaModel;
  public EsEscanerUnidactilar = this.storageService.bcStorage.EsEscanerUnidactilar;

  public controlPasos: boolean = true;


  //Variables del Flujo
  public pulgares = '0';
  public manoDerecha: any[] = [];
  public manoIzquierda: any[] = [];
  public pulgaresambas: any[] = [];
  public dedosAvtivos: any[] = [];
  public dedosaux: any[] = [this.storageService.bcStorage.dedosaux];
  public manoD = '0';
  public manoI = '0';
  public dedoEnviar = 0;
//  public instruccion = [];
  public guid = '';
  public controlFlujo: boolean = true;
  public flujoDedosCapturar: boolean = true;
  public banderaHuella: boolean = false;
  public terminoFlujoRostro: boolean = false;




  //imagenes
  public dosManos = 'assets/img/dos_manos.png'
  public signoMas = 'assets/img/signo_mas.png';
  public caraCheck = 'assets/img/cara_check.svg';
  public reloj = 'assets/img/reloj.gif';

  dedosCapturar() {
    console.log('Cargamos dedosActivos en inicio.');

    if (this.flujoDedosCapturar) {
      this.flujoDedosCapturar = false;
      // @ts-ignore
      for (var x = 0; x < this.storageService.bcStorage.dedosAvtivos.length; x++) {
        this.dedosAvtivos.push(this.storageService.bcStorage.dedosAvtivos?.[x])
      }
    }
  }

  startcapture() {
    this.dedosCapturar();
    this.bcService.getfingerChances();
    this.bcService.fingerChances();
    this.bcService.fingerChancesRespuesta$.subscribe({
      next: (response) => {
        if (response) {
          this.fingerChances(response.intentos, response.EsEscanerUnidactilar);
        }
      }
    });
  }

  public flagFlujo: boolean = true;

  fingerChances(intentos: number, EsEscanerUnidactilar: boolean) {

    if (this.intentosRestantes < 3) {
      console.log('numero de intento:' + this.intentosRestantes)
      this.storageService.bcStorage.intentosRestantes = this.intentosRestantes.toString();
    } else {
      this.intentosRestantes = intentos;
      this.storageService.bcStorage.intentosRestantes = intentos.toString();
    }
    this.EsEscanerUnidactilar = this.storageService.bcStorage.EsEscanerUnidactilar;

//    $scope.$applyAsync();
    var flag = this.flagFlujo;
    var manoD = 0;
    this.manoI = '0'; //se declaran arriba
    this.manoD = '0';
    this.pulgares = '0';
    this.manoDerecha = [];
    this.manoIzquierda = [];
    this.pulgaresambas = [];
    this.banderaHuella = false;
    this.bcService.borradoShowPreview();


    if (EsEscanerUnidactilar) {//region para unidactilar
      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 2 ||
          this.dedosAvtivos[i] === 3 ||
          this.dedosAvtivos[i] === 4 ||
          this.dedosAvtivos[i] === 5) {
          this.manoDerecha.push(this.dedosAvtivos[i]);
          break;
        }
      }
      for (var i = 0; i <= this.manoDerecha.length - 1; i++) {
        this.manoD = this.manoDerecha.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 7 ||
          this.dedosAvtivos[i] === 8 ||
          this.dedosAvtivos[i] === 9 ||
          this.dedosAvtivos[i] === 10) {
          this.manoIzquierda.push(this.dedosAvtivos[i]);
          break;
        }

      }
      for (var i = 0; i <= this.manoIzquierda.length - 1; i++) {
        this.manoI = this.manoIzquierda.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 1 ||
          this.dedosAvtivos[i] === 6) {
          this.pulgaresambas.push(this.dedosAvtivos[i]);
          break;
        }
      }
      for (var i = 0; i <= this.pulgaresambas.length - 1; i++) {
        this.pulgares = this.pulgaresambas.join('');
      }
    } else {//region para decadactilar
      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 2 ||
          this.dedosAvtivos[i] === 3 ||
          this.dedosAvtivos[i] === 4 ||
          this.dedosAvtivos[i] === 5) {
          this.manoDerecha.push(this.dedosAvtivos[i]);
        }
      }

      for (var i = 0; i <= this.manoDerecha.length - 1; i++) {
        this.manoD = this.manoDerecha.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 7 ||
          this.dedosAvtivos[i] === 8 ||
          this.dedosAvtivos[i] === 9 ||
          this.dedosAvtivos[i] === 10) {
          this.manoIzquierda.push(this.dedosAvtivos[i]);
        }
      }

      for (var i = 0; i <= this.manoIzquierda.length - 1; i++) {
        this.manoI = this.manoIzquierda.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 1 ||
          this.dedosAvtivos[i] === 6) {
          this.pulgaresambas.push(this.dedosAvtivos[i]);
        }
      }

      for (var i = 0; i <= this.pulgaresambas.length - 1; i++) {
        this.pulgares = this.pulgaresambas.join('');
      }
    }
    console.log('variables DedoEnviar: ' + flag + ' mano_D: ' + this.manoD + ' manoI: '
      + this.manoI + ' pulgares: ' + this.pulgares)
    this.DedoEnviar(flag);
  }

  DedoEnviar(flag: boolean) {
    switch (this.manoD) {
      case '2345':
        this.dedoEnviar = 13;
        this.instruccion('índice, medio, anular y meñique derechos', '7');
        //biochkHub.server.addFinger(guid, $scope.dedoEnviar);
        break;
      case '234':
        this.dedoEnviar = 47;
        this.instruccion('índice, medio y anular derechos', '5');
        //biochkHub.server.addFinger(guid, $scope.dedoEnviar);
        break;
      case '345':
        this.dedoEnviar = 48;
        this.instruccion('medio, anular y meñique derechos', '11');
        //biochkHub.server.addFinger(guid, );
        break;
      case '23':
      case '235':
        this.instruccion('índice y medio derechos', '3');
        this.dedoEnviar = 40;
        //biochkHub.server.addFinger(guid, $scope.dedoEnviar);
        break;
      case '2':
      case '245':
      case '24':
      case '25':
        this.dedoEnviar = 2;
        this.instruccion('índice derecho', '2');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '3':
      case '34':
      case '35':
        this.dedoEnviar = 3;
        this.instruccion('medio derecho', '9');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '4':
      case '45':
        this.dedoEnviar = 4;
        this.instruccion('anular derecho', '1');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '5':
        this.dedoEnviar = 5;
        this.instruccion('meñique derecho', '13');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '0':
        switch (this.manoI) {
          case '78910':
            this.dedoEnviar = 14;
            this.instruccion('índice, medio, anular y meñique izquierdos', '8');
            //FingerNeuro = 14;
            break;
          case '789':
            this.dedoEnviar = 49;
            this.instruccion('índice, medio y anular izquierdos', '6');
            //FingerNeuro = 49;
            break;
          case '8910':
            this.dedoEnviar = 50;
            this.instruccion('medio, anular y meñique izquierdos', '12');
            //FingerNeuro = 50;
            break;
          case '78':
          case '7810':
            this.dedoEnviar = 43;
            this.instruccion('índice y medio izquierdos', '4');
            //FingerNeuro = 43;
            break;
          case '7':
          case '7910':
          case '79':
          case '710':
            this.dedoEnviar = 7;
            this.instruccion('índice izquierdo', '18');
            //FingerNeuro = 7;
            break;
          case '8':
          case '89':
          case '810':
            this.dedoEnviar = 8;
            this.instruccion('medio izquierdo', '10');
            //FingerNeuro = 8;
            break;
          case '9':
          case '910':
            this.dedoEnviar = 9;
            this.instruccion('anular izquierdo', '19');
            //FingerNeuro = 9;
            break;
          case '10':
            this.dedoEnviar = 10;
            this.instruccion('meñique izquierdo', '14');
            //FingerNeuro = 10;
            break;
          case '0':
            switch (this.pulgares) {
              case '1':
                this.dedoEnviar = 1;
                this.instruccion('pulgar derecho', '16');
                break;
              case '16':
                this.instruccion('pulgar derecho e izquierdo', '17');
                this.dedoEnviar = 15;
                break;
              case '6':
                this.instruccion('pulgar izquierdo', '15');
                this.dedoEnviar = 6;
                break;
              case '0':
                flag = false;

                this.cerrarModal();
                if (this.terminoFlujoRostro) {
                  console.log('ingreso a la prueba de vida exitosa')
                  this.pruebaVidaExitosa();
                } else {
                }

                break;
              default:
                break;

            }
            break;
          default:
            break;

        }
        break;
      default:
        break;
    }

    if (this.dedoEnviar != 0 && flag) {
      this.dedosSolicitados = this.dedoEnviar;
      this.flagFlujo = false;
      //INICIA CAPTURA DE HUELLAS
      console.log('dedo Enviar ' + this.dedoEnviar + ':::::::');
      console.log('control del flujo ' + this.controlFlujo);
      if (this.controlFlujo) {
        this.controlFlujo = false;
        this.bcService.addFinger([this.guid, this.dedoEnviar]);
        this.bcService.getshowPreview()
        this.bcService.showPreviewRespuesta$.subscribe({
          next: (response: any) => {
            if (response) {
              $("#preview").css("opacity", "1");
              $("#preview").attr('src', 'data:image/png;base64,' + response);
//          this.preview.css("opacity", "1");
//          this.preview.attr('src', 'image/png;base64,' + response);
//          this.preview.data('src', 'data:image/png;base64,' + response)
              //var img = document.getElementById("preview") as HTMLImageElement;
              //img.src = "data:image/png;base64," + response;

              response = "";
//          segunda.unsubscribe;

              this.dataFinger();
            } else {
              this.failProcesador();
            }
          }
        });
      }
    }
  }

  public actualizaDialog: boolean = true;
  public dedosSolicitados: number = 0;
  public banderaAddFinger: boolean= true;



  instruccion(inst: string, dedo: string) {
    this.instruccionText = inst;  //'#instruccion'
    this.combinaciones = 'assets/img/combinaciones/' + dedo + '.png'; //'#imgHuellaModal'
    this.preview.addClass("std-opacidad-huella");
    this.preview.attr('src', 'img/combinaciones/' + dedo + '.png');
    this.cerrarModal();
    if (this.dedoEnviar != this.dedosSolicitados) {
      this.actualizaDialog = true;
      this.banderaAddFinger = true;
    }
    console.log('instruccion ' + this.actualizaDialog)


    if (this.actualizaDialog) {
      console.log('creando dialog de solicitud de huella ....');
      this.actualizaDialog = false;
      this.dialogPro = this.dialogs.showModalSolicitaHuella(this.combinaciones, this.instruccionText, this.intentosRestantes);

    }
  }

  addFinger() {
    this.bcService.getshowPreview()
    const segunda = this.bcService.showPreviewRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          $("#preview").css("opacity", "1");
          var img = document.getElementById("preview") as HTMLImageElement;
          img.src = "data:image/png;base64," + response;
          this.preview.attr('src', 'data:image/png;base64,' + response);

          response = "";
          segunda.unsubscribe;

          this.controlFlujo = false;
          this.dataFinger();
        } else {
          this.failProcesador();
        }
      }
    });
  }

  public banderaHuella: boolean = false;

  dataFinger() {
    this.controlFlujo = true;

    this.bcService.getDataFinger();
    this.bcService.dataFingerResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          this.actualizaDialog = true;
          setTimeout(() => {
            this.statusCapturaExitoso();
          }, 1000);

          console.log('aqui vamos _________');
//          setTimeout(() => {
            if (this.bcService.dataFingerResponseObject.value != '') {
              this.flagFlujo = true;
              console.log('ingreso al log de dedos activos ')
              for (var x = 0; x < response.length; x++) {
                this.banderaHuella = true;
                var index = this.dedosAvtivos.indexOf(response[x]);
                if (index > -1) {
                  this.dedosAvtivos.splice(index, 1);
                }
              }
              if (this.EsEscanerUnidactilar) {
                this.fingerChances(this.intentosRestantes, this.EsEscanerUnidactilar);
              }
            }
 //         }, 2000);
        }
      }
    });
  }

  public statusCapturaExitoso() {
    $('#colorMarco').css('visibility', 'visible');
    //this.estatusCaptura = "Huellas Capturadas";
    $('.marcoHuella').css('border-color', '#63BA68');
    $('#marcoHuella').addClass('border-green');
  } //Cambios visuales cuando la captura de huella fue exitosa

  controlDeFlujo() {
    if (this.dedosAvtivos[0] == 1 && this.dedosAvtivos[1] == 6 && this.dedoEnviar == 15) {
      this.dedosAvtivos = [];
    }
  }

  pruebaVidaExitosaHuella() {
    this.modulosAprobados();
    this.vueltaNumero++;
    console.log('metodo prueba de vida vuelta: ' + this.vueltaNumero + 'estatus de aprobado' + this.aprobadoRostroCaptura);
    if (this.aprobadoRostroCaptura) {
      this.bcService.verify();
      this.bcService.getverifyResponse();
      this.bcService.verifyResponse$.subscribe({
        next: (response: any) => {
          if (response) {
            console.log('VerifyResponse:::');
            console.log(response);
            this.verifyResponse(response);
          }
        }
      })
    } else if (this.aprobadoFail) {
      console.log('Se invoco Fail...')
      this.dialogPro?.close();
      this.dialogPro?.close();
    } else if (!this.aprobadoRostroCaptura) {
      this.dialogPro?.close();
      this.dialogPro = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatosFinal);
      this.failProcesador();
      setTimeout(() => {
        this.pruebaVidaExitosa();
      }, 25000);
    }
  }







}
