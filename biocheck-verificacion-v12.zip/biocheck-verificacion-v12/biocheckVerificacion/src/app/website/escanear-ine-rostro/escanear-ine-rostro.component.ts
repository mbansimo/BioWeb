import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {MatDialogRef} from "@angular/material/dialog";
import {DialogGeneralComponent} from "../../shared/dialogs/dialog-general/dialog-general.component";
import {BiocheckService} from "../../core/services/biocheck.service";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {Router} from "@angular/router";
import {UtilDialogs} from "../../common/util-dialogs";
import {EscanearService} from "../../core/services/escanear.service";
import {RespuestaControlErroresModel} from "../../core/models/respuesta-control-errores.model";
import {FinalDateModel} from "../../core/models/final-date.model";
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import * as $ from "jquery";
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";

@Component({
  selector: 'app-escanear-ine-rostro',
  templateUrl: './escanear-ine-rostro.component.html',
})
export class EscanearIneRostroComponent implements OnInit {


  //variables de carga de pantalla
  public headerVista = 'Escanear credencial de elector';
  public headerInstrucciones = 'Introduce la identificación y da clic en el botón de escanear.';
  public frenteIne = 'Frente de la credencial';
  public reversoIne = 'Vuelta de la credencial';
  public btnCancelar = 'Cancelar';
  public modalInstrucciones: boolean = false;
  public nombreCliente?: string;

  //Variables reset escáner
  public intentosReiniciarEscaner = 0;
  public intentosResetEscanerDoc = 3;
  public esReintentoEscaner = false;
  //Variables reset escáner

  public timer: boolean = true;
  public timerRun: boolean = false;
  public timerScreen = "00 : 00 : 00 : 00";
  public isMarch = false;
  public acumularTime = 0;
  public control: any;

  public imgHelp = 'assets/img/svg/ayuda.svg';
  public imgIneFront = 'assets/img/ine/ine-front.png';
  public imgIneBack = 'assets/img/ine/ine-back.png';
  public timeActual: any;
  public timeInicial: any;
  public procesadorInvoked: boolean = false; //bandera para saber si ya se invoco procesador y no invocarlo nuevamente
  public btnEscanear: string = ''; //texto del botón
  public tieneIne!: boolean; // en el código no se utiliza, solo se llama en guardarDatosEscaneados
  public instruccionife: string = 'Escaneando documento.';
  public invokedScanDocumentActived: boolean = false;

  // scope
  public scan: boolean = true; //esta variable es para saber si el boton escaneara o ira a la siguiente pagina
  public respuestaInstruccion: any;
  public regresoRespuesta: boolean = false;
  public errorEscaner!: boolean;
  public errorGeneral!: boolean;
  public dialogRef: MatDialogRef<DialogGeneralComponent, any> | undefined;
  public subHeaderBio: boolean = true;


  public respuestaNacional = `

      Identificación incorrecta:
        Para continuar con el proceso, favor de proporcionar una credencial para votar.
      `;

  public errorVigencia = `
   Indica al cliente que la identificación no está vigente
        que es importante que actualice su identificación
        para realizar cualquier trámite con el banco.`;


  constructor(
    private bcService: BiocheckService,
    private cdRef: ChangeDetectorRef,
    private storageService: BcstorageService,
    private Pasos: BiocheckPasosService,
    private router: Router,
    private dialogs: UtilDialogs,
    private escanearService: EscanearService
  ) {
    //this.bcService.crearConexion();
    this.storageService.bcStorage.documentScan = 1; // 1 = ife/ine   2 = FM   3 = Pasaporte
  }

  ngOnInit(): void {
    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;

//    this.bcService.initializeSignalConnection();
//    this.bcService.connectionScaner$.subscribe(response => {
//      if (response) {
//        console.log('Connected...' + response);
        //this.start();
        this.scan = true;
        this.storageService.bcStorage.isCIC = false;
        this.storageService.bcStorage.signalrStopped = false;
        //        this.verificarEscanerDocumentos(); // despues de iniciar conexión verifica escaner documentos
        this.inicializarVista();
        //this.instructionScan();
//      } else {
        //    this.bcService.checkService()
//      }

//    })

//    this.bcService.initializeSignalConnection();
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      // this.start()
    }, 0);
    this.cdRef.detectChanges();
  }

  public controlPasos: boolean = true;


  controlDePasos() {
    if (this.controlPasos) {
      const lista = this.Pasos.totalPasos(4);
      this.controlPasos = false;
      $('#listaPasos').append(lista);
      this.cambiarPaso(3, "Escanear identificacion");//revisar
    } else {
      console.log('ya se cargaron los pasos::::')
    }
  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');

    $("#nombrePasoActual").text(nombre);
    for (let i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  //Fin del Header-sub


  start() {
    this.timer = false;
    this.timerRun = true;
    if (!this.isMarch) {
      this.timeInicial = new Date();
      this.control = setInterval(this.cronometro, 10);
      this.isMarch = true;
    }
  }

  cronometro() {
    this.timeActual = new Date();
    this.acumularTime = this.timeActual - this.timeInicial;
    let acumularTime2 = new Date();
    acumularTime2.setTime(this.acumularTime);
    let cc: number | string = Math.round(acumularTime2.getMilliseconds() / 10);
    let ss: number | string = acumularTime2.getSeconds();
    let mm: number | string = acumularTime2.getMinutes();
    let hh: number | string = acumularTime2.getHours() - 18;
    if (cc < 10) {
      cc = `0${cc}`;
    }
    if (ss < 10) {
      ss = `0${ss}`;
    }
    if (mm < 10) {
      mm = `0${mm}`;
    }
    if (hh < 10) {
      hh = `0${hh}`;
    }
    this.timerScreen = `${hh}: ${mm}: ${ss}: ${cc}`;
    return this.timerScreen;
  }


  stop() {
    if (this.isMarch) {
      clearInterval(this.control);
      this.isMarch = false;
    }
  }

  resume() {
    if (!this.isMarch) {
      let date = new Date();
      let timeActu2 = date.getTime();
      let acumularResume = timeActu2 - this.acumularTime;

      this.timeInicial.setTime(acumularResume);
      this.control = setInterval(this.cronometro, 10);
      this.isMarch = true;
    }
  }

  reset() {
    if (this.isMarch) {
      clearInterval(this.control);
      this.isMarch = false;
    }
    this.acumularTime = 0;
    this.timerScreen = "00 : 00 : 00 : 00";
  }

  restart() {
    this.reset();
    this.start();
  }


  dialogA() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan(this.instruccionife, false);
    this.dialogRef.afterClosed().subscribe(response => {
      console.log('dialogA....')
      this.onAbrirModalErrorSinEscaner();
    });
  }

  dialogB() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan('Voltear documento', true, 'Escanear');
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {
          this.scanSideB();
        }
      }
    );
  }

  onCerrandoModalErrorSinEscaner() {
    if (this.respuestaInstruccion.Message === undefined || typeof this.respuestaInstruccion.Message === 'undefined' || /(esc(a|á)ner de documentos.*conectado)|(conexiones.*esc(a|á)ner de documentos)/i.test(this.respuestaInstruccion.Message)) {
      this.estadoInicialImagenes();
      const msg = "Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5";
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogError(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.textoBtnScanear(true);
          try {
            this.sendLog('warning', '', msg);
          } catch (tryError) {
          }
        }
      });
    }
  }


  //funcion inicial para la vista
  inicializarVista() {
    this.textoBtnScanear(true);
    this.subHeaderBio = true;
    //this.controlDePasos();

    //NO SE SI ES OPEN O SE EJECUTA?
    //const dialogRef = this.dialogs.showDialogInsctructionScan(this.instruccionife, false);
    //dialogRef.afterClosed().subscribe( response => {
    //});
  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  //Cambia el texto del boton a "escanear" o "continuar" ademas de que decide el flujo
  textoBtnScanear(valor: boolean) {
    if (valor) {
      this.scan = true;
      this.btnEscanear = "Escanear";
    } else {
      this.scan = false;
      this.btnEscanear = "Continuar";
    }
  }

  estadoInicialImagenes() {
    this.imgIneFront = 'assets/img/ine/ine-front.png';
    this.imgIneBack = 'assets/img/ine/ine-back.png';
    this.estadoInicialImagenesJquery();
  }

  estadoInicialImagenesJquery() {
    let frente = $("#frente");
    if (frente.length > 0) {
      frente.attr("src", this.imgIneFront);
      frente.css("opacity", ".3");
      //frente.val('assets/img/ine/ine-front.png');
    }
    let atras = $("#atras");
    if (atras.length > 0) {
      atras.attr("src", this.imgIneBack);
      atras.css("opacity", ".3");
    }


  }

  guardarDatosEscaneados(responseEscaner: any) {
    if (responseEscaner.ClassName == 'Voter Identification') {
      this.escanearService.guardarDatos(responseEscaner, 1);
      this.tieneIne = true;
      this.storageService.bcStorage.esIne = true;
    } else {
      this.storageService.bcStorage.esIne = false;
      responseEscaner.message = "";
    }
    //Revisamos si se escanearon correctamente los dos lados
    return !!(this.storageService.bcStorage.imagenFrente && this.storageService.bcStorage.imagenAtras);
  }

  validarVigencia(existeVigencia: any, fecha: string) {
    const fechaDeHoy = new Date();
    const anio = fechaDeHoy.getFullYear();
    return existeVigencia
      ? anio <= parseInt(fecha) ? true : false
      : false;
  }

  /**
   * FUNCIONES DE RESPUESTA
   */
  onErrorEscaner(responseEscaner: string) {
    this.respuestaInstruccion = responseEscaner;
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogError(responseEscaner, 'OK');
    this.dialogRef.afterClosed().subscribe(() => {
      this.textoBtnScanear(true);
      try {
        this.sendLog('warning', '', responseEscaner);
      } catch (tryError) {
        // ignored
      }
    });
  }

  onRespuestaEscaner(response: any) {
    console.log('onRespuestaEscaner: ' + response)
    if (this.errorEscaner && this.respuestaInstruccion.Code === 3 && response.Success && (/cancel/i.test(response.Message) || /no detectada/i.test(response.Message))) {
      return;
    }
    // $scope.onCerrandoModalErrorSinEscaner = function () { };
    // if ($("#instrucciones").modal("show")) {
    //     $("#instrucciones").modal("hide");
    //     //setTimeout(function(){$(location).attr('href', '#!/Ejecutivo/ocrdeife')},3000);
    // }
    // if (modalInstrucciones.isOpen()) {
    //     modalInstrucciones.close();
    //     //crearModal();
    // }
    this.sendLog('warning', '', response.Message);

    if (response.Message === 'Side A') {
      this.dialogB();
      return;
    }

    if (response) {
      if (response.Success) {
        if (response.Alertas != null) {
          const data = response.Alertas.filter((alerta: any) => alerta.Valido == false); // filtrar las que Valido = false
          this.storageService.bcStorage.mensajeinternoflujo = (data != undefined && data != null && data.length >= 0) && data;
        }
        //checamos si es valido el documento escaneado
        if (response.valid) {
          //Revisamos si obtuvo los datos necesarios
          if (this.guardarDatosEscaneados(response)) {
            // se valida si existencia vigencia es true
            if (this.storageService.bcStorage.existenciaVigencia) {
              /* !!! MXSLBIOM-2448 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2019 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. Se deberá modificar la bandera no eliminarla, es decir, cuando termine la prórroga del INE se puede volver hacer las validaciones de las vigencias actuales.
              * !!! MXBIOC-193 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2020 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. ====================================== */
              let anioVigencia = parseInt((this.storageService.bcStorage.vigencia) ? this.storageService.bcStorage.vigencia : 0);
              const listEstadosVigencia = this.storageService.bcStorage.EstadosVigenciaIne !== undefined ? this.storageService.bcStorage.EstadosVigenciaIne.split(',') : "";
              const ExisteEstado = listEstadosVigencia !== "" ? listEstadosVigencia.find(value => value == this.storageService.bcStorage.ClaveEntidad) : false;
              const fechaDeHoy = new Date();
              const anio = fechaDeHoy.getFullYear() - 1; //año valido vigente
              const reglaOmitirVigencia = this.storageService.bcStorage.OmitirVigenciaIne === true && anioVigencia === anio && ExisteEstado !== undefined;
              if (reglaOmitirVigencia || this.validarVigencia(this.storageService.bcStorage.existenciaVigencia, this.storageService.bcStorage.vigencia)) {
                this.errorEscaner = false;
                this.errorGeneral = false;
                this.storageService.bcStorage.proceso = true;
                this.textoBtnScanear(false);
                this.dialogRef?.close();
              } else {
                this.errorGeneral = true;
                this.estadoInicialImagenes();
                this.textoBtnScanear(true);
                this.dialogRef?.close();
                this.dialogRef = this.dialogs.showDialogError(this.errorVigencia, 'Finalizar');
                this.dialogRef.afterClosed().subscribe(response => {
                  if (response) {
                    this.errorFunction("EOB09");
                    try {
                      this.sendLog('warning', '', this.errorVigencia);
                    } catch (tryError) {
                    }
                  }
                });
              }
            } else { // existencia vigencia es false
              this.errorGeneral = true;
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(this.errorVigencia, 'Finalizar');
              this.dialogRef.afterClosed().subscribe(response => {
                if (response) {
                  this.errorFunction("EBC00");
                  try {
                    this.sendLog('warning', '', this.errorVigencia);
                  } catch (tryError) {
                  }
                }
              });
            }
            //valida que se haya escaneado una PASAPORTE
          } else if (!this.storageService.bcStorage.esIne) {
            this.errorGeneral = true;
            const documentoNoValido = this.escanearService.controlErrores(response, 1);
            const isRepetir = documentoNoValido.msjBoton == 'Repetir';
            const addLabel = isRepetir ? '' : ':ErrorCode:EOB09';
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(documentoNoValido.mensajeError, `${documentoNoValido.msjBoton} ${addLabel}`);
            this.dialogRef.afterClosed().subscribe(
              response => {
                if (response) {
                  if (isRepetir) {
                    this.textoBtnScanear(true);
                    this.estadoInicialImagenes();
                  } else {
                    this.errorFunction('EOB09');
                  }
                }
                try {
                  this.sendLog('warning', '', documentoNoValido.mensajeError);
                } catch (tryError) {
                }
              }
            );
          } else {  // no obtuvo los datos necesarios
            this.errorGeneral = false;
            const mensaje = "Debe escanear ambos lados de la identificación";
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(mensaje, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.textoBtnScanear(true);
                this.estadoInicialImagenes();

                try {
                  this.sendLog('warning', '', mensaje);
                } catch (tryError) {
                }
              }
            });
          }
        } else { //no es valido el documento escaneado
          try {
            this.guardarDatosEscaneados(response);
          } catch (error) {
          }
          this.errorGeneral = true;
          const documentoNoValido: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 1);
          this.textoBtnScanear(true);
          //TypeModal es 2
          if (response.TypeModal === 2) {
            let documentoCaducado = false;
            if (!/no permite la captura/ig.test(response.Message)) {
              let vigencia = '';
              //Esto es para la clave de lector de INE
              response.Values.forEach((v: any, i: number) => {
                //vigencia
                if (v.Name == "VIZ Expiration Date") {
                  vigencia = v.Value;
                  const fechaDeHoy = new Date();
                  //fecha de hoy
                  const dd = fechaDeHoy.getDate();
                  const mm = fechaDeHoy.getMonth() + 1;
                  const yyyy = fechaDeHoy.getFullYear();
                  const date_regex = /^(0[1-9]|1\d|2\d|3[01])\-(0[1-9]|1[0-2])\-(19\d{2}|2\d{3})$/;//Esta epresion regular revisa que la vigencia tenga el formato correcto
                  //aqui evaluamos que la vigencia sea valida
                  if (date_regex.test(vigencia)) {
                    const fecha = v.Value.split('-');
                    const anioEscan = parseInt(fecha[2]);
                    const mesEscan = parseInt(fecha[1]) - 1;
                    const diaEscan = parseInt(fecha[0]);
                    const vigenciafecha = new Date(anioEscan, mesEscan, diaEscan);
                    documentoCaducado = vigenciafecha < fechaDeHoy && true;
                  }
                }
              });
            }
            if (documentoCaducado) {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(this.errorVigencia, 'Finalizar');
              this.dialogRef.afterClosed().subscribe(response => {
                if (response) {
                  this.errorFunction('EOB09', documentoNoValido.mensajeErrorLegible)
                  try {
                    this.sendLog('warning', '', this.errorVigencia);
                  } catch (tryError) {
                  }
                }
              });
            } else {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(documentoNoValido.mensajeError, documentoNoValido.msjBoton);
              this.dialogRef.afterClosed().subscribe(response => {
                if (response) {
                  if (documentoNoValido.msjBoton === 'Repetir') {
                    this.textoBtnScanear(true);
                    this.estadoInicialImagenes();
                  } else {
                    this.errorFunction("EOB09", documentoNoValido.mensajeErrorLegible)
                  }
                  try {
                    this.sendLog('warning', '', documentoNoValido.mensajeError);
                  } catch (tryError) {
                  }
                }
              });
            }
            //TypeModal es 3
          } else if (response.TypeModal == 3) {
            if (response.Message === 'DocumentoErroneo') {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(this.respuestaNacional, 'Repetir');
              this.dialogRef.afterClosed().subscribe(() => {
                try {
                  this.sendLog('warning', '', this.respuestaNacional);
                } catch (tryError) {
                }
              });
            } else {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(response.Message, 'Repetir');
              this.dialogRef.afterClosed().subscribe(() => {
                try {
                  this.sendLog('warning', '', response.Message);
                } catch (tryError) {
                }
              });
            }
          } else { // TypeModal no es 2 ni 3
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(this.respuestaNacional, 'Repetir');
            this.dialogRef.afterClosed().subscribe(() => {
              try {
                this.sendLog('warning', '', this.respuestaNacional);
              } catch (tryError) {
              }
            });
          }
        }
      } else { // Response no success
        this.textoBtnScanear(true);
        if (response.ScanBothSides) {
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogError(this.respuestaNacional, 'Repetir');
          this.dialogRef.afterClosed().subscribe(() => {
            try {
              this.sendLog('warning', '', this.respuestaNacional);
            } catch (tryError) {
            }
          });
        } else if (response.Message === 'Identificación no detectada.') {
          const msg = 'Por favor vuelve a escanear la identificación'
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogError(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(() => {
            try {
              this.sendLog('warning', '', msg);
            } catch (tryError) {
            }
          });
        } else {
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogError(response.Message, 'Repetir');
          this.dialogRef.afterClosed().subscribe(() => {
            try {
              this.sendLog('warning', '', response.Message);
            } catch (tryError) {
            }
          });
        }
      }
    } else { // NO RESPONSE
      this.textoBtnScanear(true);
      const documentoNoSuccess: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 3);
      this.dialogRef?.close()
      this.dialogRef = this.dialogs.showDialogError(documentoNoSuccess.mensajeError, documentoNoSuccess.msjBoton);
      this.dialogRef.afterClosed().subscribe(() => {
        try {
          this.sendLog('warning', '', documentoNoSuccess.mensajeError);
        } catch (tryError) {
        }
      });
      this.errorGeneral = true;
    }
  }

  onRespuestaInstruccion(responseEscaner: any) {

    this.respuestaInstruccion = responseEscaner;
    switch (responseEscaner.Code) {
      case 1:
      case 4:
        this.errorEscaner = false;
        break;
      case 5:
      case 6:
        this.errorEscaner = true;
        this.onCerrandoModalErrorSinEscaner();
        break;
      case 7:
        this.instruccionife = 'Escaneando documento.';
//        this.responseScan();
        break;

      default:
        this.instruccionife = responseEscaner.Message;
        break;
    }
  }

  /**
   * END FUNCIONES DE RESPUESTA
   */

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    if (this.storageService.bcStorage.proceso) {
      this.router.navigateByUrl('/finalizar');
    } else {
      this.respuesta();
    }
  }

  onAbrirModalErrorSinEscaner() {
    if (!this.invokedScanDocumentActived) {
      console.log('onAbrirModalErrorSinEscaner...');
      this.bcService.invokeScanDocument([1]);
      this.invokedScanDocumentActived = true;
    }
  }

  /**
   * INICIA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
   */

  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.getFinalDate();
  }

  scanSideB() {
    this.bcService.invokeScanDocumentManual([1]);
    // modalInstrucciones.open();
    const resp = {Code: 7, Message: "Escaneando documento."};
    this.bcService.invokeScanDocument([1]);
    this.dialogA();
    this.onRespuestaInstruccion(resp);
  }

  respuestaProcesador() {
    this.bcService.respuestaProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      if (response) {
        console.log('response', response)
        const id = response.id;
        switch (id) {
          case 'VerificarEstatusEscanerDoc':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Verificar si el escaner está conectado y online
              this.activarModoManualEscaner();
            }
            break;
          case 'VerificarEscanerConectadoOnline':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Poner el flujo que se quiere ejecutar en la respuesta
              this.activarModoManualEscaner();
            }
            break;
          case 'ActivarModoManualEscaner':
            // this.startScanProcess();
            // Se ejecuta función que indica que los dispositivos se chequearon con éxito ??
            break;
          default:
            break;
        }
      }
    });
  }

  failProcesador() {
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      if (response) {
        console.log(response.code);
        const code = parseInt(response.code);
        let msg = '';
        if (code === 330) {
          //modalerror2
          msg = `Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              // this.errorFunction();
              // CHECAR error EN CODIGO
            } else {
              this.cancelarinfo();
            }
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 331) {
          //modalerror
          msg = `Servicio de escaneo de documentos no pudo ser iniciado.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 332) {
          //modalerror
          msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 333) {
          //Si hay intentos, verifica el estatus del escáner
          if (this.intentosReiniciarEscaner < this.intentosResetEscanerDoc) {
            this.intentosReiniciarEscaner++;
            this.esReintentoEscaner = true;
            //modalerror2
            msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5`;
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.verificarEscanerDocumentos();
              } else {
                this.cancelarinfo();
              }
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          } else { //Si no hay intentos, notifica y termina flujo
            //modalerror
            msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.errorServiciosEscaner();
              }
              ;
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          }
        } else if (code === 350) {
          //modalerror
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(response.message, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        }
      }
    });
  }

  verificarEscanerDocumentos() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEstatusEscanerDoc", {});
    })
  }

  verificarEscanerConectadoOnline() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEscanerConectadoOnline", {});
    })
  }

  activarModoManualEscaner() {
    this.controladorFunciones("ActivarModoManualEscaner", {});
  }

  controladorFunciones(id: string, parametrosEntrada: any) {
    const funcion = {
      Id: id,
      ParametrosEntrada: parametrosEntrada
    };
    this.bcService.procesador([funcion]); // si es necesario no invocarlo lo metemos en if de abajo
    if (!this.procesadorInvoked) {
      this.procesadorInvoked = true;
    }
  }

  errorServiciosEscaner() {
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.codigoflujo = "ELB01";
    this.getFinalDate();
  }

  /**
   * Función para error en los servicios del escaner de documentos
   * TERMINA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
   */

  public failScan() {
    this.bcService.getFailScan();
    this.bcService.responseScan$.subscribe({
      next: response => {
        if (response) {
          this.onErrorEscaner(response);
        }
      }
    });
  }

  responseScan() {
    this.bcService.getResponseScan();
    console.log('ingreso a getResponseScan');
    this.bcService.responseScan$.subscribe(response => {
      console.log(response)
      if (response) {
        if (response.Message !== 'Side A') {
          this.stop();
        }
        this.onRespuestaEscaner(response);
      }
//        this.failScan();
    });


    /*    this.bcService.getResponseScanIneFacial()
        this.bcService.responseScan$.subscribe(response => {
            console.log(response)
            if (response) {
              if (response.Message !== 'Side A') {
                this.stop();
              }
              this.onRespuestaEscaner(response);
            }
    //        this.failScan();
          });*/

  }

  instructionScan() {
    this.bcService.getInstructionScan();
    this.bcService.instruccionesScaner$.subscribe({
      next: response => {
        console.log('instruccion lleva esto:: ');
        console.log(response);
        if (response) {
          this.onRespuestaInstruccion(response);
        }
      }
    });
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  sendMessage(msg: string) {
    this.postFinalizar(msg); // no existe funcionalidad
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  // Acción del botón
  continuar() {
    if (this.scan) {
      console.log(this.instruccionife);
      this.onAbrirModalErrorSinEscaner();
      this.dialogA();
      this.instructionScan();
      this.responseScan();
      console.log('salio del responseScan')
    } else {
      this.getFinalDate();
    }
  }

  cancelar() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCancelar();
    this.dialogRef.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }


  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "PaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  postFinalizar(msg: string) {
    console.log(msg);
    alert(msg);
  }


}
