import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {EscanearIneRostroComponent} from "./escanear-ine-rostro.component";
import {EscanearIneRostroRoutingModule} from "./escanear-ine-rostro-routing.module";


@NgModule({
  declarations: [
    EscanearIneRostroComponent,
  ],
  imports: [
    CommonModule,
    EscanearIneRostroRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
  ],
  exports: [

  ],
  bootstrap: [EscanearIneRostroComponent]
})
export class EscanearIneRostroModule{}
