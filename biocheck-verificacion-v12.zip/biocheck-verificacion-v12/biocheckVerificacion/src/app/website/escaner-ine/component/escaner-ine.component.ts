import { Component, OnInit, NgZone } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MessagesDialogProcesando } from 'src/app/common/msgs-dialog';
import { UtilDialogs } from 'src/app/common/util-dialogs';
import { FinalDateModel } from 'src/app/core/models/final-date.model';
import { RespuestaControlErroresModel } from 'src/app/core/models/respuesta-control-errores.model';
import { BcstorageService } from 'src/app/core/services/bcstorage.service';
import { BiocheckService } from 'src/app/core/services/biocheck.service';
import { EscanearService } from 'src/app/core/services/escanear.service';
import { DialogGeneralComponent } from 'src/app/shared/dialogs/dialog-general/dialog-general.component';
import * as $ from "jquery";
import { BiocheckUtils } from 'src/app/core/services/biocheck-utils.service';
import { BiocheckCurp } from 'src/app/core/services/biocheck.bCurp.service';
import { DialogHuellasComponent } from 'src/app/shared/dialogs/dialog-huellas/dialog-huellas.component';


@Component({
  selector: 'app-home',
  templateUrl: './escaner-ine.component.html',
  styleUrls: ['./escaner-ine.component.css']
})
export class EscanerIneComponent implements OnInit {

  //#region VARIABLES ESCANER INE
  public verEscanerIne: boolean = false;
  public headerVista = '';
  public headerInstrucciones = 'Introduce la identificación y da clic en el botón de escanear.';
  public frenteIne = 'Frente de la credencial';
  public reversoIne = 'Vuelta de la credencial';
  public btnCancelar = 'Cancelar';
  public modalInstrucciones: boolean = false;
  public nombreCliente?: string;
  public lista = "";

  //Variables reset escáner
  public intentosReiniciarEscaner = 0;
  public intentosResetEscanerDoc = 3;
  public esReintentoEscaner = false;
  //Variables reset escáner


  public imgHelp = 'assets/img/svg/ayuda.svg';
  public imgIneFront = 'assets/img/ine/ine-front.png';
  public imgIneBack = 'assets/img/ine/ine-back.png';
  public timeActual: any;
  public timeInicial: any;
  public procesadorInvoked: boolean = false; //bandera para saber si ya se invoco procesador y no invocarlo nuevamente
  public btnEscanear: string = ''; //texto del botón
  public tieneIne!: boolean; // en el código no se utiliza, solo se llama en guardarDatosEscaneados
  public instruccionife: string = 'Escaneando documento.';
  public invokedScanDocumentActived: boolean = false;

  public scan: boolean = true; //esta variable es para saber si el boton escaneara o ira a la siguiente pagina
  public respuestaInstruccion: any;
  public regresoRespuesta: boolean = false;
  public errorEscaner!: boolean;
  public errorGeneral!: boolean;
  public dialogRef: MatDialogRef<DialogGeneralComponent, any> | undefined;
  public dialogHuellas: MatDialogRef<DialogHuellasComponent, any> | undefined;


  public respuestaNacional = `

      Identificación incorrecta:
        Para continuar con el proceso, favor de proporcionar una credencial para votar.
      `;

  public errorVigencia = `
   Indica al cliente que la identificación no está vigente
        que es importante que actualice su identificación
        para realizar cualquier trámite con el banco.`;
  //#endregion

  //#region CAMPOS VERIFICACION N O CLIENTE INE
  public msjNombre: string | null = "";
  public msjPrimerApellido: string | null = "";
  public msjSegundoApellido: string | null = "";
  public msjFechaNacimiento: string | null = "";
  public msjEntidadNacimiento: string | null = "";
  public msjGenero: string | null = "";
  public msjCurp: string | null = "";
  public datosOk = false;
  public nombre: string | undefined = "";
  public primerApellido: string | undefined = "";
  public segundoApellido: string | undefined = "";
  public ano: string | undefined = "";
  public mes: string | undefined = "";
  public dia: string | undefined = "";
  public fechaNacimiento: string | undefined = "";
  public genero: string | undefined = "";
  public entidadNacimiento: string | undefined = "";
  public curp: string | undefined = "";
  public escaneoOk: boolean = false;
  public readOnly = true;

  //#endregion

  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private router: Router,
    private dialogs: UtilDialogs,
    private escanearService: EscanearService,
    private bCurp: BiocheckCurp,
    private zone: NgZone,
    private Utils: BiocheckUtils,
  ) {
    //  this.bcService.crearConexion();

  }

  ngOnInit(): void {
    this.storageService.bcStorage.documentScan = 1;// 1 = ife/ine   2 = FM   3 = Pasaporte
    if (this.storageService.bcStorage.tipoFlujoVerificacion == 5 || this.storageService.bcStorage.tipoFlujoVerificacion == 6)
      this.nombreCliente = "";
    else
      this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    //this.bcService.reconectingSignalR();

    //this.bcService.initializeSignalConnection();
    // this.bcService.connectionScaner$.subscribe(response => {
    //   if (response) {
    //     debugger;
    //     console.log('Connected...' + response);
    //     this.scan = true;
    //     this.storageService.bcStorage.isCIC = false;
    //     this.storageService.bcStorage.signalrStopped = false;
    //     this.inicializarVista();
    //   }
    // })
    this.iniciarVista();
  }

  //#region ESCANER
  iniciarVista() {
    setTimeout(() => {
      this.Utils.totalPasos(4);
      if (this.storageService.bcStorage.tipoFlujoVerificacion == 5 || this.storageService.bcStorage.tipoFlujoVerificacion == 6) {
        this.Utils.cambiarPaso(2, "Escanear identificación");
        this.headerVista = '2. Escanear credencial de elector';
      }
      else {
        this.Utils.cambiarPaso(3, "Escanear identificación");
        this.headerVista = '3. Escanear credencial de elector';
      }
      this.textoBtnScanear(true);
    }, 500);
  }

  textoBtnScanear(valor: boolean) {
    if (valor) {
      this.scan = true;
      this.btnEscanear = "Escanear";
    } else {
      this.scan = false;
      this.btnEscanear = "Continuar";
    }
  }

  dialogA() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan(this.instruccionife, false);
    this.dialogRef.afterClosed().subscribe(response => {
      this.onAbrirModalErrorSinEscaner();
    });
  }

  dialogB() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan('Voltear documento', true, 'Escanear');
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {
          this.scanSideB();
        }
      }
    );
  }

  onCerrandoModalErrorSinEscaner() {
    if (this.respuestaInstruccion.Message === undefined || typeof this.respuestaInstruccion.Message === 'undefined' || /(esc(a|á)ner de documentos.*conectado)|(conexiones.*esc(a|á)ner de documentos)/i.test(this.respuestaInstruccion.Message)) {
      this.estadoInicialImagenes();
      const msg = "Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5";
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogError(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.textoBtnScanear(true);
          try {
            this.sendLog('warning', '', msg);
          } catch (tryError) {
          }
        }
      });
    }
  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  //Cambia el texto del boton a "escanear" o "continuar" ademas de que decide el flujo


  estadoInicialImagenes() {
    this.imgIneFront = 'assets/img/ine/ine-front.png';
    this.imgIneBack = 'assets/img/ine/ine-back.png';
    this.estadoInicialImagenesJquery();
  }

  estadoInicialImagenesJquery() {
    let frente = $("#frente");
    if (frente.length > 0) {
      frente.attr("src", this.imgIneFront);
      frente.css("opacity", ".3");
    }
    let atras = $("#atras");
    if (atras.length > 0) {
      atras.attr("src", this.imgIneBack);
      atras.css("opacity", ".3");
    }
  }

  guardarDatosEscaneados(responseEscaner: any) {
    if (responseEscaner.ClassName == 'Voter Identification') {
      this.escanearService.guardarDatos(responseEscaner, 1);
      this.tieneIne = true;
      this.storageService.bcStorage.esIne = true;
    } else {
      this.storageService.bcStorage.esIne = false;
      responseEscaner.message = "";
    }
    //Revisamos si se escanearon correctamente los dos lados
    return !!(this.storageService.bcStorage.imagenFrente && this.storageService.bcStorage.imagenAtras);
  }

  validarVigencia(existeVigencia: any, fecha: string) {
    const fechaDeHoy = new Date();
    const anio = fechaDeHoy.getFullYear();
    return existeVigencia
      ? anio <= parseInt(fecha) ? true : false
      : false;
  }

  /**
   * FUNCIONES DE RESPUESTA
   */
  onErrorEscaner(responseEscaner: string) {
    this.respuestaInstruccion = responseEscaner;
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogError(responseEscaner, 'OK');
    this.dialogRef.afterClosed().subscribe(() => {
      this.textoBtnScanear(true);
      try {
        this.sendLog('warning', '', responseEscaner);
      } catch (tryError) {
        // ignored
      }
    });
  }

  mensajeGeneral(mensaje: string, accion: string, codigoError: string) {

    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogError(mensaje, accion);
    this.dialogRef.afterClosed().subscribe(response => {
      if (response) {
        if (codigoError != "") {
          this.errorFunction(codigoError);
        }
        try {
          this.sendLog('warning', '', this.errorVigencia);
        } catch (tryError) {
        }
      }
    });

  }

  onRespuestaInstruccion(responseEscaner: any) {

    this.respuestaInstruccion = responseEscaner;
    switch (responseEscaner.Code) {
      case 1:
      case 4:
        this.errorEscaner = false;
        break;
      case 5:
      case 6:
        this.errorEscaner = true;
        this.onCerrandoModalErrorSinEscaner();
        break;
      case 7:
        this.instruccionife = 'Escaneando documento.';
        //        this.responseScan();
        break;

      default:
        this.instruccionife = responseEscaner.Message;
        break;
    }
  }

  /**
   * END FUNCIONES DE RESPUESTA
   */

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    this.router.navigateByUrl('/finalizar');
  }

  onAbrirModalErrorSinEscaner() {
    if (!this.invokedScanDocumentActived) {
      this.bcService.invokeScanDocument([1]);
      this.invokedScanDocumentActived = true;
    }
  }

  /**
   * INICIA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
   */

  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.getFinalDate();
  }

  scanSideB() {
    this.bcService.invokeScanDocumentManual([1]);
    // modalInstrucciones.open();
    const resp = { Code: 7, Message: "Escaneando documento." };
    this.bcService.invokeScanDocument([1]);
    this.dialogA();
    this.onRespuestaInstruccion(resp);
  }

  respuestaProcesador() {
    this.bcService.respuestaProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      if (response) {
        console.log('response', response)
        const id = response.id;
        switch (id) {
          case 'VerificarEstatusEscanerDoc':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Verificar si el escaner está conectado y online
              this.activarModoManualEscaner();
            }
            break;
          case 'VerificarEscanerConectadoOnline':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Poner el flujo que se quiere ejecutar en la respuesta
              this.activarModoManualEscaner();
            }
            break;
          case 'ActivarModoManualEscaner':
            // this.startScanProcess();
            // Se ejecuta función que indica que los dispositivos se chequearon con éxito ??
            break;
          default:
            break;
        }
      }
    });
  }

  failProcesador() {
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      if (response) {
        console.log(response.code);
        const code = parseInt(response.code);
        let msg = '';
        if (code === 330) {
          //modalerror2
          msg = `Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              // this.errorFunction();
              // CHECAR error EN CODIGO
            } else {
              this.cancelarinfo();
            }
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 331) {
          //modalerror
          msg = `Servicio de escaneo de documentos no pudo ser iniciado.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 332) {
          //modalerror
          msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 333) {
          //Si hay intentos, verifica el estatus del escáner
          if (this.intentosReiniciarEscaner < this.intentosResetEscanerDoc) {
            this.intentosReiniciarEscaner++;
            this.esReintentoEscaner = true;
            //modalerror2
            msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5`;
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.verificarEscanerDocumentos();
              } else {
                this.cancelarinfo();
              }
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          } else { //Si no hay intentos, notifica y termina flujo
            //modalerror
            msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.errorServiciosEscaner();
              }
              ;
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          }
        } else if (code === 350) {
          //modalerror
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(response.message, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        }
      }
    });
  }

  verificarEscanerDocumentos() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEstatusEscanerDoc", {});
    })
  }

  verificarEscanerConectadoOnline() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEscanerConectadoOnline", {});
    })
  }

  activarModoManualEscaner() {
    this.controladorFunciones("ActivarModoManualEscaner", {});
  }

  controladorFunciones(id: string, parametrosEntrada: any) {
    const funcion = {
      Id: id,
      ParametrosEntrada: parametrosEntrada
    };
    this.bcService.procesador([funcion]); // si es necesario no invocarlo lo metemos en if de abajo
    if (!this.procesadorInvoked) {
      this.procesadorInvoked = true;
    }
  }

  errorServiciosEscaner() {
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.codigoflujo = "ELB01";
    this.getFinalDate();
  }

  /**
   * Función para error en los servicios del escaner de documentos
   * TERMINA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
   */

  public failScan() {
    this.bcService.getFailScan();
    this.bcService.responseScan$.subscribe({
      next: response => {
        if (response) {
          this.onErrorEscaner(response);
        }
      }
    });
  }

  async instructionScan() {
    await this.bcService.getInstructionScan();
    await this.bcService.instruccionesScaner$.subscribe({
      next: response => {
        if (response) {
          this.onRespuestaInstruccion(response);
        }
      }
    });
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.getfinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  // Acción del botón
  continuar() {

    if (this.scan) {
      this.dialogRef?.close();
      this.invokedScanDocumentActived = false;
      console.log(this.instruccionife);
      this.onAbrirModalErrorSinEscaner();
      this.dialogA();
      this.instructionScan();
      this.responseScan();
    } else {
      console.log('tipoFlujo::: '+ this.storageService.bcStorage.tipoFlujoVerificacion)
      if (this.storageService.bcStorage.tipoFlujoVerificacion == 4) {
        var path = "ocr-identificacion";
        this.zone.run(() => {
          this.router.navigateByUrl(`/${path}`);
        });
      }else if (this.storageService.bcStorage.tipoFlujoVerificacion == 5) {//no clientes
      this.redirectNoCliente();
      }
    }
  }




  public respondeObservable: any
  responseScan() {
    var cont = 0;
    this.bcService.getResponseScan();
    this.respondeObservable = this.bcService.responseScan$.subscribe(response => {
      //this.first_subscriber_subject = response;
      if (response) {
        // cont += 1;
        // if (cont == 1) {
        if (response.Message !== 'Side A') {

        }
        this.onRespuestaEscaner(response);
        // }
      }
    });

  }

  onRespuestaEscaner(response: any) {
    if (this.respondeObservable != undefined) {
      //this.respondeObservable.unsubscribe();
    }

    if (this.errorEscaner && this.respuestaInstruccion.Code === 3 && response.Success && (/cancel/i.test(response.Message) || /no detectada/i.test(response.Message))) {
      return;
    }
    this.sendLog('warning', '', response.Message);
    if (response.Message === 'Side A') {
      this.dialogB();
      return;
    }

    if (response) {
      if (response.Success) {
        if (response.Alertas != null) {
          const data = response.Alertas.filter((alerta: any) => alerta.Valido == false); // filtrar las que Valido = false
          this.storageService.bcStorage.mensajeinternoflujo = (data != undefined && data != null && data.length >= 0) && data;
        }
        //checamos si es valido el documento escaneado
        if (response.valid) {
          //Revisamos si obtuvo los datos necesarios
          if (this.guardarDatosEscaneados(response)) {
            // se valida si existencia vigencia es true
            if (this.storageService.bcStorage.existenciaVigencia) {
              /* !!! MXSLBIOM-2448 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2019 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. Se deberá modificar la bandera no eliminarla, es decir, cuando termine la prórroga del INE se puede volver hacer las validaciones de las vigencias actuales.
              * !!! MXBIOC-193 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2020 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. ====================================== */
              let anioVigencia = parseInt((this.storageService.bcStorage.vigencia) ? this.storageService.bcStorage.vigencia : 0);
              const listEstadosVigencia = this.storageService.bcStorage.EstadosVigenciaIne !== undefined ? this.storageService.bcStorage.EstadosVigenciaIne.split(',') : "";
              const ExisteEstado = listEstadosVigencia !== "" ? listEstadosVigencia.find(value => value == this.storageService.bcStorage.ClaveEntidad) : false;
              const fechaDeHoy = new Date();
              const anio = fechaDeHoy.getFullYear() - 1; //año valido vigente
              const reglaOmitirVigencia = this.storageService.bcStorage.OmitirVigenciaIne === true && anioVigencia === anio && ExisteEstado !== undefined;
              if (reglaOmitirVigencia || this.validarVigencia(this.storageService.bcStorage.existenciaVigencia, this.storageService.bcStorage.vigencia)) {
                if (this.storageService.bcStorage.tipoFlujoVerificacion == 5 || this.storageService.bcStorage.tipoFlujoVerificacion == 6) {//no clientes
                  this.textoBtnScanear(false);
                  this.nombre = this.storageService.bcStorage.nombre;
                  this.primerApellido = this.storageService.bcStorage.apellidoP;
                  this.segundoApellido = this.storageService.bcStorage.apellidoM;
                  this.ano = this.storageService.bcStorage.ano;
                  this.mes = this.storageService.bcStorage.mes;
                  this.dia = this.storageService.bcStorage.dia;
                  this.fechaNacimiento = this.dia + "/" + this.mes + "/" + this.ano;
                  this.genero = this.storageService.bcStorage.sexo;
                  this.entidadNacimiento = this.storageService.bcStorage.entidadNacimiento;
                  this.curp = this.storageService.bcStorage.curp;
                  this.escaneoOk = true;
                  this.validacionInputs(true);
                  this.dialogRef?.close();
                }
                else {
                  this.errorEscaner = false;
                  this.errorGeneral = false;
                  this.storageService.bcStorage.proceso = true;
                  this.textoBtnScanear(false);
                  this.dialogRef?.close();
                }
              } else {
                this.errorGeneral = true;
                //   this.storageService.bcStorage.proceso= true;
                this.estadoInicialImagenes();
                this.textoBtnScanear(true);
                this.mensajeGeneral(this.errorVigencia, "Finalizar", "");
              }
            } else { // existencia vigencia es false
              this.errorGeneral = true;
              this.mensajeGeneral(this.errorVigencia, 'Finalizar', "EBC00");
            }
            //valida que se haya escaneado una PASAPORTE
          } else if (!this.storageService.bcStorage.esIne) {
            this.errorGeneral = true;
            const documentoNoValido = this.escanearService.controlErrores(response, 1);
            const isRepetir = documentoNoValido.msjBoton == 'Repetir';
            const addLabel = isRepetir ? '' : ':ErrorCode:EOB09';
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(documentoNoValido.mensajeError, `${documentoNoValido.msjBoton} ${addLabel}`);
            this.dialogRef.afterClosed().subscribe(
              response => {
                if (response) {
                  if (isRepetir) {
                    this.textoBtnScanear(true);
                    this.estadoInicialImagenes();
                  } else {
                    this.errorFunction('EOB09');
                  }
                }
                try {
                  this.sendLog('warning', '', documentoNoValido.mensajeError);
                } catch (tryError) {
                }
              }
            );
          } else {  // no obtuvo los datos necesarios
            this.errorGeneral = false;
            const mensaje = "Debe escanear ambos lados de la identificación";
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(mensaje, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.textoBtnScanear(true);
                this.estadoInicialImagenes();
                try {
                  this.sendLog('warning', '', mensaje);
                } catch (tryError) {
                }
              }
            });
          }
        } else { //no es valido el documento escaneado
          try {
            this.guardarDatosEscaneados(response);
          } catch (error) {
          }
          this.errorGeneral = true;
          const documentoNoValido: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 1);
          this.textoBtnScanear(true);
          //TypeModal es 2
          if (response.TypeModal === 2) {
            let documentoCaducado = false;
            if (!/no permite la captura/ig.test(response.Message)) {
              let vigencia = '';
              //Esto es para la clave de lector de INE
              response.Values.forEach((v: any, i: number) => {
                //vigencia
                if (v.Name == "VIZ Expiration Date") {
                  vigencia = v.Value;
                  const fechaDeHoy = new Date();
                  //fecha de hoy
                  const dd = fechaDeHoy.getDate();
                  const mm = fechaDeHoy.getMonth() + 1;
                  const yyyy = fechaDeHoy.getFullYear();
                  const date_regex = /^(0[1-9]|1\d|2\d|3[01])\-(0[1-9]|1[0-2])\-(19\d{2}|2\d{3})$/;//Esta epresion regular revisa que la vigencia tenga el formato correcto
                  //aqui evaluamos que la vigencia sea valida
                  if (date_regex.test(vigencia)) {
                    const fecha = v.Value.split('-');
                    const anioEscan = parseInt(fecha[2]);
                    const mesEscan = parseInt(fecha[1]) - 1;
                    const diaEscan = parseInt(fecha[0]);
                    const vigenciafecha = new Date(anioEscan, mesEscan, diaEscan);
                    documentoCaducado = vigenciafecha < fechaDeHoy && true;
                  }
                }
              });
            }
            if (documentoCaducado) {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(this.errorVigencia, 'Finalizar');
              this.dialogRef.afterClosed().subscribe(response => {
                if (response) {
                  this.errorFunction('EOB09', documentoNoValido.mensajeErrorLegible)
                  try {
                    this.sendLog('warning', '', this.errorVigencia);
                  } catch (tryError) {
                  }
                }
              });
            } else {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(documentoNoValido.mensajeError, documentoNoValido.msjBoton);
              this.dialogRef.afterClosed().subscribe(response => {
                if (response) {
                  if (documentoNoValido.msjBoton === 'Repetir') {
                    this.textoBtnScanear(true);
                    this.estadoInicialImagenes();
                  } else {
                    this.errorFunction("EOB09", documentoNoValido.mensajeErrorLegible)
                  }
                  try {
                    this.sendLog('warning', '', documentoNoValido.mensajeError);
                  } catch (tryError) {
                  }
                }
              });
            }
            //TypeModal es 3
          } else if (response.TypeModal == 3) {
            if (response.Message === 'DocumentoErroneo') {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(this.respuestaNacional, 'Repetir');
              this.dialogRef.afterClosed().subscribe(() => {
                try {
                  this.sendLog('warning', '', this.respuestaNacional);
                } catch (tryError) {
                }
              });
            } else {
              this.dialogRef?.close();
              this.dialogRef = this.dialogs.showDialogError(response.Message, 'Repetir');
              this.dialogRef.afterClosed().subscribe(() => {
                try {
                  this.sendLog('warning', '', response.Message);
                } catch (tryError) {
                }
              });
            }
          } else { // TypeModal no es 2 ni 3
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(this.respuestaNacional, 'Repetir');
            this.dialogRef.afterClosed().subscribe(() => {
              try {
                this.sendLog('warning', '', this.respuestaNacional);
              } catch (tryError) {
              }
            });
          }
        }
      } else { // Response no success
        this.textoBtnScanear(true);
        if (response.ScanBothSides) {
          this.mensajeGeneral(this.respuestaNacional, 'Repetir', "");

        } else if (response.Message === 'Identificación no detectada.') {
          this.invokedScanDocumentActived = false;
          const msg = 'Por favor vuelve a escanear la identificación'
          this.mensajeGeneral(msg, 'Repetir', "");
        } else {
          this.invokedScanDocumentActived = false;
          var msg = "";
          if (response.Message == "DocumentoErroneo")
            msg = "El documento escaneado no es valido.";
          else
            msg = response.Message;
          this.mensajeGeneral(msg, 'Repetir', "");
        }
      }
    } else { // NO RESPONSE
      this.invokedScanDocumentActived = false;
      this.textoBtnScanear(true);
      const documentoNoSuccess: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 3);
      this.mensajeGeneral(documentoNoSuccess.mensajeError, documentoNoSuccess.msjBoton, "");
      this.errorGeneral = true;
    }
  }


  cancelar() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCancelar();
    this.dialogRef.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }


  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "PaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  //#endregion


  //#region VERIFICACION NO CLIENTE
  public funcionReadOnly() {
    // if (bcstorage.resultadoIne.fallonombre === true) {
    //   this.msjNombre = "No coincide en INE";
    //   $("#Nombre").prop('readonly', false);
    // }
    // if (bcstorage.resultadoIne.falloappat === true) {
    //   this.msjPrimerApellido = "No coincide en INE";
    //   $("#Paterno").prop('readonly', false);
    // }
    // if (bcstorage.resultadoIne.falloapmat === true) {
    //   this.msjSegundoApellido = "No coincide en INE";
    //   $("#Materno").prop('readonly', false);
    // }
    // if (bcstorage.resultadoIne.falloCURP === true) {
    //   this.msjCurp = "No coincide en INE";
    //   $("#Curp").prop('readonly', false);
    // } else {
    //   $("#Curp").prop('readonly', true);
    // }
  }

  validacionInputs(primeraVez: boolean = true) {
    this.datosOk = true;
    this.msjNombre = null;
    this.msjPrimerApellido = null;
    this.msjSegundoApellido = null;
    this.msjFechaNacimiento = null;
    this.msjGenero = null;
    this.msjEntidadNacimiento = null;
    this.msjCurp = null;
    if (primeraVez === true) {
      $("#Curp").prop('readonly', true);
    }
    if (this.nombre == null || this.nombre == "") {
      this.datosOk = false;
      this.msjNombre = "Campo vacío";
    } else if (this.primerApellido == null || this.primerApellido == "") {
      this.datosOk = false;
      this.msjPrimerApellido = "Campo vacío";
    } else if (this.segundoApellido == null || this.segundoApellido == "") {
      this.datosOk = false;
      this.msjSegundoApellido = "Campo vacío";
    } else if (this.fechaNacimiento == null || this.fechaNacimiento == "") {
      this.datosOk = false;
      this.msjFechaNacimiento = "Campo vacío";
    } else if (this.genero == null || this.genero == "") {
      this.datosOk = false;
      this.msjGenero = "Campo vacío";
    } else if (this.entidadNacimiento == null || this.entidadNacimiento == "") {
      this.datosOk = false;
      this.msjEntidadNacimiento = "Campo vacío";
    } else if (this.curp == null || this.curp == "") {
      this.datosOk = false;
      this.msjCurp = "Campo vacío";
    } else {
      var CURPcalculado = this.bCurp.generar2(this.nombre, this.primerApellido, this.segundoApellido, this.ano == undefined ? "" : this.ano, this.mes == undefined ? "" : this.mes, this.dia == undefined ? "" : this.dia, this.genero, this.entidadNacimiento).toUpperCase();

      // Se obtiene la fecha de la CURP para validar con la fecha de nacimiento
      var fechaCurp = this.curp.substring(4, 10).toUpperCase();
      var fechaNacimientoCurpFormat = this.ano == null ? "" : this.ano.substring(2, 4) + this.mes + this.dia;

      this.curp = this.curp.toUpperCase();

      if (this.curp.length !== 18) {
        this.datosOk = false;
        this.msjCurp = "Estructura de CURP incorrecta";
      } else if (!/^[A-Z][A,E,I,O,U,X][A-Z]{2}[0-9]{2}[0-1][0-9][0-3][0-9][M,H][A-Z]{2}[B,C,D,F,G,H,J,K,L,M,N,Ñ,P,Q,R,S,T,V,W,X,Y,Z]{3}[0-9,A-Z]{2}$/ig.test(this.curp)) {
        this.datosOk = false;
        this.msjCurp = "Estructura de CURP incorrecta";
      } else if (fechaCurp != fechaNacimientoCurpFormat) {
        this.datosOk = false;
        this.msjCurp = "Fecha de CURP no coincide con fecha de nacimiento";
      }
    }
    if (this.msjCurp != null && this.msjCurp != "") {
      $("#Curp").prop('readonly', false);
    }
    if (!this.datosOk) {
      $("#escanearBtn").hide();
    } else {
      $("#escanearBtn").show();
    }
    //this.$applyAsync();
  }

  continuarNoClientes() {
    debugger;
    this.storageService.bcStorage.curp = this.curp;
    //this.storageService.bcStorage.curpDO = this.storageService.bcStorage.curp;
    // this.storageService.bcStorage.curpDO = this.storageService.bcStorage.curp;
    // if (this.storageService.bcStorage.repetirCapturaDatosIne === true) {
    //     this.storageService.bcStorage.nombre = this.nombre;
    //     this.storageService.bcStorage.apellidoP = this.primerApellido;
    //     this.storageService.bcStorage.apellidoM = this.segundoApellido;
    this.storageService.bcStorage.nombreCliente = this.storageService.bcStorage.nombre + " " + this.storageService.bcStorage.apellidoP + " " + this.storageService.bcStorage.apellidoM;
    // }
    //this.storageService.bcStorage.yaEscaneoIne = true;

    // Compara datos OCR vs datos recibidos del cliente
    if (this.storageService.bcStorage.datosCanal && this.storageService.bcStorage.datosCanal !== undefined && this.storageService.bcStorage.datosCanal !== null && this.storageService.bcStorage.datosCanal !== "") {
      if (typeof this.storageService.bcStorage.datosCanal === 'string') {
        this.storageService.bcStorage.datosCanal = JSON.parse(this.storageService.bcStorage.datosCanal);
      }
      var datosDiferentes = [];
      if (this.storageService.bcStorage.datosCanal.Nombres && this.storageService.bcStorage.datosCanal.Nombres != null && this.storageService.bcStorage.datosCanal.Nombres != "") {
        if (this.nombre != this.storageService.bcStorage.datosCanal.Nombres) {
          datosDiferentes.push({ Dato: "Nombres", Ocr: this.nombre, Canal: this.storageService.bcStorage.datosCanal.Nombres });
        }
        if (this.primerApellido != this.storageService.bcStorage.datosCanal.PrimerApellido) {
          datosDiferentes.push({ Dato: "PrimerApellido", Ocr: this.primerApellido, Canal: this.storageService.bcStorage.datosCanal.PrimerApellido });
        }
        if (this.segundoApellido != this.storageService.bcStorage.datosCanal.SegundoApellido) {
          datosDiferentes.push({ Dato: "SegundoApellido", Ocr: this.segundoApellido, Canal: this.storageService.bcStorage.datosCanal.SegundoApellido });
        }
        var fechaNacimientoFormato = this.ano + "-" + this.mes + "-" + this.dia;
        if (fechaNacimientoFormato != this.storageService.bcStorage.datosCanal.FechaNacimiento) {
          datosDiferentes.push({ Dato: "FechaNacimiento", Ocr: fechaNacimientoFormato, Canal: this.storageService.bcStorage.datosCanal.FechaNacimiento });
        }
        if (datosDiferentes.length > 0) {
          var errores = "";
          datosDiferentes.forEach(function (item, index, arr) {
            errores += "<li><a style='color: rgb(236, 0, 0);'>" + item.Dato + "</a><br/>Credencial: " + item.Ocr + "<br/>Origen: " + item.Canal + "</li>";
          });
          var mensajefinal = "Favor de validar la información que no sea un error de captura, en caso de que no sea así sugiere que acuda al INE para actualizar su información";
          this.mensajeGeneral("<div style = 'font-weight:700;' > Comparación de datos OCR vs Canal</div > <br /><div style='text-align: left;'>Indica al cliente que debes finalizar el proceso, porque los siguientes datos obtenidos de la credencial no coinciden con los de origen: <br><br>"
            + "<ul style='list-style: inside;'>" + errores + "</ul>" + mensajefinal + "</div>", "Finalizar", "EVD03");
        } else {
          // biocheck.onStopSignalR();
          this.redirectNoCliente();
        }
      }
    } else {
      //biocheck.onStopSignalR();
      this.redirectNoCliente();
    }
  }

  redirectNoCliente() {
    this.Utils.cambiarPaso(2, 'Capturar huellas');
    this.dialogCapturaHuella(1, "");
  }

  dialogCapturaHuella(dedo: any, img: any) {
    this.dialogHuellas?.close();
    this.dialogHuellas = this.dialogs.showDialogCaupturaHuellas(dedo, img);
    this.dialogHuellas.afterClosed().subscribe(
      response => {
        if (response) {

        }
      }
    );
  }
  //#endregion
}
