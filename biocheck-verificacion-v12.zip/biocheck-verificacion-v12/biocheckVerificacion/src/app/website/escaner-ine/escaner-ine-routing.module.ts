import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EscanerIneComponent } from './component/escaner-ine.component';

const routes: Routes = [
  { path: '', component: EscanerIneComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EscanerIneRoutingModule { }
