import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'src/app/material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';


import { EscanerIneRoutingModule } from './escaner-ine-routing.module';
import { EscanerIneComponent } from './component/escaner-ine.component';
import { MatTooltipModule } from "@angular/material/tooltip";
import { TooltipModule } from "../tooltip/tooltip.module";
import { MatChipsModule } from "@angular/material/chips";
import { OverlayModule } from "@angular/cdk/overlay";
import { MatDividerModule } from "@angular/material/divider";
//import { CustomTooltipDirective } from "../../directives/custom-tooltip.directive";
import { VerificacionVentanillaModule } from '../verificacion-ventanilla/verificacion-ventanilla.module';


@NgModule({
  declarations: [
    EscanerIneComponent,
    //  CustomTooltipDirective
  ],
  imports: [
    CommonModule,
    EscanerIneRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatChipsModule,
    OverlayModule,
    MatDividerModule,
    TooltipModule,
    VerificacionVentanillaModule
  ],
})
export class EscanerIneModule { }
