import { Component, OnInit } from '@angular/core';
import { BiocheckService } from "../../core/services/biocheck.service";
import { BcstorageService } from "../../core/services/bcstorage.service";
import { MatDialogRef } from "@angular/material/dialog";
import { BiocheckErrorService } from "../../core/services/biocheck.error.service";


@Component({
  selector: 'app-finalizar',
  templateUrl: './finalizar.component.html',
  styleUrls: ['./finalizar.component.scss']
})
export class FinalizarComponent implements OnInit {

  public verCLiente: boolean = true;
  public verFechaEnrol: boolean = true;
  public verHora: boolean = true;
  public verNumeroFolio: boolean = true;
  public band: any;
  public cancel: boolean = false;
  public tipoProceso: string = "Recopilación de datos biométricos";
  public nombreCliente: string = '';
  public fechaEnrol: string = '';
  public horaFecha: string = '';
  public codigoFlujo: string = '';
  public mensajeFlujo: string = '';
  public numerofolio: string = "";
  public estatusRespuesta: string = "Verificación no exitosa";
  public nombreClienteBaner: string = "";
  public dialogRef: MatDialogRef<any, any> | undefined;
  public dialogGen: MatDialogRef<any, any> | undefined;

  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private errorMensaje: BiocheckErrorService,
  ) {
    this.band = this.storageService.bcStorage.proceso;
    this.estatusRespuesta = this.storageService.bcStorage.proceso ? "Verificación exitosa" : "Verificación no exitosa";
    if (this.storageService.bcStorage.codigoflujo === 'CA000') {
      this.cancel = true;
    }
    this.cerrarModales();
  }

  cerrarModales() {
    this.dialogRef?.close();
    this.dialogGen?.close();
  }

  ngOnInit(): void {
    console.log(':::: ingresando a Finalizar ::::');
    this.CargaDatos();
  }

  CargaDatos() {
    if (this.storageService.bcStorage.codigoflujo == "CA000") {
      console.log('cancel en true;')
      this.cancel = true;
    }

    //revisa si algun dato que se muestra en pantalla no tiene algun valor
    if (this.storageService.bcStorage.codigoflujo === 'EEB02' ||
      this.storageService.bcStorage.codigoflujo === 'EVB00' ||
      this.storageService.bcStorage.codigoflujo === 'EVB02') {
      console.log('ingreso a false del cliente error ')
      this.verCLiente = false;
    } else {
      this.nombreClienteBaner = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    }

    if (this.storageService.bcStorage.apicNombre === null || this.storageService.bcStorage.apicNombre === undefined || this.storageService.bcStorage.apicNombre === '') {
      this.storageService.bcStorage.apicNombre = '';
      this.verCLiente = false;
    }
    if (this.storageService.bcStorage.apicApellidoM === null || this.storageService.bcStorage.apicApellidoM === undefined || this.storageService.bcStorage.apicApellidoM === '') {
      this.storageService.bcStorage.apicApellidoM = '';
    }
    if (this.storageService.bcStorage.apicApellidoP === null || this.storageService.bcStorage.apicApellidoP === undefined || this.storageService.bcStorage.apicApellidoP === '') {
      this.storageService.bcStorage.apicApellidoP = '';
    }

    if (this.storageService.bcStorage.nombreCliente != '') {
      this.nombreCliente = undefined ? "" : "" + this.storageService.bcStorage.nombreCliente;
    } else {
      this.nombreCliente = this.storageService.bcStorage.apicNombre + ' ' + this.storageService.bcStorage.apicApellidoP + ' ' + this.storageService.bcStorage.apicApellidoM;
    }

    if (this.storageService.bcStorage.fechapros === null || this.storageService.bcStorage.fechapros === undefined || this.storageService.bcStorage.fechapros === '') {
      this.verHora = false;
      this.fechaEnrol = '';
    } else {
      this.fechaEnrol = this.storageService.bcStorage.fechapros;
    }

    if (this.storageService.bcStorage.horapros === null || this.storageService.bcStorage.horapros === undefined || this.storageService.bcStorage.horapros === '') {
      this.verFechaEnrol = false;
      this.horaFecha = '';
    } else {
      this.horaFecha = this.storageService.bcStorage.horapros;
    }

    if (this.storageService.bcStorage.foliopros === null || this.storageService.bcStorage.foliopros === undefined || this.storageService.bcStorage.foliopros === '') {
      this.verNumeroFolio = false;
      this.numerofolio = '';
    } else {
      this.numerofolio = this.storageService.bcStorage.foliopros;
    }
    this.bcService.onStopSignalR();

  }

  respuesta() {
    let innerMessage = '';
    let mensajeCatalogo = '';

    if (this.storageService.bcStorage.mensajeinternoflujo) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }
    if (this.storageService.bcStorage.codigoflujo != null) {
      mensajeCatalogo = this.errorMensaje.codigoError(this.storageService.bcStorage.codigoflujo);
    }
    if (this.storageService.bcStorage.mensajeflujo != '' && this.storageService.bcStorage.mensajeflujo != undefined) {
      mensajeCatalogo = this.storageService.bcStorage.mensajeflujo;
    }

    let response: any = "";
    if (this.cancel) {
      console.log('respuesta en cancel::::')
      response = {
        message: this.storageService.bcStorage.mensajeflujo || '',
        innerMessage: '',
        code: this.storageService.bcStorage.codigoflujo || '',
        response: false,
        indice: this.storageService.bcStorage.indice
      }
    } else if (mensajeCatalogo != '') {
      response = {
        message: mensajeCatalogo || '',
        innerMessage: innerMessage,
        code: this.storageService.bcStorage.codigoflujo || '',
        response: false
      }
    } else if (mensajeCatalogo != '') {
      response = {
        message: mensajeCatalogo || '',
        innerMessage: innerMessage,
        code: this.storageService.bcStorage.codigoflujo || '',
        response: false
      }
    } else {
      console.log('respuesta en error ::::')
      response = {
        //      message: this.storageService.bcStorage.mensajeflujo || '',
        innerMessage: innerMessage,
        code: this.storageService.bcStorage.codigoflujo || '',
        response: this.storageService.bcStorage.proceso,
        indice: this.storageService.bcStorage.indice
      }

    }

    let responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  sendMessage(msg: string) {
    this.postFinalizar(msg);
  }

  postFinalizar(e: any) {
    window.parent.postMessage(e, "*")
  };

  fin() {
    this.respuesta();
  }

  buscarMessage(codigo: any) {
    this.storageService.bcStorage.mensajeflujo = this.errorMensaje.codigoError(codigo);
    console.log('MensajeError: ' + this.storageService.bcStorage.mensajeflujo);
  }

}
