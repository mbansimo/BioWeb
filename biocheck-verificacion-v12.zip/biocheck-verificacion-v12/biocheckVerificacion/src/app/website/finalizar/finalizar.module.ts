import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";

import {FinalizarRoutingModule} from "./finalizar-routing.module";
import {FinalizarComponent} from "./finalizar.component";


@NgModule({
  declarations: [
  FinalizarComponent
  ],
  imports: [
    CommonModule,
    FinalizarRoutingModule
  ]
})
export class FinalizarModule{}
