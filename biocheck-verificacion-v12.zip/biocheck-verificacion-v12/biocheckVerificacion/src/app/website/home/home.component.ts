import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from "@angular/router";
import {UtilDialogs} from 'src/app/common/util-dialogs';
import {BcstorageService} from 'src/app/core/services/bcstorage.service';
import {BiocheckService} from 'src/app/core/services/biocheck.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public typeScan!: string;
  public coreVistaVentanilla: boolean = false;
  public coreVistaCancelar: boolean = false;


  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private readonly router: Router,
    private readonly ar: ActivatedRoute,
  ) {
  }

  ngOnInit(): void {
    this.getTypeScan();
    this.tipoDeFlujoVerificacion();
    window.addEventListener('message', event => this.obtenerToken(event));
  }

  getTypeScan() {
    this.ar.params.subscribe((response: Params) => {
      this.typeScan = response.type;
    })
  }

  obtenerToken(e: any) {
    const urlRef = window.location.href;
    const paramsString = urlRef.split("?")[1];
    if(paramsString != null){
      this.getParams(urlRef);
    }
    
    if (e.data) {
      var datosCanal = null;
      if (typeof e.data === 'string' && this.IsJsonString(e.data)) {
        datosCanal = JSON.parse(e.data);
      } else if (typeof e.data === 'object') {
        datosCanal = e.data;
      }

      if (datosCanal != null) {
        if (typeof datosCanal.token != "undefined" && datosCanal.token != "")
          this.storageService.bcStorage.token = datosCanal.token;
        if (typeof datosCanal.name != "undefined" && datosCanal.name != "")
          this.storageService.bcStorage.ejecutivoname = datosCanal.name;
        if (typeof datosCanal.data != "undefined" && datosCanal.data != "")
          this.storageService.bcStorage.datosCanal = datosCanal.data;
        if (typeof datosCanal.tipoToken != "undefined" && datosCanal.tipoToken != "")
          this.storageService.bcStorage.tipoToken = datosCanal.tipoToken;
      } else {
        this.storageService.bcStorage.token = e.data;
      }
    } else {

      var isKiosko = this.getParameterByName('iskiosko');
      if (isKiosko == "true") {
        var datosCanal = null;
        if (typeof e.data === 'string' && this.IsJsonString(e.data)) {
          datosCanal = JSON.parse(e.data);
        } else if (typeof e.data === 'object') {
          datosCanal = e.data;
        }
        if (datosCanal != null) {
          if (typeof datosCanal.token != "undefined" && datosCanal.token != "")
            this.storageService.bcStorage.token = datosCanal.token;
          if (typeof datosCanal.name != "undefined" && datosCanal.name != "")
            this.storageService.bcStorage.ejecutivoname = datosCanal.name;
          if (typeof datosCanal.data != "undefined" && datosCanal.data != "")
            this.storageService.bcStorage.datosCanal = datosCanal.data;
          if (typeof datosCanal.tipoToken != "undefined" && datosCanal.tipoToken != "")
            this.storageService.bcStorage.tipoToken = datosCanal.tipoToken;
        } else {
          this.storageService.bcStorage.token = e.data;
        }
      } else {
        this.storageService.bcStorage.token = e.data;
      }
    }
  
//    console.log("TipoToken[" + this.storageService.bcStorage.tipoToken + "]" + "token[" + this.storageService.bcStorage.token + "]");
  }

  getParams(urlRef: any){
    const paramsString = urlRef.split("?")[1];
    var tokenOri = paramsString.split("&")[0];
    const urlParams = new URLSearchParams(paramsString);
    if(urlParams != null){
      this.storageService.bcStorage.datosCanal = urlParams.get("data");

      var token = tokenOri.replace("token=", ""); //token1 != null? token1.replace(" ", "+"): "";
      var tipoToken =  urlParams.get("tipoToken");
      this.storageService.bcStorage.token = token == null? "": token;
      this.storageService.bcStorage.tipoToken = tipoToken == null? "": tipoToken;
    } 
  }

  IsJsonString(str: any) {
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  getParameterByName(name: string) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    console.log("getParametrerByName(" + results + ")");
    if (results == null)
      return "";
    else
      return decodeURIComponent(results[1].replace(/\+/g, " "));
  }

  tipoDeFlujoVerificacion() {
    let path = '';
    var component = window.location.href



    if (component.includes("/#!/full")) {                                                //Verificacion full
      this.storageService.bcStorage.tipoVerificacion = 'full';
      this.coreVistaVentanilla = true;
    } else if (component.includes("/#!/VentanillaINE")) {                               //Verificacion no enr. ventanilla (Pyme)
      this.storageService.bcStorage.tipoVerificacion = 'verificacion-ventanilla';
      this.coreVistaCancelar = true;
    } else if (component.includes("/#!/Ejecutivo")) {                                   //Verificacion no enr. escritorio
      this.storageService.bcStorage.tipoVerificacion = 'verificacion-no-Enrolado';
      this.coreVistaCancelar = true;
    } else if (component.includes("/#!/NoCliente?documento=ine")) {                     //VErificacion no cliente (INE)
      this.storageService.bcStorage.tipoVerificacion = 'NoClienteINE';
      this.coreVistaCancelar = true;
    } else if (component.includes("/#!/NoCliente?documento=pasaporte")) {               //Verificacion no cliente (Pasaporte)
      this.storageService.bcStorage.tipoVerificacion = 'NoClientePasaporte';
      this.coreVistaVentanilla = true;
      this.storageService.bcStorage.documento = this.getParameterByName('documento');
    } else if (component.includes("/#!/NoEnrolado/facialIneInicio")) {                //Verificacion Ine FAcial Escaner
      this.storageService.bcStorage.tipoVerificacion = 'verifica_ine_facial';
      this.coreVistaVentanilla = true;
      this.storageService.bcStorage.nombreProceso = 'verifica_ine_facial';
    } else if (component.includes("/#!/NoEnrolado/inicioFacialIneSimple")) {         //Verificacion Ine Facial MAnual
      this.storageService.bcStorage.tipoVerificacion = 'verificacion_Ine_simple';
      this.coreVistaVentanilla = true;
      this.storageService.bcStorage.nombreProceso = 'verificacion_Ine_simple';
    } else if (component.includes("/#!/NoEnrolado/inicioFacialIneMotor")) {         // Verificacion Ine Facial Motor
      this.storageService.bcStorage.tipoVerificacion = 'verifica_motor';
      this.coreVistaVentanilla = true;
      this.storageService.bcStorage.nombreProceso = 'verifica_motor';
    } else {                                                                        //  Verificacion Simple
      this.storageService.bcStorage.tipoVerificacion = 'simple';
      this.coreVistaVentanilla = true;
    }
    console.log('tipo de Verificacion que se realiza es: ' + this.storageService.bcStorage.tipoVerificacion);
  }


}
