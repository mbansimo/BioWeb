import {AfterViewInit, ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {MatDialogRef} from '@angular/material/dialog';
import {MessagesDialogProcesando} from 'src/app/common/msgs-dialog';
import {UtilDialogs} from 'src/app/common/util-dialogs';
import {BcstorageService} from 'src/app/core/services/bcstorage.service';
import {BiocheckService} from 'src/app/core/services/biocheck.service';
import {DialogGeneralComponent} from 'src/app/shared/dialogs/dialog-general/dialog-general.component';
import {BiocheckCurp} from 'src/app/core/services/biocheck.bCurp.service';
import {CatalogosService} from 'src/app/core/services/catalogos.service';
import {BiocheckCadenas} from 'src/app/core/services/biocheck-cadenas.service';
import {BiocheckErrorService} from 'src/app/core/services/biocheck.error.service';
import * as $ from "jquery";
import {BiocheckUtils} from "../../../core/services/biocheck-utils.service";

@Component({
  selector: 'app-home',
  templateUrl: './ocr-identificacion.component.html',
})
export class OcrIdentificacionComponent implements OnInit {
  //#region VARIABLES OCR INE
  public nombreCliente?: string;
  public dialogRef: MatDialogRef<DialogGeneralComponent, any> | undefined;
  public verOcrIne: boolean = false;
  public msjnombre: string = "";
  public msjapellidop: string = "";
  public msjapellidom: string = "";
  public msjdia: string = "";
  public msjmes: string = "";
  public msjano: string = "";
  public genero: any[] = [
    {'sexo': 'Hombre', 'valor': 'H'},
    {'sexo': 'Mujer', 'valor': 'M'},
  ];
  public msjsexo: string = "";
  public est: any;
  public msjentidad: string = "";
  public msjcurp: string = "";
  public msjsugerenciacurp: string | null = "";
  public msjvigencia: string = "";
  public msjocr: string = "";
  public msjclaveElector: string | null = "";
  public msjcic: string | null = "";
  public msjemision: string | null = "";

  public nombre: string | undefined = "";
  public apellidoP?: string | null | undefined = "";
  public apellidoM?: string | null | undefined = "";
  //public tieneApMatB: boolean = false;
  public tieneApMat: boolean = false;
  // public tieneApPatB: boolean = false;
  public tieneApPat: boolean = false;
  public dia: string = "";
  public mes: string = "";
  public ano: string = "";
  public sexo: string = "";
  public isCIC: boolean = false;
  public entidadNacimiento: string | undefined = "";
  public curp: string | undefined = "";
  public existenciaVigencia: boolean | undefined = false;
  public vigencia: any;
  public ocr: string = "";
  public cic: string = "";
  public claveElector: string = "";
  public emision: string = "";
  public estados: any;
  public anioRegistro: string = "";
  public anioEmision: string = "";

  public falloCritico: boolean = false;
  public fallo: boolean = false;
  public nombreOriginal = this.storageService.bcStorage.apicNombre; //(apicNombre proviene de PE68).variable del nombre original para intentos del INE
  public apellidoPaternoOriginal = this.storageService.bcStorage.apicApellidoP; //(apicApellidoP proviene de PE68).variable del apellido paterno original para intentos del INE
  public apellidoMaternoOriginal?: string | null = this.storageService.bcStorage.apicApellidoM; //(apicApellidoM proviene de PE68).variable del apellido materno original para intentos del INE
  //public oneditableDataResponse: any;
  public esNombreEditado = false;
  public esAPaternoEditado = false;
  public esAMaternoEditado = false;
  public esIrAlIneCon390 = false;
  public primerIntento = 0; //Bandera para indicar si ya se realizó al comparación de los datos de 390 con el OCR al entrar a esta pantalla YYYY ya..
  public yaFueAlIne = false; // Bandera que indica si ya se realizo al menos una comparacion vs INE, para validar que la primera vez que va al INE tome los datos
  public curpValida: any;
  public solicitudRenapoCurpHomoclaveModificada = false;

  //      imagenes de tooltip
  public toolTipClaveElector = "assets/img/clave.png";
  public toolTipOCR_i = 'assets/img/ocr.png';
  public toolTipEmision = 'assets/img/emision.png';
  public toolTipFechaEmision = 'assets/img/ine_emision.png';
  public toolTipFechaRegistro = 'assets/img/ine_Registro.png';
  public toolTipCIC = 'assets/img/cic.png';
  public toolTipVigencia = 'assets/img/ine_vigencia.png';
  public toolTipCURP = 'assets/img/ine_curp.png';
  public toolTipEntidadNacimiento = 'assets/img/entidad_de_nacimiento.png';
  public toolTipFechaNacimiento = 'assets/img/ine_fecha de nacimeinto.png';

  public datosOCR = {
    nombre: '',
    apellidos: '',
    dia: '',
    mes: '',
    ano: ''
  };
  public datos390 = {
    nombre: '',
    apellidos: '',
    dia: '',
    mes: '',
    ano: ''
  };
  public regexCurp = /^[A-Z][A,E,I,O,U,X][A-Z]{2}[0-9]{2}[0-1][0-9][0-3][0-9][M,H][A-Z]{2}[B,C,D,F,G,H,J,K,L,M,N,Ñ,P,Q,R,S,T,V,W,X,Y,Z]{3}[0-9,A-Z]{2}$/ig;
  public intentosRENAPO = 3;

  public imgEdit = "assets/img//edit1.png";
  public imgAyuda = "assets/img/ayuda.svg";

  //#endregion

  constructor(
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private dialogs: UtilDialogs,
    private bCurp: BiocheckCurp,
    private Catalogos: CatalogosService,
    private cadena: BiocheckCadenas,
    private biocheckError: BiocheckErrorService,
    private Utils: BiocheckUtils,
  ) {
    //  this.bcService.crearConexion();
    this.storageService.bcStorage.documentScan = 1; // 1 = ife/ine   2 = FM   3 = Pasaporte
  }

  ngOnInit(): void {

    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    this.inicializarVista();
  }

  //#region ESCANER
  inicializarVista() {
    setTimeout(() => {
      this.Utils.totalPasos(4);
      this.Utils.cambiarPaso(4, "Datos del cliente");
      this.cargaOcrIne();
    }, 1000);
  }

  // cambiarPaso(paso: number, nombre: string) {
  //     $('#paso' + paso).css('text-decoration', 'underline');
  //     $("#nombrePasoActual").text(nombre);
  //     for (var i = 1; i <= paso; i++) {
  //         $('#paso' + i).css('color', '#ec0000');
  //     }
  // }

  //#region OCR INE
  cargaOcrIne() {
    this.nombre = this.storageService.bcStorage.apicNombre || '';//Origen PE68
    this.apellidoP = this.storageService.bcStorage.apicApellidoP || '';//Origen PE68
    this.apellidoM = this.storageService.bcStorage.apicApellidoM || '';//Origen PE68
    this.tieneApMat = (this.storageService.bcStorage.apicApellidoM) ? true : false;//Origen PE68
    (this.tieneApMat) ? this.storageService.bcStorage.apicApellidoM = this.storageService.bcStorage.apicApellidoM : this.storageService.bcStorage.apicApellidoM = '';//Origen PE68
    this.tieneApPat = (this.storageService.bcStorage.apicApellidoP) ? true : false;//Origen PE68
    (this.tieneApPat) ? this.storageService.bcStorage.apicApellidoP = this.storageService.bcStorage.apicApellidoP : this.storageService.bcStorage.apicApellidoP = '';//Origen PE68
    this.dia = this.storageService.bcStorage.apicDia || '';//Origen PE68
    this.mes = this.storageService.bcStorage.apicMes || '';//Origen PE68
    this.ano = this.storageService.bcStorage.apicAno || '';//Origen PE68
    this.sexo = this.storageService.bcStorage.sexo || 'M';//Origen OCR Escaner
    this.isCIC = this.storageService.bcStorage.isCIC || false;//Origen OCR Escaner// Esta variable indica si es una ine o una IFE, la INE es la única que trae CIC
    this.storageService.bcStorage.entidadNacimiento = this.cadena.limpiarEntidadNacimiento(this.storageService.bcStorage.apicNac, this.storageService.bcStorage.entidadNacimiento);//Origen entidadNacimiento OCR Escaner y apicNac Origen PE68
    var tmpEntidadNacimiento = this.bCurp.nombreEstado(this.storageService.bcStorage.entidadNacimiento || "OO");//Origen OCR Escaner
    console.log('entidad::' +tmpEntidadNacimiento);
    this.entidadNacimiento = (!tmpEntidadNacimiento) ? this.bCurp.nombreEstado("OO") : tmpEntidadNacimiento;//Origen OCR Escaner
    console.log(this.entidadNacimiento);
    this.entidadNacimiento = this.storageService.bcStorage.entidadNacimiento;
    this.curp = this.cadena.limpiarCurp(this.storageService.bcStorage.curp == undefined ? "" : this.storageService.bcStorage.curp);//Origen OCR Escaner
    this.existenciaVigencia = this.storageService.bcStorage.existenciaVigencia;//Origen OCR Escaner
    this.vigencia = this.cadena.limpiarVigencia(this.storageService.bcStorage.vigencia);//Origen OCR Escaner
    this.ocr = this.storageService.bcStorage.ocr || '';//Origen OCR Escaner
    this.cic = this.storageService.bcStorage.cic || '';//Origen OCR Escaner
    this.claveElector = this.cadena.validacionClaveElector(this.storageService.bcStorage.claveElector == undefined ? "" : this.storageService.bcStorage.claveElector)//Origen OCR Escaner
    this.emision = this.storageService.bcStorage.codigoEmision || '';//Origen OCR Escaner
    this.estados = this.Catalogos.estadosRenapo;

    this.init();
  }

  //2
  init() {
    this.curp = this.cadena.curpRemplazo(this.curp == undefined ? "" : this.curp);
    this.comparacionInterna();

    //Se setean variables en bcstorage para pintar el nombre en pantalla de finalizar
    this.storageService.bcStorage.nombreEditado = this.nombreOriginal = this.storageService.bcStorage.apicNombre; //Se vuelven a setear los nombres por si tuvieron alguna correción de Ñ
    this.storageService.bcStorage.apellidoPaternoEditado = this.apellidoPaternoOriginal = this.storageService.bcStorage.apicApellidoP;
    this.storageService.bcStorage.apellidoMaternoEditado = this.apellidoMaternoOriginal = this.storageService.bcStorage.apicApellidoM;
    if (!this.falloCritico) {
      this.primerIntento = 1;
      this.enviarVerificacion();
    }
  }

  //3
  enviarVerificacion() {
    this.continuarOCR();
  }

  //4
  continuarOCR(eligeDatosSistema: boolean = false) {
    if (eligeDatosSistema != null && eligeDatosSistema != undefined && eligeDatosSistema) {
      this.esIrAlIneCon390 = true;
    }
    // MXSLBIOM-1522: No se debe enviar el nombre escaneo de la credencial cuando se muestra y se edita algún campo en la pantalla 5
    if (this.yaFueAlIne == false && !this.falloCritico && (!this.curpValida || this.fallo)) {
      this.esIrAlIneCon390 = true;
    }

    if (this.curpValida && !this.fallo) {
      // biocheck.lastScreen = 'ocrdeife';
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.ifeRenapo);
      // winPros = $scope.procesando("Consultando RENAPO e INE");
      // winPros.open();
      if (!this.storageService.bcStorage.apicApellidoP)
        this.storageService.bcStorage.apicApellidoP = null;
      if (!this.storageService.bcStorage.apicApellidoM)
        this.storageService.bcStorage.apicApellidoM = null;

      //Valida si se realizo cambio en el nombr eoriginal
      if (this.storageService.bcStorage.apicApellidoPEditado != null || this.storageService.bcStorage.apicApellidoPEditado != undefined)
        this.storageService.bcStorage.apicApellidoP = this.storageService.bcStorage.apicApellidoPEditado;
      if (this.storageService.bcStorage.apicApellidoMEditado != null || this.storageService.bcStorage.apicApellidoMEditado != undefined)
        this.storageService.bcStorage.apicApellidoM = this.storageService.bcStorage.apicApellidoMEditado;
      if (this.storageService.bcStorage.apicNombreEditado != null || this.storageService.bcStorage.apicNombreEditado != undefined)
        this.storageService.bcStorage.apicNombre = this.storageService.bcStorage.apicNombreEditado;

      this.storageService.bcStorage.apellidoMaternoEditado = this.storageService.bcStorage.apicApellidoM;
      this.storageService.bcStorage.apellidoPaternoEditado = this.storageService.bcStorage.apicApellidoP;
      this.storageService.bcStorage.nombreEditado = this.storageService.bcStorage.apicNombre;

      /// ****IMPORTANTE****
      /// ****IMPORTANTE****
      /// ****IMPORTANTE****
      /// A ver, cabrones, para realizar la validación con el INE se toman los siguientes datos RECUPERADOS DE LA CREDENCIAL:
      ///this.storageService.bcStorage.nombre
      ///this.storageService.bcStorage.apellidoP
      ///this.storageService.bcStorage.apellidoM
      /// Antes se tomaban los de 390, se modificaban las Ñ y se mandaban, pero ya no más. De nada!!! Los tkm! :D
      /// Si se da el caso de que el usuario modifique caracteres, estos se modifican sobre 390
      /// y se envía ese dato en vez del que se toma de la credencial

      var nombreParaIne: string | null | undefined = "";
      var aPaternoParaIne: string | null | undefined = "";
      var aMaternoParaIne: string | null | undefined = "";

      aMaternoParaIne = this.esAMaternoEditado ? this.apellidoMaternoOriginal : this.storageService.bcStorage.apellidoM;
      if (this.esIrAlIneCon390) {
        nombreParaIne = this.esNombreEditado ? this.nombreOriginal : this.storageService.bcStorage.apicNombre;
        aPaternoParaIne = this.esAPaternoEditado ? this.apellidoPaternoOriginal : this.storageService.bcStorage.apicApellidoP;
        aMaternoParaIne = this.esAMaternoEditado ? this.apellidoMaternoOriginal : this.storageService.bcStorage.apicApellidoM;
      } else {
        nombreParaIne = this.esNombreEditado ? this.nombreOriginal : this.storageService.bcStorage.nombre;
        aPaternoParaIne = this.esAPaternoEditado ? this.apellidoPaternoOriginal : this.storageService.bcStorage.apellidoP;
        aMaternoParaIne = this.esAMaternoEditado ? this.apellidoMaternoOriginal : this.storageService.bcStorage.apellidoM;
      }

      // MXSLBIOM-1338: Se modificará que los datos que aparecen en Datos del cliente como en los pop ups y en la modificación de Nombre, Primer apellido y segundo apellido tienen que mostrarse lo que se envía al INE, actualmente se esta mostrando lo de 390.
      this.nombre = nombreParaIne;
      this.apellidoP = aPaternoParaIne;
      this.apellidoM = aMaternoParaIne;

      /// ****IMPORTANTE****
      /// ****IMPORTANTE****
      /// ****IMPORTANTE****

      if (aPaternoParaIne == "") {
        aPaternoParaIne = null;
      }

      if (aMaternoParaIne == "") {
        aMaternoParaIne = null;
      }
      var dataine = this.Utils.DataEditable(this.sexo, this.entidadNacimiento, this.curp, this.ocr, this.vigencia,
        nombreParaIne, aPaternoParaIne, aMaternoParaIne, this.claveElector, this.emision, this.cic);
      //AQUI DE DEBE REALIZAR LA VALIDACION DEL INE, SI ES EXITOSO ENVIA A finalizar, SI NO, REGRESA AL FORMULARIO DEL CLIENTE
      //biochkHub.server.editableData(dataine);

      const params = [
        dataine
      ];
      this.bcService.editableData(params);
      this.bcService.geteditableDataResponse();
      this.bcService.editableDataResponseRespuesta$.subscribe(response => {
        if (response == undefined) {
          this.oneditableDataResponse();
        }
      });
    } else {

    }
  }

  oneditableDataResponse() {
    //Si yá se realizó la consulta a RENAPO, no se debe volver a hacer
    if (this.storageService.bcStorage.renapoRespuesta) {
      this.verifyINE();
    } else {
      //Se manda a revisar CURP en Renapo
      this.solicitudRenapoCurpHomoclaveModificada = false;
      this.checkRenapo();
    }
  }

  checkRenapo() {
    this.bcService.checkRenapo();
    this.bcService.getresponseRenapo();
    this.bcService.responseRenapoRespuesta$.subscribe(response => {
      if (response) {
        this.responseRenapo(response);
      }
    });
  }

  checkRenapoCustomCurp(curpHomoclaveModificada: string) {
    const params = [
      curpHomoclaveModificada
    ];
    this.bcService.checkRenapoCustomCurp(params);
    this.bcService.getresponseRenapo();
    this.bcService.responseRenapoRespuesta$.subscribe(response => {
      if (response) {
        this.responseRenapo(response);
      }
    });
  }

  responseRenapo(response: any) {
    if (response == "true" || response == true || response == "false" || response == false) {
      if (response) {
        this.bcService.onStopSignalR();
        //  $scope.sig(4);
      } else {
        this.mensajeGeneral("Indica al cliente, que no se ha logrado validar los datos con RENAPO y que debes finalizar el proceso.", "Salir", "EVD01");
      }
    } else {
      if (response.code == 0) {
        if (response.result) {
          if (response.result.code === "OK0001") {
            this.curp = response.result.curpConsultada;
            this.storageService.bcStorage.renapoRespuesta = true;
            this.verifyINE();
          } else {
            this.mensajeGeneral("Indica al cliente, que no se ha logrado validar los datos con RENAPO y que debes finalizar el proceso.", "Salir", "EVD01");
          }
        }
      } else {
        if (response.code == 400) {
          var obj = JSON.parse(response.message);
          if (obj.errores) {
            if (obj.errores.length > 0) {
              if (obj.errores[0].code == "OK0002" || obj.errores[0].code == "BAD001") {
                if (this.solicitudRenapoCurpHomoclaveModificada == false && this.bCurp.esUltimoCaracterCambiable(this.curp == undefined ? "" : this.curp) == true) {
                  this.solicitudRenapoCurpHomoclaveModificada = true;
                  var curpHomoclaveModificada = this.bCurp.cambiaUltimoCaracterCurp(this.curp == undefined ? "" : this.curp);
                  //Se manda a revisar CURP con homoclave modificada en Renapo
                  this.checkRenapoCustomCurp(curpHomoclaveModificada);
                  return;
                } else {
                  //if (winPros) { winPros.close(); }
                  var message = "Indica al cliente, que no se ha logrado validar los datos con RENAPO y que debes finalizar el proceso.";
                  if (obj.errores[0].code == "BAD001") {
                    message = "Incorrecta Estructura en el CURP del cliente, coméntale que es necesario lo valide con RENAPO.";
                  }
                  this.mensajeGeneral(message, "Salir", "EVD01");
                }
              } else {
                //if (winPros) { winPros.close(); }
                if (this.intentosRENAPO > 1)
                  this.mensajeGeneral("El servicio de RENAPO no está disponible, reintente por favor", "Repetir", "Renapo");
                else
                  this.mensajeGeneral("El servicio de RENAPO no está disponible", "Seguir", "Renapo");
              }
            }
          } else if (obj.errors) {
            if (obj.errors.length > 0) {
              if (obj.errors[0].code == "OK0002" || obj.errors[0].code == "BAD001") {
                if (this.solicitudRenapoCurpHomoclaveModificada == false && this.bCurp.esUltimoCaracterCambiable(this.curp == undefined ? "" : this.curp) == true) {
                  this.solicitudRenapoCurpHomoclaveModificada = true;
                  var curpHomoclaveModificada = this.bCurp.cambiaUltimoCaracterCurp(this.curp == undefined ? "" : this.curp);
                  //Se manda a revisar CURP con homoclave modificada en Renapo
                  this.checkRenapoCustomCurp(curpHomoclaveModificada);
                  return;
                } else {
                  // if (winPros) { winPros.close(); }
                  var message = "Indica al cliente, que no se ha logrado validar los datos con RENAPO y que debes finalizar el proceso.";
                  if (obj.errors[0].code == "BAD001") {
                    message = "Incorrecta Estructura en el CURP del cliente, coméntale que es necesario lo valide con RENAPO.";
                  }
                  this.mensajeGeneral(message, "Salir", "EVD01");
                }
              } else {
                // if (winPros) { winPros.close(); }
                if (this.intentosRENAPO > 1)
                  this.mensajeGeneral("El servicio de RENAPO no está disponible, reintente por favor", "Repetir", "Renapo");
                else
                  this.mensajeGeneral("El servicio de RENAPO no está disponible", "Seguir", "Renapo");
              }
            }
          } else {
            //if (winPros) { winPros.close(); }
          }
        } else if (response.code == 404) {
          //   if (winPros) { winPros.close(); }
          if (this.intentosRENAPO > 1)
            this.mensajeGeneral("El servicio de RENAPO no está disponible, reintente por favor", "Repetir", "Repetir");
          else
            this.mensajeGeneral("El servicio de RENAPO no está disponible", "Seguir", "Renapo");
        } else {
          // if (winPros) { winPros.close(); }
          if (this.intentosRENAPO > 1)
            this.mensajeGeneral("El servicio de RENAPO no está disponible, reintente por favor", "Repetir", "Renapo");
          else
            this.mensajeGeneral("El servicio de RENAPO no está disponible", "Seguir", "Renapo");
        }
      }
    }
  }

  errorRENAPO() {
    if (this.intentosRENAPO > 1) {
      this.intentosRENAPO--;
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.ifeRenapo);
      // winPros = $scope.procesando("Consultando RENAPO e INE");
      // winPros.open();
      //Se manda a revisar CURP en Renapo
      this.solicitudRenapoCurpHomoclaveModificada = false;
      this.checkRenapo();
    } else {
      const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.ifeRenapo);
      // winPros = $scope.procesando("Consultando INE");
      // winPros.open();
      this.verifyINE();
    }

  };

  verifyINE() {
    this.bcService.verifyINE();
    this.bcService.getineResponse();
    this.bcService.ineResponseRespuesta$.subscribe(response => {
      if (response) {
        this.ineResponse(response);
      }
    });
  }

  public indiceRespondeIne: string = "";

  ineResponse(response: any) {
    this.storageService.bcStorage.hash = "";
    if (response.result != null && response.result != undefined && response.result.hash != null && response.result.hash != undefined) {
      this.storageService.bcStorage.hash = response.result.hash;
    }
    if (response.code == 0) {
      var msg = "";
      if (parseInt(response.result.response.codigoRespuesta) == 0) {
        if (response.result.response.minutiaeResponse != "" && response.result.response.minutiaeResponse != null) {
          var result2: number | null = 0;
          var result7: number | null = 0;
          //#region VALIDACIONES RESPUESTA INE
          if (response.result.response.minutiaeResponse.similitud2)
            if (response.result.response.minutiaeResponse.similitud2 != "" && response.result.response.minutiaeResponse.similitud2 != null) {
              // result2 = response.result.response.minutiaeResponse.similitud2.replace('%', '');
              result2 = parseFloat(response.result.response.minutiaeResponse.similitud2.replace('%', ''));
            }
          if (response.result.response.minutiaeResponse.similitud7)
            if (response.result.response.minutiaeResponse.similitud7 != "" && response.result.response.minutiaeResponse.similitud7 != null) {
              // result7 = response.result.response.minutiaeResponse.similitud7.replace('%', '');
              result7 = parseFloat(response.result.response.minutiaeResponse.similitud7.replace('%', ''));
            }
          if ((result2 >= 98 && result7 >= 98) || (result2 == 0 && result7 >= 98) || (result2 >= 98 && result7 == 0)) {
            //result2 indice derecho
            //result7 indice izquierdo

            //Aqui evaluamos que nombre y ApellidoP vengan en TRUE y ademas, si tiene Apellido Materno, "apellidoMaterno" debera de venir en TRUE
            //Si no tiene apellido materno, se omite la validacion
            var respcom = response.result.response.dataResponse.respuestaComparacion;
            // MXSLBIOM-1264: Al momento de validar sus datos del sistema vs INE, si 1 de los 3 campos (Nombre/ Apellido paterno/ apellido materno) de "True", la verificación sea exitosa.
            // Bug 2020PI06_SPRINT03_D003: Se solicita no se tome el null como true en la validación de una verificación en los campos Apellido Paterno y Materno.
            //Evaluar campo CURP enviado al INE
            var situacion = response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral;
            var OmitirVigencia = this.Utils.validaOmitirVigencia(situacion);
            if (!OmitirVigencia && situacion == "NO_VIGENTE") {
              var msg = this.biocheckError.codigoError("EOB09");
              this.modalErrorGeneral(msg, "Salir");
              return;
            }
            //#region EVALUA INDICE
            var timeStamp = response.result.timeStamp
            if (timeStamp !== null && timeStamp !== undefined) {
              var indice = response.result.timeStamp.indice;
              if (indice !== null && indice !== undefined) {
                this.indiceRespondeIne = indice;
                this.storageService.bcStorage.indice = this.indiceRespondeIne;
              }
            }
            //#endregion
            var EvaluarCurp = false;
            if (respcom.curp != "" && respcom.curp != null) {
              EvaluarCurp = true;
            }
            var camposCorrectos = 0;
            if (this.tieneApPat && respcom.apellidoPaterno == "true") {
              camposCorrectos++;
            }
            if (this.tieneApMat && respcom.apellidoMaterno == "true") {
              camposCorrectos++;
            }
            if (respcom.nombre == "true") {
              camposCorrectos++;
            }
            //#endregion
            if (EvaluarCurp) {// evalua CURP
              if ((this.isCIC || (respcom.ocr == "true" && respcom.claveElector == "true"
                && respcom.numeroEmisionCredencial == "true"
              )) && respcom.curp == "true" && camposCorrectos >= 2) {
                this.storageService.bcStorage.proceso = true;
                this.storageService.bcStorage.codigoflujo = "OK0000";
                this.storageService.bcStorage.mensajeflujo = "Validación Correcta";
                this.storageService.bcStorage.indice = this.indiceRespondeIne;
                this.storageService.bcStorage.ineRespuesta = true;

                this.Utils.getFinalDate();
              } else {
                this.storageService.bcStorage.proceso = false;
                this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
                this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
                this.storageService.bcStorage.indice = this.indiceRespondeIne;
                this.Utils.getFinalDate();
              }
            } else { ///no evalua CURP flujo viejito
              if ((this.isCIC || (respcom.ocr == "true" &&
                respcom.claveElector == "true"
                && respcom.numeroEmisionCredencial == "true"
              )) && camposCorrectos >= 2) {
                this.storageService.bcStorage.proceso = true;
                this.storageService.bcStorage.codigoflujo = "OK0000";
                this.storageService.bcStorage.mensajeflujo = "Validación Correcta";
                this.storageService.bcStorage.ineRespuesta = true;
                this.storageService.bcStorage.indice = this.indiceRespondeIne;
                this.Utils.getFinalDate();
              } else {
                this.storageService.bcStorage.proceso = false;
                this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
                this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
                this.storageService.bcStorage.indice = this.indiceRespondeIne;
                this.Utils.getFinalDate();
              }
            }

          } else {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
            this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
            this.storageService.bcStorage.indice = this.indiceRespondeIne;
            this.Utils.getFinalDate();
          }
        } else {
          /* !!! MXSLBIOM-1265 / MXSLBIOM-1638:
           * tipoReporteRoboExtravio: debe ser distinto de: REPORTE_DE_EXTRAVIO | REPORTE_DE_ROBO | REPORTE_DE_ROBO_TEMPORAL | REPORTE_DE_EXTRAVIO_TEMPORAL ====================================== */
          if (
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_EXTRAVIO" ||
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_ROBO" ||
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_ROBO_TEMPORAL" ||
            response.result.response.dataResponse.respuestaSituacionRegistral.tipoReporteRoboExtravio == "REPORTE_DE_EXTRAVIO_TEMPORAL") {
            var msg = this.biocheckError.codigoError("EOB09");
            this.modalErrorGeneral(msg, "Salir");
          } else {
            /* !!! MXSLBIOM-2448 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2019 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. Se deberá modificar la bandera no eliminarla, es decir, cuando termine la prórroga del INE se puede volver hacer las validaciones de las vigencias actuales.
             * !!! MXBIOC-193 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2020 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. ====================================== */
            var situacion = response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral;
            var OmitirVigencia = this.Utils.validaOmitirVigencia(situacion);
            if (!OmitirVigencia && situacion == "NO_VIGENTE") {
              var msg = this.biocheckError.codigoError("EOB09");
              this.modalErrorGeneral(msg, "Salir");
              return;
            }

            if (response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral == "NO_VIGENTE") {
              var msg = this.biocheckError.codigoError("EOB09");
              this.modalErrorGeneral(msg, "Finalizar");
            } else if (response.result.response.dataResponse.respuestaSituacionRegistral.tipoSituacionRegistral == "DATOS_NO_ENCONTRADOS") {
              var errores = "";
              var mensajefinal = "Favor de validar la información que no sea un error de captura, en caso de que no sea así sugiere que acuda al INE para actualizar su información";
              if (this.storageService.bcStorage.tipoIdentificacion === "INE")
                errores += "<li>Número de Credencial para votar - <a class='listErrorIne'>" + this.storageService.bcStorage.cic + "</a></li>";
              else {
                errores += "<li>Número de Credencial para votar - <a class='listErrorIne'>" + this.storageService.bcStorage.ocr + "</a></li>";
                errores += "<li>Clave de Elector - <a class='listErrorIne'>" + this.storageService.bcStorage.claveElector + "</a></li>";
              }
              msg = "<div class='dvListErrorIne'>Respuesta del INE</div><br />"
                + "<div class='dvMsgCliente'>Indica al cliente que debes finalizar el proceso, por que no se ha logrado validar los siguientes datos con el INE: <br><br>"
                + "<ul class='dvUlList'>" + errores + "</ul>" + mensajefinal + "</div>"
              this.storageService.bcStorage.proceso = false;
              this.storageService.bcStorage.codigoflujo = response.result.response.codigoRespuesta;
              this.storageService.bcStorage.mensajeflujo = "Validación no exitosa";
              // this.getFinalDate();
              this.modalErrorGeneral(msg, "Finalizar");


            } else {
              var resp = this.parseResponse(response.message);
              if (resp != null && resp != null)
                this.modalErrorGeneral(resp, "Finalizar");
              else
                this.modalErrorGeneral("El servicio de INE no esta disponible", "Finalizar");
            }
          }
        }
      } else {
        var resp = this.parseResponse(response.message);
        if (resp != null && resp != null)
          this.modalErrorGeneral(resp, "Finalizar");
        else
          this.modalErrorGeneral("El servicio de INE no esta disponible", "Finalizar");
      }
    } else {
      var resp = this.parseResponse(response.message);
      if (resp != null && resp != null)
        this.modalErrorGeneral(resp, "Finalizar");
      else
        this.modalErrorGeneral("El servicio de INE no esta disponible", "Finalizar");
    }
  }

  parseResponse(response: string) {
    let obj = JSON.parse(response);
    var msg = "";
    try {
      if (obj != null && obj != null) {
        var dato = obj.errores[0];
        msg = dato.message + ", " + dato.description;
      }
    } catch {
      msg = "";
    }
    return msg;
  }

  modalErrorGeneral(msg: string, accion: string, codigoError: string = "") {
    if (accion == "Salir" || accion == "Finalizar") {//salir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, accion);
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          //this.dialogFingerRef.close();
          this.Utils.getFinalDate();
        }
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    } else {//repetir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.Utils.errorFunction(codigoError);
        } else {
          this.Utils.cancelarinfo();
        }
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    }
  }

  comparacionInterna() {

    this.falloCritico = false;
    this.fallo = false;
    this.curpValida = true;
    //Campos no editables

    // #region ASIGNACIONES Y REEMPLAZO DE CARACTERES
    //----------------------ASIGNACIONES Y REEMPLAZO DE CARACTERES
    //----------------------ASIGNACIONES Y REEMPLAZO DE CARACTERES
    //----------------------ASIGNACIONES Y REEMPLAZO DE CARACTERES


    var apiAcompleto = '';
    if (this.tieneApPat && this.storageService.bcStorage.apicApellidoP !== undefined) {
      apiAcompleto += $.trim(this.storageService.bcStorage.apicApellidoP == null ? "" : this.storageService.bcStorage.apicApellidoP.replace(/\s/g, ''));
    }
    if (this.tieneApPat && this.storageService.bcStorage.apicApellidoP !== undefined) {
      if (this.tieneApMat && this.storageService.bcStorage.apicApellidoM !== undefined) {
        apiAcompleto += $.trim(this.storageService.bcStorage.apicApellidoM == null ? "" : this.storageService.bcStorage.apicApellidoM.replace(/\s/g, ''));
      }

      //Se quitan espacios en blanco y caracteres especiales ALV!!! D: D: D:
      var apellidosocr = "";
      if (this.storageService.bcStorage.apellidos !== undefined) {
        apellidosocr = $.trim(this.storageService.bcStorage.apellidos.replace(/\s/g, ''));
        apellidosocr = this.cadena.normalizarCandena(apellidosocr);
      } else {
        apellidosocr = '';
      }

      //Se quitan espacios en blanco y caracteres especiales ALV!!! D: D: D:
      var nombreocr = "";
      if (this.storageService.bcStorage.nombre !== undefined) {
        nombreocr = $.trim(this.storageService.bcStorage.nombre.replace(/\s/g, ''));
        nombreocr = this.cadena.normalizarCandena(nombreocr);
      } else {
        nombreocr = '';
      }

      var nombreApi = "";
      if (this.storageService.bcStorage.apicNombre !== undefined || this.storageService.bcStorage.apicNombre !== "") {
        nombreApi = $.trim(this.storageService.bcStorage.apicNombre == null ? "" : this.storageService.bcStorage.apicNombre.replace(/\s/g, ''));

      } else {
        nombreApi = '';
      }

      var anoocr = "";
      if (this.storageService.bcStorage.ano !== undefined) {
        anoocr = $.trim(this.storageService.bcStorage.ano.replace(/[^a-z0-9\s]/g, '').replace(/[_\s]/g, ''));

      } else {
        anoocr = '';
      }
      var mesocr = "";
      if (this.storageService.bcStorage.mes !== undefined) {
        mesocr = $.trim(this.storageService.bcStorage.mes.replace(/[^a-z0-9\s]/g, '').replace(/[_\s]/g, ''));
      } else {
        mesocr = '';
      }
      var diaocr = "";
      if (this.storageService.bcStorage.dia !== undefined) {
        diaocr = $.trim(this.storageService.bcStorage.dia.replace(/[^a-z0-9\s]/g, '').replace(/[_\s]/g, ''));

      } else {
        diaocr = '';
      }
      var anoApi = "";
      if (this.storageService.bcStorage.apicAno !== undefined) {
        anoApi = $.trim(this.storageService.bcStorage.apicAno.replace(/[^a-z0-9\s]/g, '').replace(/[_\s]/g, ''));

      } else {
        anoApi = '';
      }
      var mesApi = "";
      if (this.storageService.bcStorage.apicMes !== undefined) {
        mesApi = $.trim(this.storageService.bcStorage.apicMes.replace(/[^a-z0-9\s]/g, '').replace(/[_\s]/g, ''));

      } else {
        mesApi = '';
      }
      var diaApi = "";
      if (this.storageService.bcStorage.apicDia !== undefined) {
        diaApi = $.trim(this.storageService.bcStorage.apicDia.replace(/[^a-z0-9\s]/g, '').replace(/[_\s]/g, ''));

      } else {
        diaApi = '';
      }
      // #endregion


      var cambiodennombres = false;
      var cambiodenapellidos = false;
      var posdenapellidos = [];
      var posdennombres = [];

      // #region COMPARACIÓN 390 VS CREDENCIAL
      //----------------------COMPARACIÓN 390 VS CREDENCIAL
      //----------------------COMPARACIÓN 390 VS CREDENCIAL
      //----------------------COMPARACIÓN 390 VS CREDENCIAL
      if (nombreocr !== nombreApi) {

        if (nombreocr.length === nombreApi.length) {
          for (var letra = 0; letra < nombreocr.length; letra++) {
            if (nombreocr[letra] !== nombreApi[letra]) {
              if (nombreApi[letra] === 'N' && nombreocr[letra] === 'Ñ') {
                cambiodennombres = true;
                posdennombres.push(letra);
              } else
                this.falloCritico = true;
            }
          }
        } else {
          this.falloCritico = true;
        }
        if (this.falloCritico) {
          this.datosOCR.nombre = this.storageService.bcStorage.nombre == undefined ? "" : this.storageService.bcStorage.nombre;
          this.datos390.nombre = this.storageService.bcStorage.apicNombre == undefined ? "" : this.storageService.bcStorage.apicNombre;
        }
      }

      if (apiAcompleto !== apellidosocr) {
        if (apiAcompleto.length === apellidosocr.length) {
          for (var letra = 0; letra < apiAcompleto.length; letra++) {
            if (apiAcompleto[letra] !== apellidosocr[letra]) {
              if (apiAcompleto[letra] === 'N' && apellidosocr[letra] === 'Ñ') {
                cambiodenapellidos = true;
                posdenapellidos.push(letra);
              } else
                this.falloCritico = true;
            }
          }
        } else {
          this.falloCritico = true;
        }
        if (this.falloCritico) {
          this.datosOCR.apellidos = this.storageService.bcStorage.apellidos == undefined ? "" : this.storageService.bcStorage.apellidos;
          this.datos390.apellidos = this.storageService.bcStorage.apicApellidoP + ' ' + this.storageService.bcStorage.apicApellidoM;
        }
      }

      //Si hay letras Ñ las reemplaza
      if (cambiodennombres) {
        this.storageService.bcStorage.apicNombre = this.storageService.bcStorage.apicNombre == undefined ? "" : this.storageService.bcStorage.apicNombre.split("")[0];
        for (var posene = 0; posene < posdennombres.length; posene++) {
          var letran = 0;
          var posn = 0;
          while (posn != posdennombres[posene]) {
            if (!(this.storageService.bcStorage.apicNombre[letran] == ' ') || (this.storageService.bcStorage.apicNombre[letran] == '\t') || (this.storageService.bcStorage.apicNombre[letran] == '\n')) {
              posn++;
            }
            letran++;
          }
          //this.storageService.bcStorage.apicNombre[letran] = 'Ñ';
        }
        this.storageService.bcStorage.apicNombre = this.storageService.bcStorage.apicNombre + " ";//join("");
      }

      //Si hay letras Ñ las reemplaza
      if (cambiodenapellidos) {
        var iCompleto = 0;
        var iPadre = 0;
        var iMadre = 0;
        var apP = this.storageService.bcStorage.apicApellidoP == null ? "" : this.storageService.bcStorage.apicApellidoP.split("");
        var apM = this.storageService.bcStorage.apicApellidoM == null ? "" : this.storageService.bcStorage.apicApellidoM.split("");
        var apellidos = this.storageService.bcStorage.apellidos == null ? "" : this.storageService.bcStorage.apellidos.split("");
        // var esEspacio = function (cadena) {


        //   return (cadena == ' ' || cadena == '\t' || cadena == '\n') == true;
        // };


        while (iCompleto < apellidos.length) {
          if (!this.esEspacio(apellidos[iCompleto])) {
            if (iCompleto < apP.length) {
              if (this.esEspacio(apP[iPadre])) {
                iPadre++;
                continue;
              } else {
                if (apellidos[iCompleto] == "Ñ" && apP[iPadre] == "N") {
                  // apP[iPadre] = "Ñ";
                }
                iPadre++;
              }
            } else {
              if (this.esEspacio(apM[iMadre])) {
                iMadre++;
                continue;
              } else {
                if (apellidos[iCompleto] == "Ñ" && apM[iMadre] == "N") {
                  //  apM[iMadre] = "Ñ";
                }
                iMadre++;
              }
            }
          }
          iCompleto++;
        }
        this.storageService.bcStorage.apicApellidoP = apP + "";//.join("");
        this.storageService.bcStorage.apicApellidoM = apM + "";//.join("");
      }

      if (anoocr !== anoApi) {
        this.datosOCR.ano = this.storageService.bcStorage.ano == undefined ? "" : this.storageService.bcStorage.ano;
        this.datos390.ano = this.storageService.bcStorage.apicAno == undefined ? "" : this.storageService.bcStorage.apicAno;
        this.falloCritico = true;
      }

      if (mesocr !== mesApi) {
        this.datosOCR.mes = this.storageService.bcStorage.mes == undefined ? "" : this.storageService.bcStorage.mes;
        this.datos390.mes = this.storageService.bcStorage.apicMes == undefined ? "" : this.storageService.bcStorage.apicMes;
        this.falloCritico = true;
      }
      if (diaocr !== diaApi) {
        this.datosOCR.dia = this.storageService.bcStorage.dia == undefined ? "" : this.storageService.bcStorage.dia;
        this.datos390.dia = this.storageService.bcStorage.apicDia == undefined ? "" : this.storageService.bcStorage.apicDia;
        this.falloCritico = true;
      }
      // #endregion

      // #region VALIDACIÓN DE REGLA DE NEGOCIO
      //----------------------VALIDACIÓN DE REGLA DE NEGOCIO
      //----------------------VALIDACIÓN DE REGLA DE NEGOCIO
      //----------------------VALIDACIÓN DE REGLA DE NEGOCIO

      if (this.existenciaVigencia === true) {
        /* !!! MXSLBIOM-2448 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2019 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. Se deberá modificar la bandera no eliminarla, es decir, cuando termine la prórroga del INE se puede volver hacer las validaciones de las vigencias actuales.
         * !!! MXBIOC-193 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2020 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. ====================================== */
        var anioVigencia = parseInt((this.storageService.bcStorage.vigencia) ? this.storageService.bcStorage.vigencia : 0);
        var listEstadosVigencia = this.storageService.bcStorage.EstadosVigenciaIne !== undefined ? this.storageService.bcStorage.EstadosVigenciaIne.split(',') : "";
        var ExisteEstado = false; //listEstadosVigencia !== "" ? listEstadosVigencia.find(function (value, index) { return value == this.storageService.bcStorage.ClaveEntidad; }) : false;
        var FechaAplicaVigencia = this.storageService.bcStorage.FechaVigenciaProrroga !== undefined ? (this.storageService.bcStorage.FechaVigenciaProrroga !== "" ? new Date(this.storageService.bcStorage.FechaVigenciaProrroga) : new Date("01/01/1990")) : new Date("01/01/1990")
        var fechaDeHoy = new Date();
        var anio = fechaDeHoy.getFullYear(); //año valido vigente
        var FechaTerminoProrroga = true;
        if (anioVigencia < anio && FechaAplicaVigencia < fechaDeHoy)
          FechaTerminoProrroga = false
        var reglaOmitirVigencia = this.storageService.bcStorage.OmitirVigenciaIne === true && FechaTerminoProrroga && ExisteEstado != undefined;
        if (reglaOmitirVigencia === false && (this.vigencia) && (this.vigencia < (new Date()).getFullYear())) {
          this.msjvigencia = 'Vigencia vencida';
          this.fallo = true;
        }
        if (this.vigencia.length === 0) {
          this.msjvigencia = 'Campo vacío';
          this.fallo = true;
        } else if (!this.vigencia.match(/^[0-9]*$/i)) {
          this.msjvigencia = 'Solo se aceptan números';
          this.fallo = true;
        }
      } else {
        this.vigencia = '';
        $("#vigencia").attr('disabled', 'true');
      }


      // Validacion de nuemero de emision
      //var msjclaveElector = null;

      if (this.claveElector.length == 0 || this.claveElector == undefined) {
        this.msjclaveElector = 'Campo vacío';
        this.fallo = true;
      } else if (this.claveElector.length === 18) {
        if (this.claveElector == this.claveElector.toUpperCase()) {
          if (this.claveElector.match(/[A-Z]{6}[0-9]{8}[A-Z]{1}[0-9]{3}/)) {
            var edadClaveElector = this.claveElector.substring(6, 12);
            var sexoClaveElector = this.claveElector.substring(14, 15);
            var fechaConcatenada = this.storageService.bcStorage.apicAno == undefined ? "" : this.storageService.bcStorage.apicAno.substring(2, 4).concat(this.storageService.bcStorage.apicMes == undefined ? "" : this.storageService.bcStorage.apicMes).concat(this.storageService.bcStorage.apicDia == undefined ? "" : this.storageService.bcStorage.apicDia);
            if (edadClaveElector !== fechaConcatenada) {
              this.msjclaveElector = 'La fecha no coincide con la del sistema';
              this.fallo = true;
            } else if (sexoClaveElector != this.sexo) {
              this.msjclaveElector = 'El sexo debe ser ' + this.sexo;
              this.fallo = true;
            } else {
              this.msjclaveElector = null;
            }
          } else {
            this.msjclaveElector = 'Estructura incorrecta';
            this.fallo = true;
          }
        } else {
          this.msjclaveElector = 'Solo se aceptan números y letras en mayúsculas';
          this.fallo = true;
        }
      } else {
        this.msjclaveElector = 'Requiere 18 caracteres';
        this.fallo = true;
      }

      if (this.isCIC) {
        var soloNumCic = this.cic.match(/^[0-9]*$/i);
        // Validacion de CIC
        if (this.cic.length == 0) {
          this.msjcic = 'Campo vacío';
          this.fallo = true;
        } else if (this.cic.length != 9) {
          this.msjcic = 'Requiere 9 caracteres';
          this.fallo = true;
        } else if (soloNumCic == null) {
          this.msjcic = 'Solo se aceptan números';
          this.fallo = true;
        } else {
          this.msjcic = null;
        }
      } else {
        // Validacion de nuemero de emision
        if (this.emision.length == 0) {
          this.msjemision = 'Campo vacío';
          this.fallo = true;
        } else if (this.emision.length != 2) {
          this.msjemision = 'Formato incorrecto';
          this.fallo = true;
        } else if (!this.emision.match(/^[0-9]*$/i)) {
          this.msjemision = 'Solo se aceptan números';
          this.fallo = true;
        } else {
          this.msjemision = null;
        }
      }
      var CURPcalculado = this.bCurp.generar(this.storageService.bcStorage.apicNombre == undefined ? "" : this.storageService.bcStorage.apicNombre, this.storageService.bcStorage.apicApellidoP == undefined ? "" : this.storageService.bcStorage.apicApellidoP, this.storageService.bcStorage.apicApellidoM == undefined ? "" : this.storageService.bcStorage.apicApellidoM, this.ano, this.mes, this.dia, this.sexo, this.entidadNacimiento).toUpperCase();

      // Se obtienen las curp sin los ultimos dos digitos de homoclabe para comparación.
      // Estos dos dígitos son dos dígitos que se asignan por RENAPO en el momento de sacar tu curp y se hace de manera aleatoria. (Si se pueden calcular los 16 primeros dígitos con certeza, pero la homoclave no viene de ningún cálculo).
      var curpSinHomoclabe = this.curp == undefined ? "" : this.curp.substring(0, 16).toUpperCase();
      var curpCalculadoSinHomoclabe = CURPcalculado.substring(0, 16).toUpperCase();
      var curpIgualACalculada = curpSinHomoclabe === curpCalculadoSinHomoclabe;

      this.curp = this.curp == undefined ? "" : this.curp.toUpperCase();
      this.curpValida = this.curp.match(this.regexCurp);

      var error = false;
      if (this.entidadNacimiento === '---- Selecciona Estado ----') {
        this.msjcurp = 'Selecciona una entidad de nacimiento';
        this.msjsugerenciacurp = null;
        this.fallo = true;
      } else {
        if (this.curp.length === 18) {
          if (this.curp === this.curp.toUpperCase()) {
            if (this.curpValida) {
              if (this.bCurp.validarFechaCurp(this.curp, this.dia, this.mes, this.ano)) {
                this.msjcurp = '';
                if (curpIgualACalculada) {
                  this.msjcurp = '';
                  this.msjsugerenciacurp = '';
                  error = true;
                } else {
                  this.msjcurp = '';
                  this.msjsugerenciacurp = 'Ejemplo de CURP: ' + CURPcalculado;
                  error = true;
                }
              } else {
                this.msjsugerenciacurp = '';
                this.msjcurp = 'Estructura de CURP incorrecta';
                this.fallo = true;
              }
            } else {
              this.msjsugerenciacurp = '';
              this.msjcurp = 'Estructura de CURP incorrecta';
              this.fallo = true;
            }
          } else {
            this.msjcurp = 'Solo se aceptan números y letras en mayúsculas';
            this.fallo = true;
          }
        } else if (this.curp.length === 0) {
          this.msjsugerenciacurp = '';
          this.msjcurp = 'Campo vac\u00EDo';
          this.fallo = true;
        } else {
          this.msjsugerenciacurp = '';
          this.msjcurp = 'Requiere 18 caracteres';
          this.fallo = true;
        }
      }

      var soloNumOCR = this.ocr.match(/^[0-9]*$/i);
      if (this.ocr.length === 0) {
        this.msjocr = 'Campo vacío';
        this.fallo = true;
      } else if (soloNumOCR == null) {
        this.msjocr = 'Solo se aceptan números';
        this.fallo = true;
      } else if (!this.ocr.match(/^(?:[\d]{13})$/)) {
        this.msjocr = 'Requiere 13 caracteres';
        this.fallo = true;
      }
      // #endregion

      // #region RESULTADO VALIDACIÓN
      //----------------------RESULTADO VALIDACIÓN
      //----------------------RESULTADO VALIDACIÓN
      //----------------------RESULTADO VALIDACIÓN
      // this.btnValidacion = this.curpValida && !this.fallo;

      // this.$applyAsync();

      // function cerrarTipsoOcr() {
      //   try {
      //     if (!tipsoCredencial || tipsoCredencial == undefined || tipsoCredencial == null) {
      //       tipsoCredencial = $('.' + classButtonCredencial);
      //     }
      //     if (!tipsoSistema || tipsoSistema == undefined || tipsoSistema == null) {
      //       tipsoSistema = $('.' + classButtonSistema);
      //     }
      //     tipsoCredencial.tipso('hide');
      //     tipsoSistema.tipso('hide');
      //   } catch (error) {
      //     console.error(error);
      //   }
      // }

      // var modalCritico = biocheck.modalerrorocrCustomBtn(
      //   ,
      // function () {

      // },
      // function () {
      //   cerrarTipsoOcr();
      //   biocheck.modalerrormensaje("<style>.jconfirm-content-pane{ height:auto!important }</style><img src='img/actualizar_datos.png'  width='180px'><br/> <span>Debes salir de Biocheck y actualizar los datos en nuestro sistema </span><br/><span style='font-weight:normal;'>Mencionarle al cliente que debe actualizar sus datos </span><br/><span style='font-weight:normal;'>y en su próxima visita registrarse en Biocheck</span>", "Finalizar",
      //     function () {
      //       this.storageService.bcStorage.proceso = false;
      //       this.storageService.bcStorage.codigoflujo = "EOB07";
      //       biochkHub.server.getFinalDate();
      //     });
      // }, 'Credencial', 'Sistema', 'Seleccione que dato es correcto', classButtonCredencial, classButtonSistema,
      //   function () {
      //     tipsoCredencial = $('.' + classButtonCredencial);
      //     tipsoSistema = $('.' + classButtonSistema);
      //     tipsoCredencial.tipso({
      //       position: 'bottom-right',
      //       background: '#deedf2',
      //       color: '#000',
      //       useTitle: false,
      //       tooltipHover: true,
      //       width: 380,
      //       content: "Para seguir con el proceso, sal de Biocheck y actualiza los datos en ABC"
      //     });
      //     tipsoSistema.tipso({
      //       position: 'bottom-right',
      //       background: '#deedf2',
      //       color: '#000',
      //       useTitle: false,
      //       tooltipHover: true,
      //       width: 380,
      //       content: "Se enviaran los datos al INE como están registrado en el sistema"
      //     });
      //   }
      // );

      if (this.primerIntento == 0 && this.falloCritico) {
        // modalCritico.open();
        this.primerIntento = 1;
      }
      // #endregion

    }
    ;


    //#endregion
  }

  mensajeGeneral(mensaje: string, accion: string, codigoError: string) {

    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogError(mensaje, accion);
    this.dialogRef.afterClosed().subscribe(response => {
      if (response) {
        if (codigoError != "") {
          if (codigoError == 'Renapo')
            this.errorRENAPO();
          else
            this.Utils.errorFunction(codigoError);
        }
        try {
          this.Utils.sendLog('warning', '', this.Utils.errorVigencia());
        } catch (tryError) {
        }
      }
    });

  }

  cancelar() {
    this.Utils.cancelar();
  }

  modalCritico(diaApi: string, mesApi: string, anoApi: string, diaocr: string, mesocr: string, anoocr: string) {
    var body = "<div class='mb-5' style='text - align: center;font-size:18px'><strong>Instrucciones: </strong> Seleccione que dato es correcto</div>" +
      "<div class='txtleft'>" +
      "<span style='margin-top: 150px;margin-bottom: 150px'><strong>" +
      "Datos del sistema</strong></span><br/>" +
      "<span style='font-weight: normal'>Nombre Completo: " + ((this.datos390.nombre) ? "<span style='color: #ec0000'>" + this.datos390.nombre + "</span>" : this.storageService.bcStorage.apicNombre) + " " + ((this.datos390.apellidos) ? "<span style='color: #ec0000'>" + this.datos390.apellidos + "</span>" : this.storageService.bcStorage.apicApellidoP + " " + this.storageService.bcStorage.apicApellidoM) + "</span></br>" +
      "<span style='font-weight: normal'>Fecha de nacimiento: " + ((this.datos390.dia) ? "<span style='color: #ec0000'>" + this.datos390.dia + " - </span>" : diaApi + " - ") + ((this.datos390.mes) ? " <span style='color: #ec0000'>" + this.datos390.mes + "</span>" : mesApi) + ((this.datos390.ano) ? "<span style='color: #ec0000'> - " + this.datos390.ano + "</span>" : " - " + anoApi) + "</span></br>"
      + "<br/><span><strong>Datos de la credencial</strong></span></br>" +
      "<span style='font-weight: normal'>Nombre: " + ((this.datosOCR.nombre) ? "<span style='color: #ec0000'>" + this.datosOCR.nombre + "</span>" : this.storageService.bcStorage.nombre) + " " + ((this.datosOCR.apellidos) ? "<span style='color: #ec0000'>" + this.datosOCR.apellidos + "</span>" : this.storageService.bcStorage.apellidos) + "</span></br>" +
      "<span style='font-weight: normal'>Fecha de nacimiento: " + ((this.datosOCR.dia) ? "<span style='color: #ec0000'>" + this.datosOCR.dia + " - </span>" : diaocr + " - ") + ((this.datosOCR.mes) ? " <span style='color: #ec0000'>" + this.datosOCR.mes + "</span>" : mesocr) + ((this.datosOCR.ano) ? "<span style='color: #ec0000'> - " + this.datosOCR.ano + "</span>" : " - " + anoocr) + "</span>" +
      "<div>";
    //cerrarTipsoOcr();
    const falloCritico = false;
    //  modalCritico.close();
    this.continuarOCR(true);
  }

  esEspacio(cadena: string) {
    return (cadena == ' ' || cadena == '\t' || cadena == '\n') == true;
  }


  validacioninputs() {
    this.msjnombre = "";
    this.msjapellidop = "";
    this.msjapellidom = "";
    this.msjdia = "";
    this.msjmes = "";
    this.msjano = "";
    this.msjsexo = "";
    this.msjentidad = "";
    this.msjcurp = "";
    this.msjvigencia = "";
    this.msjocr = "";
    // this.msjApellidoMMod = "";
    // this.msjApellidoPMod = "";
    // this.msjnombreMod = "";
    this.comparacionInterna();

  };
}
