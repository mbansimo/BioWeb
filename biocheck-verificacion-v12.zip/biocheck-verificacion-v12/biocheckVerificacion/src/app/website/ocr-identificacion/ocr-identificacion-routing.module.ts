import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OcrIdentificacionComponent } from './component/ocr-identificacion.component';

const routes: Routes = [
    { path: '', component: OcrIdentificacionComponent }

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class OcrIdentificacionRoutingModule { }
