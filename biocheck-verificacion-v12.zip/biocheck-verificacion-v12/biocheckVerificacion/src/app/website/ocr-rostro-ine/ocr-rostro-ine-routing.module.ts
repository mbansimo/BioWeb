import {RouterModule, Routes} from "@angular/router";
import {OcrRostroIneComponent} from "./ocr-rostro-ine.component";
import {NgModule} from "@angular/core";


const routes: Routes = [
  {path: '', component: OcrRostroIneComponent},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OcrRostroIneRoutingModule{}
