import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.scss']
})
export class TooltipComponent implements OnInit {


  public footerTooltip = 'Son 13 dígitos después de las letras.';
  public headerTooltip = '';
  public headerTooltip2 = '';
  public tituloTooltip = '';
  public ToolTipClaveElector = "assets/img/clave.png";
  public ToolTipOCR = 'assets/img/ocr.png';
  public ToolTipEmision = 'assets/img/emision.png';
  public ToolTipFechaEmision = 'assets/img/ine_emision.png';
  public ToolTipFechaRegistro = 'assets/img/ine_emision.png';
  public ToolTipCIC = 'assets/img/cic.png';


  constructor() {
  }

  ngOnInit(): void {
    //  debugger;
  }

}
