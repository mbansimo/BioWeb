import { NgModule } from '@angular/core';
import { TooltipComponent } from "./tooltip.component";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatChipsModule } from "@angular/material/chips";
import { OverlayModule } from "@angular/cdk/overlay";
import { MatDividerModule } from "@angular/material/divider";

@NgModule({
  declarations: [
    TooltipComponent
  ],
  exports: [
    TooltipComponent
  ],
  imports: [
    MatTooltipModule,
    MatChipsModule,
    OverlayModule,
    MatDividerModule,
  ]
})
export class TooltipModule { }
