import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VentanillaComponent } from "./ventanilla.component";


const routes: Routes = [
  {
    path: '',
    component: VentanillaComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VentanillaRoutingModule { }
