import {Component, OnDestroy, OnInit} from '@angular/core';
import {UtilDialogs} from 'src/app/common/util-dialogs';
import {BiocheckService} from "../../core/services/biocheck.service";
import {ActivatedRoute, Router} from "@angular/router";
import {PostParentService} from "../../core/services/post-parent.service";
import {BcstorageService} from 'src/app/core/services/bcstorage.service';
import {MatDialogRef} from '@angular/material/dialog';
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import * as $ from "jquery";
import {FinalDateModel} from "../../core/models/final-date.model";
import {ConfiguracionRespuestaModel} from "../../core/models/configuracion-respuesta.model";
import {BiocheckErrorService} from "../../core/services/biocheck.error.service";


@Component({
  selector: 'app-ventanilla',
  template: '',
})
export class VentanillaComponent implements OnInit, OnDestroy {

  public tituloInstruccion: string = '';

  public versionBiocheck!: string;
  public verCancelar: boolean = true;//Muestra u oculta el boton cancelar
  public verVerificar: boolean = true;//Muestra u oculta el boton de verificar
  //public instruccion: string = ''; //Instruccion que se mostrara en la cabecera y modal
  public intentosCapturaHuella: number = 0; //Intentos para capturar la huella
  public intentosVerificar: number = 3; //Intentos para verificar la huella
  public iscapturing: boolean = false;

  public guid: string = ''; // Se envia al servicio
  public dedos: any[] = []; //Lista de dedos enrolados
  public dedosManoDerechaPrincipales: any[] = []; //Dedos disponibles para la mano derecha principales
  public dedosManoIzquierdaPrincipales: any[] = [];//Dedos disponibles para la mano izquierda principales
  public dedosManoDerechaOpcional: any[] = []; //Dedos disponibles para la mano derecha opcionales
  public dedosManoIzquierdaOpcional: any[] = [];//Dedos disponibles para la mano izquierda opcionales
  // bcstorage.esEjecutivo = getParameterByName('isPreVerif') == "true"; //Indica si se está realizando una preverificación
  public mano: number = 0; //1)mano derecha 2)Mano izquierda 0)Mano sin definir
  public dedoEnviar: number = 0; //Es el dedo que enviaremos a verificar
  public arrayIntentoHuellas: any[] = [];
  public isnotwhitelist: boolean = true;
  public contadorBug: number = 0;
  public dedosaux: any[] = [];


  //Elementos del DOM
  public versionComercial: string = '';
  public versionInstalador: string = '';
  public statusCaptura: string = '';  //Captura exitosa  o no exitosa
  public marcoHuella: string = ''; //Marco que cambia de color dependiendo la captura
  public procesando: string = 'Captura huellas';  //Modal de procesando
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public dedoSelec = $('#dedoSelec');//Imagen de la huella seleccionada
  public procesadorInvoked: boolean = false; //bandera para saber si ya se invoco procesador y no invocarlo nuevamente


  public dialogRef: MatDialogRef<any, any> | undefined;
  public dialogGen: MatDialogRef<any, any> | undefined;


  constructor(
    private bcService: BiocheckService,
    private postParentService: PostParentService,
    private storageService: BcstorageService,
    private biocheckError: BiocheckErrorService,
    private dialogs: UtilDialogs,
    private router: Router,
  ) {
  }

  ngOnInit(): void {

    this.postParentService.postTokenParent();
    this.bcService.checkService();
    this.bcService.connection$.subscribe(response => {
      if (response) {
        console.log('::::: Inicia componente Ventanilla :::::');
        this.storageService.bcStorage.esEjecutivo = this.getParameterByName('isPreVerif') == "true";
        this.storageService.bcStorage.versionSistema = "3.2.2.5"; //(VersionInstalador)Controla La versión del Windows service con la que debe de ejecutarse
        this.storageService.bcStorage.versionBiocheck = "1.4.6";  //(versionComercial)Muestra la etiqueta de la versión comercial que se muestra en el header
        this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;
        this.storageService.bcStorage.issuper = false;
        this.consultaInit();    //Temporal para iniciar el diálogo
      }
    }, error => {
      console.log(error);
    })
  }

  ngOnDestroy() {
    this.bcService.failProcesadorUnsubscribe();
//    this.bcService.respuestaProcesadorUnsubscribe();
//    this.bcService.licsuccessUnsubscribe();
//    this.bcService.devicesSuccessUnsubcribe();

    console.log('Observable cerrado');
  }

  //orden de ejecucion 1
  consultaInit() {
    if (this.storageService.bcStorage.tipoVerificacion != 'NoClientePasaporte') {
      console.log('ingreso consultaInit');
      const urlRef = window.location.href;
      this.mostrarDialogProcesando();
      this.inicioObservables();   // iniciamos los observables a utilizar
      this.eraseBiometrics();//Borramos los datos biometricos y biograficos
      this.getVersionInstalador();  //Obtenemos la version del despliegue
      this.getUrlFront(urlRef);   //Mandamos la url al servicio
    } else {
      this.existeDatosCanal();
    }
  }

  existeDatosCanal() {
    var datosCanal = this.storageService.bcStorage.datosCanal;
    if (datosCanal && datosCanal !== undefined && datosCanal !== null && datosCanal !== "") {
      if (typeof datosCanal !== 'string') {
        datosCanal = JSON.stringify(datosCanal);
      }
    }
    this.sendLog("info", "PaaS [" + window.location.href + "] startSignalR", "Datos personalizados cliente: " + datosCanal)
    if (datosCanal == undefined || datosCanal == null || datosCanal == "") {
      console.log('Ingreso a cancelar por validacion no hay datos::::::')
      //biocheck.modalerrormensaje("No se han enviado los datos adicionales, por lo tanto no se podran camparar los datos escaneados del documento.", "Salir", "");
      this.cancelarPorValidacion();
    } else {
      console.log('paso 2 ingresa a mostra dialogo e servicios de url front:::::: paso 2')
      const urlRef = window.location.href;
      this.mostrarDialogProcesando();
      this.inicioObservables();   // iniciamos los observables a utilizar
      this.eraseBiometrics();//Borramos los datos biometricos y biograficos
      this.getVersionInstalador();  //Obtenemos la version del despliegue
      this.getUrlFront(urlRef);   //Mandamos la url al servicio
    }

  }

  public tipoVerificacion: string | undefined = '';

  mostrarDialogProcesando() { //el tipoVerificacion se obtiene desde el componente HOME en el metodo tipoDeFlujoVerificacion() asegurar agregar su metodo para mostrar
    this.tipoVerificacion = this.storageService.bcStorage.tipoVerificacion;
    console.log('mostramos tipoVerificacion==' + this.tipoVerificacion);

    if (this.tipoVerificacion == 'NoClientePasaporte') {
      console.log('=> dialogProcesando ::: capturaIdentificacion');
      this.dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    } else if (this.tipoVerificacion == 'full') {
      console.log('=> dialogProcesando ::: cargandoDatos');
      this.dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatos);
    } else if (this.tipoVerificacion == 'verifica_motor' || this.tipoVerificacion == 'verifica_ine_facial'
      || this.tipoVerificacion == 'verificacion_Ine_simple') {
      console.log('=> dialogProcesando ::: capturarRostro');
      this.dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaRostro);
    } else if (this.tipoVerificacion == 'simple') {
      console.log('=> dialogProcesando ::: capturaHuellas');
      this.dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaHuellas);
    }
    this.storageService.bcStorage.procesandoAbierto = true;
  }


  public inicioObservables() {
//    this.bcService.failProcesador();
  }

  //Paso 4
  configuracionRespuesta() {
    console.log('secuencia 4 => ');
    this.bcService.getConfiguracionRespuesta();
    this.bcService.configuracionSistema$.subscribe({
      next: (respuesta: ConfiguracionRespuestaModel) => {
        if (respuesta) {
          var versionSistema = '';
          if (respuesta.VersionSistema != null && respuesta.VersionSistema != '') {
            versionSistema = respuesta.VersionSistema;
          }
          this.storageService.bcStorage.OmitirVigenciaIne = false;
          if (respuesta.OmitirVigenciaIne != null && respuesta.OmitirVigenciaIne.valueOf()) {
            this.storageService.bcStorage.OmitirVigenciaIne = respuesta.OmitirVigenciaIne;
            this.storageService.bcStorage.EstadosVigenciaIne = respuesta.EstadosVigenciaIne;
            this.storageService.bcStorage.FechaVigenciaProrroga = respuesta.FechaVigenciaProrroga;
          }
          //Si el BWS no es capaz de entregar la versión del sistema o si la entrega y esta es diferente a la declarada en el front, redirecciona.
          if (versionSistema == '' || versionSistema != this.storageService.bcStorage.versionSistema) {
            this.redireccionar();
          } else {
            if (this.tipoVerificacion == 'NoClientePasaporte' || this.tipoVerificacion == 'verifica_motor'
              || this.tipoVerificacion == 'verifica_ine_facial'
              || this.tipoVerificacion == 'verificacion_Ine_simple') {
              console.log('Paso a respuestaLicsuccess:::::::::: paso 3');
              this.respuestaLicsuccess()
            } else {
              this.respuestaConfiguracionRespuesta();
              console.log('regreso de respuestaConfiguracionRespuesta')
              this.vueltaVerificarLicencia();

            }
          }
        }
      }
    })
  } // Obtenemos el archivo de configuracion 1.3.0

  public validaLector() {
    console.log('metodo valida lector...')
    this.bcService.getlicsuccess();
    this.bcService.licsuccess$.subscribe(response => {
      if (response == "") {
        console.log('validarLector va a respuestaLicusses')
        this.respuestaLicsuccess();
      }
    });


  }

  public respuestaLicsuccess() {
    this.contadorBug++;
    if (this.isnotwhitelist) {
      console.log('contadorBug: ' + this.contadorBug);
      let testtoken = this.getParameterByName('testtoken');
      if (this.storageService.bcStorage?.token) {
        if (this.storageService.bcStorage.token && this.storageService.bcStorage.token != ""
          && this.storageService.bcStorage.token != null) {
          console.log('busqueda de tipo token ::::::paso 4');
          this.buscarTipoToken();
          this.successToken();
        } else {
          this.cerrarModal();
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = 'ETO06';
          this.error('ETO06');
          this.getFinalDate();
        }
      } else {
        if (testtoken === 'false') {
          this.buscarTipoToken();
          this.successToken();
        } else {
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = 'ETO06';
          this.getFinalDate();
        }
      }
    }
  }

  public setRedirectUrl(resultUrl: string) {
    if (this.storageService.bcStorage.esEjecutivo) {
      //biochkHub.server.noEliminarDatos();
    } //Detectamos si fue llamada la preverificación desde un enrolamiento redireccionado
    this.cerrarModal(); //Se debe cerrar el modal
    this.onStopSignalR(); //Se debe cerrar la comunición

    var urlParams = this.storageService.bcStorage.esEjecutivo ? "?isPreVerif=true" : "";

    setTimeout(function () {
      var hashSymbol = true;
      var targetUrl = resultUrl + (hashSymbol == true ? "/#!/" : "/") + urlParams;
      window.location.replace(targetUrl);
    }, 3000);
  }           //Redirecciona a otra version

  public cerrarModal() {
    this.dialogRef?.close(); //Se debe cerrar el modal
    this.dialogGen?.close();
  }

  onStopSignalR() {
    this.bcService.onStopSignalR();
  }

  public redireccionar() {
    this.bcService.redireccionar(["verify", true]);
    //biochkHub.server.getFrontUrl("verify", true);
  }


  //Invocacion de servicios
  eraseBiometrics() {
    this.bcService.setEraseBiometrics();
  }

  setConfigData() {
    this.bcService.setConfigData();
  }


  getUrlFront(urlRef: string) {
    console.log('secuencia 3 => ');
    this.bcService.getUrlFront([urlRef]);
    this.configuracionRespuesta();
  }

  getVersionInstalador() {
    console.log('secuencia 2 => ');
    const params = [
      this.storageService.bcStorage.versionBiocheck,
      this.storageService.bcStorage.versionSistema
    ];

    this.bcService.getVersionInstalador(params);
  }

  public listaFail: number = 0;

  public respuestaConfiguracionRespuesta() {
    console.log('secuencia 5 => ');
    this.bcService.getFingerLicences([this.guid]);

    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      this.failProcesador();
    });

//    this.vueltaVerificarLicencia();
  }

  vueltaVerificarLicencia() {

    this.bcService.getlicsuccess();
    this.bcService.licsuccess$.subscribe({
      next: (response: any) => {
        if (response == "") {
          this.validaLector();
        }
      }
    });


  }

  public respuestaConfiguracionRespuestaNCPasaporte() {
    this.bcService.getFingerLicences([this.guid]);
    this.bcService.getlicsuccess();
    this.bcService.licsuccess$.subscribe({
      next: (response: any) => {
        console.log('esto tienen de licsuccess:: ' + response);
        this.bcService.devicesConnectedNotEnrolled([this.guid]);
        this.devicesConnectedNotEnrolled();
      }
    });
//    this.validaLector();

  }

  fingerLicences() {
    if (this.bcService.getlicsuccess() != null) {
      this.bcService.licsuccess$.subscribe({
        next: (response: any) => {
          if (response) {
            console.log('ingreso a liccuse del response ...' + response)
            this.respuestaLicsuccess();
          }
        }
      });
    }
  }


  failProcesador() {
    console.log("failProcesador()")
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      console.log('response fail ')
      console.log(response)
      if (response && response != undefined) {
        console.log('llevamos el codigo de : ' + response.code);
        const code = parseInt(response.code);
        this.storageService.bcStorage.procesandoAbierto == true;
//        this.codeClientFail = code;
        let msg = '';
        if (code >= 100 && code < 200) {
          console.log('error 100 a 200 ');
          //modalerror
          this.cerrarModal();
          msg = `Error inesperado en la lectura de licencias. C\u00F3digo: ${code}`;
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              // this.errorLicencias() no existe metodo en el archivo
            }
            ;

            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", msg];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 320) {
          console.log('error 320 ');
          //modalerror2
          this.cerrarModal();
          this.storageService.bcStorage.codigoflujo = '320';
          msg = `Comprueba conexiones del esc\u00E1ner de huellas.\u000ASi el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.storageService.bcStorage.codigoflujo = '';
              this.renovarFail();
              //             this.bcService.getFingerLicences([this.guid]);
              this.consultaInit();
            } //else {
            // this.errorFunction('CA000', 'Proceso cancelado');
            //}
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", msg];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (this.storageService.bcStorage.tipoVerificacion == 'full') {
          this.fail_VerificacionFull(response);
        } else {
          this.respuestaLicsuccess();
        }
      } else {
        this.listaFail++;
        console.log('conteo de')
        console.log(this.listaFail)
      }
    });
  }

  renovarFail() {
    this.bcService.failProcesadorNew();
  }


  //Capa de Presentacion
  public statusCapturaExitoso() {
    let marcoHuella = $("#marcoHuella");
    marcoHuella.addClass('border-green');
    let statusCaptura = $("#statusCaptura")
    statusCaptura.text('Huellas Capturadas');
    statusCaptura.css('color', '#63BA68');
    statusCaptura.css('visibility', 'visible');
    if (this.storageService.bcStorage.esEjecutivo) {
      this.arrayIntentoHuellas.push("exitoso");
      var arrayAdicional = [];
      arrayAdicional.push({key: "IntentoDeHuellas", value: this.arrayIntentoHuellas});
      //     biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "verificacion_ejecutivo", "correcto_verificacion_" + instruccion($scope.dedoEnviar).replace(/\s/g, "_"), "captura_exitosa", arrayAdicional, true);
    }
  } //Cambios visuales cuando la captura de huella fue exitosa
  public statusCapturaNoExitosa() {
    let marcoHuella = $("#marcoHuella");
    marcoHuella.addClass('border-red');
    let statusCaptura = $("#statusCaptura")
    statusCaptura.text('Captura no exitosa');
    statusCaptura.css('color', '#ec0000');
    statusCaptura.css('visibility', 'visible');
    if (this.storageService.bcStorage.esEjecutivo) {
      this.arrayIntentoHuellas.push("fracaso");
      //biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "verificacion_ejecutivo", "error_verificacion_" + instruccion($scope.dedoEnviar).replace(/\s/g, "_"), "captura_no_exitosa");
    }
  }//Cambios visuales cuando la captura de huella no fue exitosa
  public statusCapturaInicial() {
    let marcoHuella = $("#marcoHuella");
    marcoHuella.addClass('border-gris');
    marcoHuella.removeClass('border-red');
    marcoHuella.removeClass('border-green');
    let statusCaptura = $("#statusCaptura")
    statusCaptura.text('Captura no exitosa');
    statusCaptura.css('color', '#000');
    statusCaptura.css('visibility', 'hidden');
    this.preview.addClass("std-opacidad-huella");
  }//Cambios visuales iniciales de huellas

  public abrirCapturarHuella() {
    this.dialogRef = this.dialogs.showDialogVerificacionSimple();
  } //Abrimos modal de captura


  public mostrarVista() {
    console.log('se invoco metodo de mostrarVista')
    if (this.storageService.bcStorage.esEjecutivo) {
//      biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "pageView"); TODO:Faltante de ver si se ocupa
    }
    this.dedoEnviar = this.dedoCapturar();
    if (this.dedoEnviar != 0) {
      this.statusCapturaInicial();
      console.log(this.dedoEnviar);
      this.storageService.bcStorage.dedoEnviar = this.dedoEnviar;
      this.storageService.bcStorage.dedoInicial = 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png';
      this.preview.attr('src', 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png');
      this.preview.addClass('std-opacidad-huella');
      this.dedoSelec.attr('src', 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png');
      this.tituloInstruccion = this.instruccion(this.dedoEnviar);
      this.storageService.bcStorage.tituloInstruccion = this.tituloInstruccion;
      if (this.storageService.bcStorage.esEjecutivo) {
        //Le agregamos a la instrucción para indicar que es el dedo del ejecutivo en preverificación
        this.tituloInstruccion += " del ejecutivo";
      }
      // MXSLBIOM-2750 Se ocultan los botones cuando es ejecutivo
      this.verVerificar = !this.storageService.bcStorage.esEjecutivo;
      this.verCancelar = !this.storageService.bcStorage.esEjecutivo;
      this.abrirCapturarHuella();
      if (this.storageService.bcStorage.esEjecutivo) {
        // MXSLBIOM-2750 Si es ejecutivo, arranca de inmediato el proceso de captura de huellas
        this.verificar();
      }
    } else {
//      biocheck.errorModal('El cliente no cuenta con dedos para verificar', "Salir" + ":ErrorCode:ClienteNoHuellas", '');
    }
//    $scope.$applyAsync();   TODO: saber si se utiliza esta parte
  }

  public buscarTipoToken() {
    var datosCanal = null;
    let tipoToken = this.storageService.bcStorage.tipoToken;
    let tokenString = this.storageService.bcStorage.token;

    if (tipoToken == 'muro') {
      console.log('==>Verificacion de token Muro [' + tokenString + ']');
      this.bcService.invokeVerifyToken([tokenString]);
    } else if (tipoToken == 'tot') {
      console.log('==>Verificacion de token Transversal [' + tokenString + ']');
      this.bcService.invokeVerifyTokenTransversal([tokenString]);
    } else {
      console.log('==>Verificacion de token [' + [tokenString] + ']');
      this.bcService.invokeVerifyToken([tokenString]);
    }
  }

  successToken() {
    console.log('Ingreso a metodo successToken')
    this.bcService.getSuccessToken();
    this.bcService.successToken$.subscribe(response => {
      if (response) {
        console.log('successToken -> ', response)
        const code = response.CodigoEstatus;
        let msj = '';
        switch (code) {
          case 1:
            console.log('antes de direccion de flujo :::::paso 5 ')
            this.direccionFlujo();
            break;
          case 2:
            this.storageService.bcStorage.codigoflujo = response.CodigoError;
            msj = this.bcService.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones);
            let dialogRef = this.dialogs.showDialogErrorMensaje(msj, 'Salir', response.CodigoError);
            dialogRef.afterClosed().subscribe(response => {
              this.responseDialogErrorMsg(response, msj);
            });
            break;
          case 3:
          case 4:
            this.storageService.bcStorage.codigoflujo = response.CodigoError;
            this.dialogRef = this.dialogs.showDialogErrorMensaje(response.Mensaje, 'Salir', response.CodigoError);
            this.dialogRef.afterClosed().subscribe(response => {
              this.responseDialogErrorMsg(response, response.Mensaje);
            });
            break
          default:
            this.storageService.bcStorage.codigoflujo = response.CodigoError;
            msj = 'Ocurri\u00F3 un error en la validaci\u00F3n de token.'
            this.dialogRef = this.dialogs.showDialogErrorMensaje(response.Mensaje, 'Salir', response.CodigoError);
            this.dialogRef.afterClosed().subscribe(response => {
              this.responseDialogErrorMsg(response, msj);
            });
            break;
        }
      }
    });
  }


  direccionFlujo() {
    console.log('******** tipo de verificacion: ' + this.tipoVerificacion)
    if (this.tipoVerificacion == 'NoClientePasaporte'
      || this.tipoVerificacion == 'verifica_motor'
      || this.tipoVerificacion == 'verifica_ine_facial'
      || this.tipoVerificacion == 'verificacion_Ine_simple') {
      console.log('ingreso a direccion de flujo y va para ejecutaBat::::::paso 5 ')
      this.ejecutaBat();
    } else {
      this.bcService.consult();
      this.respuestaConsultResponse();
    }
  }

public capturaDedos: boolean = true;
  respuestaConsultResponse() {
    this.bcService.getConsult();
    this.bcService.transactionID();
    this.bcService.consult$.subscribe(response => {
      if (response) {
        console.log('respuestaConsultaReponse: ' + response.code)
        switch (parseInt(response.code)) {
          case 0:
            console.log('ingreso a caso 0 consulta verificar...');
            if (response.result.enrollmentStatus != "" &&
              response.result.enrollmentStatus != null &&
              response.result.enrollmentStatus != "NO_ENROLADO" &&
              response.result.enrollmentStatus != "BAJA") {

              if (this.capturaDedos){
                this.capturaDedos = false;
                for (var x = 0; x < response.result.fingersAvailable.length; x++) {
                  //this.dedosAvtivos.push(response.result.fingersAvailable[x]);
                  this.dedosaux.push(response.result.fingersAvailable[x]);
                  this.storageService.bcStorage.dedosAvtivos = this.dedosaux;
                }

                this.dedos = response.result.fingersAvailable;//Guardamos los dedos enrolados
                console.log(this.dedos);
                console.log(this.storageService.bcStorage.dedosAvtivos);

              }

              this.consultasVerificar(response.code);//Consultas repetitivas
            } else {
              this.cerrarModal();
              this.storageService.bcStorage.codigoflujo = 'EEB03';
              let msj = 'El cliente/empleado no está enrolado.';
              this.dialogRef = this.dialogs.showDialogErrorMensaje(msj, "Salir")
              this.dialogRef.afterClosed().subscribe(response => {
                this.responseDialogErrorMsg(response, msj);
              });
            }
            break;
          case 400:
            this.cerrarModal();
            var obj = JSON.parse(response.message);
            var objError = obj.errores || obj.errors;
            if (objError.length > 0) {
              this.storageService.bcStorage.mensajeflujo = objError[0].message;
              this.storageService.bcStorage.mensajeinternoflujo = objError[0].description;
              this.error(objError[0].code);
            }
            this.error('ECC01');
            break;
          case 404:
            this.cerrarModal();
            this.error('ECC01');
            break;
          default:
            this.cerrarModal();
            this.error('ECC00');
            break;
        }
      }
    });
  }


  public consultasVerificar(codigo: any) {
    switch (codigo) {
      case "time_out_huella":
        //biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "error", "time_out_huella", "repetir", ""); TODO: evento log al parecer
        break;
      case "no_identifica_huella":
        //      biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "error", "no_identifica_huella", "repetir", "");
        break;

    }

    if (this.storageService.bcStorage.tipoVerificacion == 'full') {
      this.flujoVerificacion();
    } else {
      this.bcService.fingerChancesVerify();
      this.fingerChances();
    }

  }

  fingerChances() {
    this.intentosCapturaHuella = 3;
    this.storageService.bcStorage.numeroDeIntentosHuella = this.intentosCapturaHuella;
    this.bcService.getfingerChances();
    this.bcService.fingerChances$.subscribe(response => {
      console.log('intentos otorgado: ' + response);
      if (response != null && response != "" && response != undefined) {
        this.intentosCapturaHuella = response;
        this.respuestaFingerChances(this.intentosCapturaHuella);
      } else {
        console.log('Else respuesta finger');
        this.respuestaFingerChances(3);
      }
    });
  }


  respuestaFingerChances(intentos: any) {
    console.log('Ingreso a respuestaFingerChance...' + intentos);
    this.cerrarModal();
    this.intentosCapturaHuella = intentos;
    if (intentos > 0) {
      this.iscapturing = true;
      this.flujoVerificacion();
    } else {
      this.storageService.bcStorage.codigoflujo = 'EOB00';
      let msj = '<div style="font - weight: normal; ">Indica al cliente que la captura <strong>ha </br>excedido el número de intentos</strong> que</br> no es posible concluir el proceso de </br>verificación y tendrá que hacerlo en otra visita a </br>sucursal. Agradece su tiempo.</div>';
      this.dialogRef = this.dialogs.showDialogErrorMensaje(msj, 'Salir', 'EOB00', false);
      this.dialogRef.afterClosed().subscribe(response => {
        this.responseDialogErrorMsg(response, msj);
      });
    }
    //$scope.$applyAsync();
  }


  flujoVerificacion() {
    console.log('ingreso a flujo de verificacion..')
    if (this.storageService.bcStorage.tipoVerificacion == 'full') {
      console.log('vamos a full ')
      this.router.navigateByUrl('/full');
    } else if (this.tipoVerificacion == 'verifica_motor' || this.tipoVerificacion == 'verifica_simple') {
      this.router.navigateByUrl('/avisoDePrivacidad');
    } else {
      console.log('se abre modal de simple')
      this.mostrarVista();
    }
  }


  //Funciones para dedos
  public valorMaximo(arrayDedos: any) {
    return Math.max.apply(null, arrayDedos);
  } //Nos da el valor maximo de un array

  public valorMinimo(arrayDedos: any) {
    return Math.max.apply(null, arrayDedos);
  }//Nos da el valor minimo de un array

  public asignarDedosManos() {
    console.log('asignar dedos ...')
    this.dedosManoDerechaPrincipales = [];
    this.dedosManoIzquierdaPrincipales = [];
    this.dedosManoDerechaOpcional = [];
    this.dedosManoIzquierdaOpcional = [];
    for (var i = 0; i < this.dedos.length; i++) {
      switch (this.dedos[i]) {
        case 1:
        case 2:
        case 3:
          this.dedosManoDerechaPrincipales.push(this.dedos[i]);
          break;
        case 4:
        case 5:
          this.dedosManoDerechaOpcional.push(this.dedos[i])
          break;
        default:
          break;
      }
    }//Mano derecha
    for (var i = 0; i < this.dedos.length; i++) {
      switch (this.dedos[i]) {
        case 6:
        case 7:
        case 8:
          this.dedosManoIzquierdaPrincipales.push(this.dedos[i]);
          break;
        case 9:
        case 10:
          this.dedosManoIzquierdaOpcional.push(this.dedos[i]);
          break;
        default:
          break;
      }
    }//Mano izquierda
  }//Guardamos los dedos disponibles en cada mano

  public aleatorio(min: any, max: any) {
    return Math.round(Math.random() * (max - min) + min);
  }

  public eliminarDedo(dedoEliminar: any) {
    if (this.dedos.length !== 1) {
      for (var i = 0; i < this.dedos.length; i++) {
        if (this.dedos[i] == dedoEliminar) {
          this.dedos.splice(i, 1);
        }
      }
    }
    this.storageService.bcStorage.dedosAvtivos = this.dedos;
  }//Eliminamos el dedo del array de dedos

  public dedoCapturar() {
    this.asignarDedosManos();
    let dedo;
    switch (this.intentosCapturaHuella) {
      case 2:
        switch (this.mano) {
          case 1:
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              dedo = this.dedosManoIzquierdaPrincipales[this.aleatorio(0, this.dedosManoIzquierdaPrincipales.length - 1)];
            } else {
              if (this.dedosManoIzquierdaOpcional.length != 0) {
                dedo = this.dedosManoIzquierdaOpcional[this.aleatorio(0, this.dedosManoIzquierdaOpcional.length - 1)];
              } else {
                if (this.dedosManoDerechaPrincipales.length != 0) {
                  dedo = this.dedosManoDerechaPrincipales[this.aleatorio(0, this.dedosManoDerechaPrincipales.length - 1)];
                } else {
                  if (this.dedosManoDerechaOpcional.length != 0) {
                    dedo = this.dedosManoDerechaOpcional[this.aleatorio(0, this.dedosManoDerechaOpcional.length - 1)];
                  } else {
                    dedo = 0;
                  }
                }
              }
            }
            break;
          case 2:
            if (this.dedosManoDerechaPrincipales.length != 0) {
              dedo = this.dedosManoDerechaPrincipales[this.aleatorio(0, this.dedosManoDerechaPrincipales.length - 1)];
            } else {
              if (this.dedosManoDerechaOpcional.length != 0) {
                dedo = this.dedosManoDerechaOpcional[this.aleatorio(0, this.dedosManoDerechaOpcional.length - 1)];
              } else {
                if (this.dedosManoIzquierdaPrincipales.length != 0) {
                  dedo = this.dedosManoIzquierdaPrincipales[this.aleatorio(0, this.dedosManoIzquierdaPrincipales.length - 1)];
                } else {
                  if (this.dedosManoIzquierdaOpcional.length != 0) {
                    dedo = this.dedosManoIzquierdaOpcional[this.aleatorio(0, this.dedosManoIzquierdaOpcional.length - 1)];
                  } else {
                    dedo = 0;
                  }
                }
              }
            }
            break;
          case 3:
            dedo = this.dedos[0];
            break;
          default:
            dedo = 0;//No tiene ni un dedo disponible para verificar
            break;
        }
        break;
      case 1:
      case 3:
      default:
        if (this.dedos.length == 1) {
          this.mano = 3; //Solo tiene una huella
        } else {
          if (this.dedosManoDerechaPrincipales.length != 0) {
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              this.mano = this.aleatorio(1, 2);//Asignamos la mano aleatoria
            } else {
              this.mano = 1;
            }
          } else {
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              this.mano = 2;
            } else {
              if (this.dedosManoDerechaOpcional.length != 0) {
                if (this.dedosManoIzquierdaOpcional.length != 0) {
                  this.mano = this.aleatorio(1, 2);//Asignamos la mano aleatoria
                } else {
                  this.mano = 1;
                }
              } else {
                if (this.dedosManoIzquierdaOpcional.length != 0) {
                  this.mano = 2;//Asignamos la mano aleatoria
                } else {
                  this.mano = 0;
                }
              }
            }
          } //Revisamos que mano tiene
        }
        switch (this.mano) {
          case 1:
            if (this.dedosManoDerechaPrincipales.length != 0) {
              dedo = this.dedosManoDerechaPrincipales[this.aleatorio(0, this.dedosManoDerechaPrincipales.length - 1)];
            } else {
              dedo = this.dedosManoDerechaOpcional[this.aleatorio(0, this.dedosManoDerechaOpcional.length - 1)];
            }
            break;
          case 2:
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              dedo = this.dedosManoIzquierdaPrincipales[this.aleatorio(0, this.dedosManoIzquierdaPrincipales.length - 1)];
            } else {
              dedo = this.dedosManoIzquierdaOpcional[this.aleatorio(0, this.dedosManoIzquierdaOpcional.length - 1)];
            }
            break;
          case 3:
            dedo = this.dedos[0];
            break;
          default:
            dedo = 0;//No tiene ni un dedo disponible para verificar
            break;
        }
        break;
    }
    return dedo;
  }//Devulve el dedo que debe capturar

  public instruccion(dedoEnviar: number) {
    var respuesta = '';
    switch (dedoEnviar) {
      case 1:
        respuesta = 'pulgar derecho';
        break;
      case 2:
        respuesta = 'índice derecho';
        break;
      case 3:
        respuesta = 'medio derecho';
        break;
      case 4:
        respuesta = 'anular derecho';
        break;
      case 5:
        respuesta = 'meñique derecho';
        break;
      case 6:
        respuesta = 'pulgar izquierdo';
        break;
      case 7:
        respuesta = 'índice izquierdo';
        break;
      case 8:
        respuesta = 'medio izquierdo';
        break;
      case 9:
        respuesta = 'anular izquierdo';
        break;
      case 10:
        respuesta = 'meñique izquierdo';
        break;
      default:
        respuesta = 'índice derecho';
        break;
    }
    return respuesta;
  }

//Tipo de flujo para redireccionar en caso de ser los diferentes flujos:


  //botones
  public verificar() {
//    biochkHub.server.addFingerVerify(this.guid, this.dedoEnviar); TODO:Verificar en que se usa
    this.eliminarDedo(this.dedoEnviar);
    this.verCancelar = false;
    this.verVerificar = false;
//    $scope.$applyAsync(); TODO: Verificar en que se usa
  };

  // $scope.cancelar = function () {
  //   biocheck.cancelar(function () {
  //     $('#modalSolicitaHuella').on('hidden.bs.modal', function (e) {
  //       error('CA000');
  //     });
  //     cerrarModal();
  //
  //   });
  // };
  cancelar() {
    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }


  getParameterByName(name: string) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null)
      return "";
    else
      return decodeURIComponent(results[1].replace(/\+/g, " "));
  }


  getVersionDespliegue() {
    this.bcService.getObtenerVersionDespliegue();
  }

  //:::::::: Verificacion Full utilidades:::::::::

  fail_VerificacionFull(response: any) {
    //$(".preview").attr("src", "data:image/png;base64," + "");
    //formatoCaptura.colorMarco = 'rojo';

    var code = response.code;
    var message = response.message;
    var btnlbl = '';
    setTimeout(() => {
      //$scope.cerrarModalCaptura();
      // this.cerrarModal();
      //$scope.cerrarModalReloj();
      if (parseInt(code) == 270) {
        var partsOfStr = message.split(',');

        //message = "No se pudo capturar dedo(s):</br> ";
        message = "No se pudo capturar dedo(s):\n ";
        for (var x = 0; x < partsOfStr.length; x++) {
          if (partsOfStr[x] != "" && partsOfStr[x] != null) {
            switch (parseInt(partsOfStr[x])) {
              case 1:
              case 6:
                message += "pulgar ";
                break;
              case 2:
              case 7:
                message += "índice ";
                break;
              case 3:
              case 8:
                message += "medio ";
                break;
              case 4:
              case 9:
                message += "anular ";
                break;
              case 5:
              case 10:
                message += "meñique ";
                break;
            }
            if (partsOfStr[x] <= 5)
              message += "derecho";
            else
              message += "izquierdo";
            if (partsOfStr.length > 1)
              //message += ",</br>";
              message += ",\n";
          }
        }
        btnlbl = 'Repetir';
//        abrirModalError(message, "Repetir", $scope.error);
      } else if (parseInt(code) == 310) {
        message = 'Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
        btnlbl = 'Recargar';
//        abrirModalErrorDispositivo("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>", "Recargar", $scope.errordevice, $scope.cancelarinfo);
      } else if (parseInt(code) == 320) {
        message = 'Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5'
        btnlbl = 'Recargar';
      } else if (parseInt(code) == 300) {
        message = 'Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
        btnlbl = 'Recargar';
      } else if (parseInt(code) == 200) {
        this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // imagen del flujo(sin imagen)
        message = 'El tiempo para realizar la captura se ha excedido, \n por favor repítela.';
        btnlbl = 'Recargar';
      } else if (parseInt(code) == 280) {
        message = 'Indica al cliente que la captura ha excedido el número de intentos que no es posible concluir el proceso de \n verificación y tendrá que hacerlo en otra visita a \n sucursal. Agradece su tiempo.';
        btnlbl = 'Salir';
      } else if (parseInt(code) >= 100 && parseInt(code) < 200) {
        message = "Error inesperado en la lectura de licencias. Código: " + code;
        btnlbl = "Salir";
//        abrirModalError("Error inesperado en la lectura de licencias. Código: " + code, "Salir", $scope.errorlicencias);
      } else if (parseInt(code) == 230) {
        this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // imagen del flujo(sin imagen)
        message = "Se encontraron huellas previamente capturadas."
        btnlbl = "Repetir";
      } else {
        this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // imagen del flujo(sin imagen)
        message = "Ocurrió un error inesperado en la captura de huellas.";
        btnlbl = "Repetir";
      }

      if (message !== '' && btnlbl !== '') {
        this.dialogGen = this.dialogs.showDialogErrorMensaje(message, btnlbl, code, false);
      }

    }, 2000);
  }


  //:::::::: Verificacion Verificacion escritorio Pasaporte utilidades:::::::::

  devicesConnectedNotEnrolled() {
    console.log('devicesConnectedNotEnrolled()::::::::ingreso');
    this.bcService.getDevicesSuccess();
    this.bcService.devicesSuccess$.subscribe({
      next: (response: any) => {
        console.log('esto trae final en ====: ' + response)
        console.log('ingresa a transaccion id ')
        this.startScanProcess();
      }
    });
  }

  cancelarPorValidacion() {
    this.dialogGen?.close();
    const msj = 'No se han enviado datos adicionales (nombre, apellidos y fecha de nacimiento) desde el origen, ' +
      'por lo tanto no se podrá comparar la información escaneada del documento.';
    this.dialogGen = this.dialogs.showDialogErrorMensajeDos(msj, 'Finalizar');
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.storageService.bcStorage.nombreCliente == '';
        this.errorFunction('CA000', '¡Verificación no exitosa!');
        //this.getFinalDate();
      }
    });
  }

  ejecutaBat() {
    this.bcService.ejecutaBat();
    this.bcService.ejecutaBat$.subscribe(response => {
      if (response) {
        console.log('paso el ejecuta bat ::::::va a verificar el escanerDocuemnto::: paso 6 ')
        this.verificarEscanerDocumentos();
      }
    });
  }

  verificarEscanerDocumentos() {
    this.controladorFunciones("VerificarEstatusEscanerDoc", {});
    this.respuestaProcesador();
  }

  controladorFunciones(id: string, parametrosEntrada: any) {
    const funcion = {
      Id: id,
      ParametrosEntrada: parametrosEntrada
    };
    this.bcService.procesador([funcion]);
    if (!this.procesadorInvoked) {
      console.log('id ==> ' + id)
      this.procesadorInvoked = true;
    }
  }

  respuestaProcesador() {
    this.bcService.respuestaProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      if (response) {
        console.log('envio procesador y respuetsa es :::::paso 7 ' + response.Id)
        const id = response.Id;
        switch (response.Id) {
          case 'VerificarEstatusEscanerDoc':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              console.log('resp::: ' + response.Respuesta);
              this.activarModoManualEscaner();
            }
            break;
          case 'VerificarEscanerConectadoOnline':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              this.activarModoManualEscaner();
            }
            break;
          case 'ActivarModoManualEscaner':
            console.log('ingreso a ctivador Modeo manual ')
            this.controlFlujoActivarModoManual();
            break;
          default:
            break;
        }
      } else {
        console.log('failprocesador en respuesta procesador :::---')
//        this.failProcesador();
      }
    });
  }

  controlFlujoActivarModoManual() {
    if (this.tipoVerificacion == 'verifica_motor'
      || this.tipoVerificacion == 'verifica_ine_facial'
      || this.tipoVerificacion == 'verificacion_Ine_simple') {
      this.bcService.checkIfCameraIsConected([]);
      this.bcService.isCameraConected();
      this.bcService.isCameraConected$.subscribe(response => {
        console.log(response + 'isCameraConect:::')
        if (response) {
          this.onDevicesSuccess();
        }
      });
    } else {
      this.respuestaConfiguracionRespuestaNCPasaporte();
    }
  }

  onDevicesSuccess() {
    this.bcService.transactionID();
    this.bcService.pE68Consultar();
    this.bcService.getpE68GuardarRespuesta();
    this.bcService.pE68GuardarRespuesta$.subscribe(response => {
      if (response) {
        console.log('ingreso a guardar p68::::')
        this.guardarRespuestaPe68(response);
      }
    })

  }

  guardarRespuestaPe68(response: any) {
    var code = response.CodigoEstatus;
    var errorcustom = false;
    var codigoEstatusRespuesta = "";

    if ((response.Datos != null && response.Datos != undefined) && (response.Datos.status != null && response.Datos.status != undefined)) {
      codigoEstatusRespuesta = response.Datos.status.statusCode;
    } else {
      codigoEstatusRespuesta = response.Mensaje
    }
    let msg = '';
    switch (code) {
      case 1:
        if (response.Datos.status.statusCode == 0 && response.Datos.partyRec.partyInfo.personPartyInfo != null) {
          var cData = response.Datos.partyRec.partyInfo.personPartyInfo;
          this.storageService.bcStorage.apicNombre = cData.personName.givenName || '';
          this.storageService.bcStorage.apicApellidoP = cData.personName.paternalName || '';
          this.storageService.bcStorage.apicApellidoM = cData.personName.maternalName || '';
          this.storageService.bcStorage.nombreCliente = this.storageService.bcStorage.apicNombre + " " + this.storageService.bcStorage.apicApellidoP + " " + this.storageService.bcStorage.apicApellidoM;
          this.storageService.bcStorage.tipoCliente = this.storageService.bcStorage.nombreCliente;
//          if (this.storageService.bcStorage.tipoFlujoVerificacion == 4) {//verificacion no cliente escritorio
          if (cData.birthDt) {
            if (cData.birthDt != null && cData.birthDt != "") {
              if (typeof cData.birthDt != undefined) {
                var btDate = cData.birthDt.split("-");
                this.storageService.bcStorage.apicDia = btDate[2];
                this.storageService.bcStorage.apicMes = btDate[1];
                this.storageService.bcStorage.apicAno = btDate[0];
              }
            }
          }
          var sexo = "";
          if (cData.gender.toUpperCase() == "MASCULINO")
            sexo = "H";
          else if (cData.gender.toUpperCase() == "MALE")
            sexo = "H";
          else
            sexo = "M";
          this.storageService.bcStorage.apicSexo = sexo;
          //}
          this.avisoDePrivacidad();
//          this.setComponentVerify();
        } else if (response.Datos.status.statusCode == 100 || response.Datos.status.statusCode == 100) {
          msg = "Ocurrió un error en la consulta del cliente.";
          this.modalErrorGlobal(msg, 'Salir');
        } else {
          /*Si el estatus de la respuesta que devuelve la API es fallido,muestra mensaje y termina el flujo.*/
          msg = this.biocheckError.codigoError("EPE6801");
          this.modalErrorGlobal(msg, 'Salir');
        }
        // if (winPros) {
        //   winPros.close();
        // }
        break;
      case 2:
        this.storageService.bcStorage.codigoflujo = response.CodigoError;
        var flagbuc = false;
        $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
          if (value.indexOf("customer does not exist") != -1)
            flagbuc = true;
        });
        if (flagbuc) {
          msg = "";
          $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
            msg += this.key;
          });
          this.modalErrorGlobal(msg, 'Salir');
        } else
          this.modalErrorGlobal(msg, 'Salir');
        break;
      case 3:
        this.storageService.bcStorage.codigoflujo = "EPE6802";
        msg = this.biocheckError.codigoError(this.storageService.bcStorage.codigoflujo);
        this.modalErrorGlobal(msg, 'Salir');
        break;
      case 4:
        this.storageService.bcStorage.codigoflujo = "EPE6802";
        msg = this.biocheckError.codigoError(this.storageService.bcStorage.codigoflujo);
        this.modalErrorGlobal(msg, 'Salir');
        break;
      default:
        this.storageService.bcStorage.codigoflujo = "EPE6802";
        msg = this.biocheckError.codigoError(this.storageService.bcStorage.codigoflujo);
        this.modalErrorGlobal(msg, 'Salir');
        break;
    }
  }


  activarModoManualEscaner() {
    this.controladorFunciones("ActivarModoManualEscaner", {});
  }

  public documento: string | undefined = '';

  startScanProcess() {
    this.bcService.transactionID();
    console.log('ingreso a redireccionar para pasaporte ')
    let path = '';
    this.documento = this.storageService.bcStorage.documento;
    console.log('esto es documento:::' + this.documento);
    if (this.documento && this.documento !== "") {
      if (this.documento.match(/pasaporte/i)) {
        this.router.navigateByUrl(`verificacionNoClientePasaporte`);
      }
    }
  }

  //#region  RETORNA ERROR
  modalErrorGlobal(msg: string, accion: string, codeError: number = 0) {
    if (accion == "Salir") {//salir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, accion);
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.getFinalDate();
        }
        ;
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    } else {//repetir
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.errorFunction(codeError.toString(), msg);
        } else {
          if (response != undefined) {
            this.cancelar();
          }
        }
        try {
          const params = ["warning", "PaaS [" + window.location.href + "]", msg];
          this.bcService.invokeEscribeLog(params);
        } catch (tryError) {
          // ignored
        }
      });
    }
  }

  avisoDePrivacidad() {
    this.router.navigateByUrl('avisoDePrivacidad');
  }


  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    console.log(data);
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    if (data.trasaction != '') {
      this.storageService.bcStorage.foliopros = data.trasaction;
    } else {
      this.storageService.bcStorage.foliopros = data.trasaction == null ? '-' : '-';
    }
    this.router.navigateByUrl('finalizar');
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  error(codigo: string) {
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.apicNombre = "";
    this.storageService.bcStorage.apicApellidoP = "";
    this.storageService.bcStorage.apicApellidoM = "";
    this.storageService.bcStorage.codigoflujo = codigo;
    this.getFinalDate();
  } // Caen los errores en verificacion

  responseDialogErrorMsg(response: boolean, message: string) {
    if (response) {
      if (this.storageService.bcStorage.codigoflujo != null) {
        this.error(this.storageService.bcStorage.codigoflujo)
      }
    }
    try {
      const params = ["warning", "PaaS [" + window.location.href + "]", message];
      this.bcService.invokeEscribeLog(params);
    } catch (tryError) {
      // ignored
    }
  }


}
