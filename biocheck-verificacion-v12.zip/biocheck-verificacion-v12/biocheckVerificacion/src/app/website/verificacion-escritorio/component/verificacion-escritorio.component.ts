import { Component, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { BiocheckService } from 'src/app/core/services/biocheck.service';
import { FinalDateModel } from "../../../core/models/final-date.model";
import { UtilDialogs } from 'src/app/common/util-dialogs';
import { BcstorageService } from "../../../core/services/bcstorage.service";
import { Router } from "@angular/router";
import { DataDialogModel } from "../../../core/models/msg-dialog.model";
import { FormsModule } from '@angular/forms';
import { DialogGeneralComponent } from 'src/app/shared/dialogs/dialog-general/dialog-general.component';
import * as $ from "jquery";
import { DialogHuellasComponent } from 'src/app/shared/dialogs/dialog-huellas/dialog-huellas.component';
//import { BiocheckPasosService } from 'src/app/core/services/biocheck-pasos';
import { DataEditableModel } from "../../../core/models/dataTable.model";
import { BiocheckUtils } from 'src/app/core/services/biocheck-utils.service';

@Component({
  selector: 'app-verificacion-escritorio',
  templateUrl: './verificacion-escritorio.component.html',
})
export class VerificacionEscritorioComponent implements OnInit {
  public typeScan!: string;
  public nombreCliente?: string;
  imgDosManos = 'assets/img/dos_manos.png';
  public mostrarCorreoElectronico: boolean = false;
  public email: string = '';
  public dominio!: string;
  public msjerror!: string;
  public cargaCompleta: boolean = true;
  public direccion: string = '';
  public respuestaInstruccion: any;
  public errorEscaner!: boolean;
  public errorGeneral!: boolean;
  public instruccionEscaneo: string = 'Escaneando documento.';
  public correos: any[] = [
    { "id": 0, "name": "@gmail.com" },
    { "id": 1, "name": "@yahoo.com" },
    { "id": 3, "name": "@outlook.com" },
    { "id": 4, "name": "@hotmail.com" },
    { "id": 5, "name": "Otro" }];

  img_logo = 'assets/img/logo.png';
  tituloInstruccion: string = '';
  versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
  versionInstalador = this.storageService.bcStorage.versionSistema;  //Version anterior que se encuentra en el MSI

  public verCancelar: boolean = true;//Muestra u oculta el boton cancelar
  public verVerificar: boolean = true;//Muestra u oculta el boton de verificar
  //  public instruccion: string = ''; //Instruccion que se mostrara en la cabecera y modal cambia a tituloInstruccion
  public intentosCapturaHuella: number = 3; //Intentos para capturar la huella
  public intentosVerificar: number = 3; //Intentos para verificar la huella


  public guid: string = ''; // Se envia al servicio
  public dedos: any[] = []; //Lista de dedos enrolados
  public dedosManoDerechaPrincipales: any[] = []; //Dedos disponibles para la mano derecha principales
  public dedosManoIzquierdaPrincipales: any[] = [];//Dedos disponibles para la mano izquierda principales
  public dedosManoDerechaOpcional: any[] = []; //Dedos disponibles para la mano derecha opcionales
  public dedosManoIzquierdaOpcional: any[] = [];//Dedos disponibles para la mano izquierda opcionales
  // bcstorage.esEjecutivo = getParameterByName('isPreVerif') == "true"; //Indica si se está realizando una preverificación
  public mano: number = 0; //1)mano derecha 2)Mano izquierda 0)Mano sin definir
  public dedoEnviar: number = 0; //Es el dedo que enviaremos a verificar
  public arrayIntentoHuellas: any[] = [];

  //Elementos del DOM
  //public versionInstalador: string = '';
  public statusCaptura: string = '';  //Captura exitosa  o no exitosa

  public marcoHuella = $('.marcoHuella');//Marco que cambia de color dependiendo la captura
  public procesando: string = 'Captura huellas';  //Modal de procesando
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public dedoSelec = $('#dedoSelec');//Imagen de la huella seleccionada

  public urlref: string | undefined;

  public dialogGen: MatDialogRef<any, any> | undefined;
  public dialogRef: MatDialogRef<DialogHuellasComponent, any> | undefined;
  public direccionCorreo: string | undefined;
  public idImg?: string;


  constructor(
    private storageService: BcstorageService,
    private bcService: BiocheckService,
    private dialogs: UtilDialogs,
    private router: Router,
    private Utils: BiocheckUtils,
    //private Pasos: BiocheckPasosService,
  ) {

  }

  ngOnInit(): void {
    this.mostrarCorreoElectronico = false;
    this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
    this.versionInstalador = this.storageService.bcStorage.versionSistema;
    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    this.iniciarVista();
  }

  iniciarVista() {
    this.Utils.totalPasos(4);
    this.Utils.cambiarPaso(1, "Aviso de privacidad");
    this.oDB6ConsultarCorreo();
  }

  // cambiarPaso(paso: number, nombre: string) {
  //   $('#paso' + paso).css('text-decoration', 'underline');
  //   $("#nombrePasoActual").text(nombre);
  //   for (var i = 1; i <= paso; i++) {
  //     $('#paso' + i).css('color', '#ec0000');
  //   }
  // }

  public cancelar() {
    this.Utils.cancelar();
    // this.dialogGen?.close();
    // this.dialogGen = this.dialogs.showDialogCancelar();
    // this.dialogGen.afterClosed().subscribe(response => {
    //   if (response) {
    //     this.errorFunction('CA000', 'Proceso cancelado');
    //   }
    // });
  }

  // public errorFunction(codigoError: string, mensajeLegible?: string) {
  //   this.storageService.bcStorage.codigoflujo = codigoError;
  //   if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
  //     this.storageService.bcStorage.mensajeflujo = mensajeLegible;
  //   }
  //   codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
  //   codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
  //   this.Utils.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
  //   this.Utils.getFinalDate();
  // }

  // getFinalDate() {
  //   this.bcService.getFinalDate();
  //   this.bcService.finalDate$.subscribe(response => {
  //     if (response) {
  //       this.onFinalDato(response);
  //     }
  //   });
  // }

  // sendLog(status: string, codigoError: string | number, msg: string | undefined) {
  //   const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
  //   let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
  //   this.bcService.invokeEscribeLog(paramsLog);
  // }

  // onFinalDato(data: FinalDateModel) {
  //   this.storageService.bcStorage.fechapros = data.fecha;
  //   this.storageService.bcStorage.horapros = data.hora;
  //   this.storageService.bcStorage.foliopros = data.trasaction;
  //   this.bcService.onStopSignalR();
  //   if (this.storageService.bcStorage.proceso) {
  //     this.router.navigateByUrl('/finalizar');
  //   } else {
  //     this.respuesta();
  //   }
  // }

  // respuesta() {
  //   let innerMessage = '';

  //   if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
  //     innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
  //   } else if (this.storageService.bcStorage.hash) {
  //     innerMessage = this.storageService.bcStorage.hash;
  //   }

  //   if (this.storageService.bcStorage.mensajeflujo) {
  //     const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
  //     const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
  //     this.storageService.bcStorage.mensajeflujo = cleanMessage;
  //   }

  //   const response = {
  //     message: this.storageService.bcStorage.mensajeflujo,
  //     innerMessage: innerMessage,
  //     code: this.storageService.bcStorage.codigoflujo,
  //     response: this.storageService.bcStorage.proceso
  //   };

  //   var responseStr = JSON.stringify(response);
  //   this.sendMessage('' + responseStr);
  // }

  // sendMessage(msg: string) {
  //   //postFinalizar(msg); no existe funcionalidad
  // }

  changeCheck(value: any) {
    //se ejecuta al activar o desactivar el switch del enviar email
    this.mostrarCorreoElectronico = !this.mostrarCorreoElectronico;
  };


  public iniciar() {
    this.email = $("#compania").val() as string;
    if (this.mostrarCorreoElectronico == true) {
      if (this.emailValido()) {
        this.msjerror = '';
        var correoElectronico = "";
        if (this.dominio === 'Otro') {
          correoElectronico = this.email;
        } else {
          if (this.email != null && this.email != undefined && this.email != '') {
            correoElectronico = this.email + this.dominio;
          } else {
            correoElectronico = '';
          }
        }
        // MXSLBIOM-1631: Enviar el aviso de privacidad al correo electronico del cliente en el flujo de no enrolados escritorio
        this.bcService.notificacionEmail([correoElectronico, 'AvisoDePrivacidad']);
        this.iniciaCapturaDeHuellas();
      } else {
        this.msjerror = 'Correo electrónico erróneo';
      }
    } else {
      this.iniciaCapturaDeHuellas();
    }
  };

  iniciaCapturaDeHuellas() {
    var TipoFlujo = this.storageService.bcStorage.tipoFlujoVerificacion;
    this.Utils.cambiarPaso(2, 'Capturar huellas');
    this.dialogCapturaHuella(1, "");
  }

  emailValido() {
    var correoElectronico = ''; //variable auxiliar
    var emailValido = true;
    if (this.mostrarCorreoElectronico) {
      if (this.email.length !== 0) {
        if (this.dominio === 'Otro') {
          correoElectronico = this.email;
        } else {
          correoElectronico = this.email.concat(this.dominio);
        } //acomodamos el correo electronico para poder trabajarlo
        emailValido = this.validacionEmail(correoElectronico);
      } else {
        correoElectronico = '';
        emailValido = false;
      }
    }
    return emailValido;
  }

  validacionEmail(email: string) {
    var estructuraValida = true;
    var regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/igm;
    if (email === '') {
      this.msjerror = '';
      estructuraValida = true;
      //$('#emailform').css('border', 'solid 1px rgb(27, 179, 188)');
      $('#emailform').css('border', 'solid 1px #ced4da');
    } else {
      if (!email.match(regex)) {
        this.msjerror = 'El correo electr\u00F3nico es inv\u00E1lido';
        setTimeout(function () {
          $('#email__campoTexto').css('border', '1px solid #ec0000');
          $('#msj-error').css('color', '#ec0000');
        }, 100);
        estructuraValida = false;
      } else {
        this.msjerror = '';
        estructuraValida = true;
        //$('#emailform').css('border', 'solid 1px rgb(27, 179, 188)');
        $('#email__campoTexto').css('border', 'solid 1px #ced4da');
      }
    }
    return estructuraValida;
  }

  emailChange() {
    var correo = $('#correo').val();
    this.dominio = correo as string;
    $("#correo").blur();
    //$("#correo").css('background', 'red')
  };


  dialogCapturaHuella(dedo: any, img: any) {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCaupturaHuellas(dedo, img);
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {

        }
      }
    );
  }

  //#region  CONSULTA OBD6
  //public email: string= "";
  oDB6ConsultarCorreo() {
    this.bcService.oDB6Consultar();
    this.bcService.getoDB6GuardarRespuesta();
    this.bcService.oDB6GuardarRespuesta$.subscribe(response => {
      if (response) {
        if (response.CodigoEstatus == null || response.Datos == null ||
          response.Datos.status == null || response.Datos.status.statusCode == null ||
          typeof response.CodigoEstatus == 'undefined' || typeof response.Datos == 'undefined' ||
          typeof response.Datos.status == 'undefined' || typeof response.Datos.status.statusCode == 'undefined') {
          //Significa que ocurrio un problema en el WSB y no logramos consultar el correo
          this.email = '';
          this.dominio = "@gmail.com";
        }

        if (response.CodigoEstatus === "OK" && response.Datos.status.statusCode == 0) { //catEstatusRespuesta.Exito && response.Datos.status.statusCode == 0) {//Significa que si logramos obtener el correo guardado en 390
          var emailAddress = null;
          try {
            emailAddress = response.Datos.partyInqObjRec[0].contact.email.emailAddr;
          } catch (error) {
            emailAddress = null;
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", error];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          }
          if (emailAddress != undefined && emailAddress != null && emailAddress != "undefined" && emailAddress != "") {
            this.mostrarEmail(emailAddress);
          } else {
            this.email = '';
            this.dominio = "@gmail.com";
          }
        } else {
          //Significa que ocurrio un problema en el WSB y no logramos consultar el correo
          this.email = '';
          this.dominio = "@gmail.com";
        }
      }
    });
  }

  mostrarEmail(email: string) {
    if (email) {
      var correoElectronico = email.split('@', 2);
      this.email = correoElectronico[0];
      // Se convierte a minusculas para hacer la comparacion, de lo contrario, si el correo viene en mayusculas, se pondra siempre Otro
      this.dominio = '@' + correoElectronico[1].toLowerCase();
      if (this.dominio !== '@gmail.com' && this.dominio !== '@yahoo.com' && this.dominio !== '@outlook.com' && this.dominio !== '@hotmail.com' && this.dominio !== '@yahoo.com.mx') {
        this.dominio = 'Otro';
        this.email = email;
      }
    } else {
      this.email = '';
      this.dominio = "@gmail.com";
    }
  }

  //  EstatusRespuesta() {
  // 	this.Exito = 1;
  // 	this.ExcepcionSumarizada = 2;
  // 	this.ExcepcionGenerica = 3;
  // }

  // public catEstatusRespuesta = new EstatusRespuesta();

  // RespuestaHub() {
  // 	this.CodigoEstatus = catEstatusRespuesta.Exito;
  // 	this.Titulo='';
  // 	this.Mensaje='';
  // 	this.ExcepcionSumarizada = new ExcepcionSumarizada();
  // 	this.ExcepcionGenerica = '';
  // 	//Esta propiedad es para almacenar las respuestas devueltas en cada petici�n. para cada funcionalidad esta va a ser distinta
  // 	this.Datos = new Object();
  // }
  //#endregion

}
