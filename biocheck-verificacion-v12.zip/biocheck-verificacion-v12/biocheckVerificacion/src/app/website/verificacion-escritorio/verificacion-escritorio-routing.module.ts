import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VerificacionEscritorioComponent } from "../verificacion-escritorio/component/verificacion-escritorio.component";

const routes: Routes = [
  { path: '', component: VerificacionEscritorioComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VerificacionEscritorioRoutingModule { }
