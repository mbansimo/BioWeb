import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'src/app/material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';

import { VerificacionEscritorioRoutingModule } from './verificacion-escritorio-routing.module';
import { VerificacionEscritorioComponent } from '../verificacion-escritorio/component/verificacion-escritorio.component';
import { TooltipModule } from "../tooltip/tooltip.module";
//import { CustomTooltipDirective } from "../../directives/custom-tooltip.directive";
@NgModule({
  declarations: [
    VerificacionEscritorioComponent,
    //CustomTooltipDirective
  ],
  imports: [
    CommonModule,
    VerificacionEscritorioRoutingModule,
    TooltipModule
  ],

  bootstrap: [VerificacionEscritorioComponent]
})
export class VerificacionEscritorioModule { }
