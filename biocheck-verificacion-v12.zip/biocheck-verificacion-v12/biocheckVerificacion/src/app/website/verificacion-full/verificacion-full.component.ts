import {Component, OnInit} from '@angular/core';
import {BiocheckService} from "../../core/services/biocheck.service";
import {PostParentService} from "../../core/services/post-parent.service";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {BiocheckErrorService} from "../../core/services/biocheck.error.service";
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";
import {UtilDialogs} from "../../common/util-dialogs";
import {Router} from "@angular/router";
import {MatDialogRef} from "@angular/material/dialog";
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import {FinalDateModel} from "../../core/models/final-date.model";
import {FormatoCapturaModel, intentosHuellaCliente} from "../../core/models/formatoCaptura.model";
import * as $ from "jquery";
import {BehaviorSubject} from "rxjs";

@Component({
  selector: 'app-verificacion-full',
  templateUrl: './verificacion-full.component.html',
  styleUrls: ['./verificacion-full.component.scss']
})
export class VerificacionFullComponent implements OnInit {

  public intentosRestantes = 3; //formatoCaptura.intentos restantes
  public boton = 'cacnelar';    //modalErrorDispositivo.boton
  public versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
  public versionInstalador = this.storageService.bcStorage.versionSistema;  //Version anterior que se encuentra en el MSI
  public intentosHuellaCliente: number = 0; //Intentos para capturar la huella
  public instruccionText: string = '';
  public combinaciones: string = '';
  public instruccionTitulo = $('#instruccion');
  public combinacion = $('#imgHuellaModal');
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public formatoCaptura!: FormatoCapturaModel;
  public EsEscanerUnidactilar: boolean = false;
  public controlPasos: boolean = true;


  //Variables del Flujo
  public pulgares = '0';
  public manoDerecha: any[] = [];
  public manoIzquierda: any[] = [];
  public pulgaresambas: any[] = [];
  public dedosAvtivos: any[] = [];
  public dedosaux: any[] = [this.storageService.bcStorage.dedosaux];
  public manoD = '0';
  public manoI = '0';
  public dedoEnviar = 0;
//  public instruccion = [];
  public guid = '';
  public controlFlujo: boolean = true;

  //imagenes
  public dosManos = 'assets/img/dos_manos.png'
  public signoMas = 'assets/img/signo_mas.png';
  public caraCheck = 'assets/img/cara_check.svg';
  public reloj = 'assets/img/reloj.gif';

  public dialogRef: MatDialogRef<any, any> | undefined;
  public dialogGen: MatDialogRef<any, any> | undefined;


  constructor(
    private bcService: BiocheckService,
    private postParentService: PostParentService,
    private storageService: BcstorageService,
    private Pasos: BiocheckPasosService,
    private dialogs: UtilDialogs,
    private biocheckError: BiocheckErrorService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {

    this.datosExternos();
//    this.controlDePasos();
    this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
    this.versionInstalador = this.storageService.bcStorage.versionSistema;
    this.dedosCapturar();
  }

  datosExternos() {
    var estatus = this.storageService.bcStorage.terminoFlujoRostro;
    console.log(estatus);
    if (estatus == 'Ok') {
      this.controlPasos = true;
      this.terminoFlujoRostro = true;
    } else {
      this.terminoFlujoRostro = false;
    }

  }


  controlDePasos() {
    if (this.controlPasos) {
      var lista = this.Pasos.totalPasos(2);
      $('#listaPasos').append(lista);
      this.cambiarPaso(1, "Captura huellas");//revisar
      this.controlPasos = false;
    } else {
      console.log('ya se cargaron los pasos::::')
    }

  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');

    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  public flujoDedosCapturar: boolean = true;

  dedosCapturar() {
    console.log('Cargamos dedosActivos en inicio.');

    if (this.flujoDedosCapturar) {
      this.flujoDedosCapturar = false;
      // @ts-ignore
      for (var x = 0; x < this.storageService.bcStorage.dedosAvtivos.length; x++) {
        this.dedosAvtivos.push(this.storageService.bcStorage.dedosAvtivos?.[x])
      }
    }
  }


  startcapture() {
    this.bcService.getfingerChances();
    this.bcService.fingerChances();
    this.bcService.fingerChancesRespuesta$.subscribe({
      next: (response) => {
        if (response) {
          this.fingerChances(response.intentos, response.EsEscanerUnidactilar);
        }
      }
    });
  }


  public contfingerChances: number = 0;
  public flagFlujo: boolean = true;

  fingerChances(intentos: number, EsEscanerUnidactilar: boolean) {

    if (this.intentosRestantes < 3) {
      console.log('numero de intento:' + this.intentosRestantes)
      this.storageService.bcStorage.intentosRestantes = this.intentosRestantes.toString();
    } else {
      this.intentosRestantes = intentos;
      this.storageService.bcStorage.intentosRestantes = intentos.toString();
    }
    this.EsEscanerUnidactilar = EsEscanerUnidactilar;
    this.storageService.bcStorage.EsEscanerUnidactilar = this.EsEscanerUnidactilar;

//    $scope.$applyAsync();
    var flag = this.flagFlujo;
    var manoD = 0;
    this.manoI = '0'; //se declaran arriba
    this.manoD = '0';
    this.pulgares = '0';
    this.manoDerecha = [];
    this.manoIzquierda = [];
    this.pulgaresambas = [];
    this.banderaHuella = false;
    this.bcService.borradoShowPreview();


    if (EsEscanerUnidactilar) {//region para unidactilar
      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 2 ||
          this.dedosAvtivos[i] === 3 ||
          this.dedosAvtivos[i] === 4 ||
          this.dedosAvtivos[i] === 5) {
          this.manoDerecha.push(this.dedosAvtivos[i]);
          break;
        }
      }
      for (var i = 0; i <= this.manoDerecha.length - 1; i++) {
        this.manoD = this.manoDerecha.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 7 ||
          this.dedosAvtivos[i] === 8 ||
          this.dedosAvtivos[i] === 9 ||
          this.dedosAvtivos[i] === 10) {
          this.manoIzquierda.push(this.dedosAvtivos[i]);
          break;
        }

      }
      for (var i = 0; i <= this.manoIzquierda.length - 1; i++) {
        this.manoI = this.manoIzquierda.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 1 ||
          this.dedosAvtivos[i] === 6) {
          this.pulgaresambas.push(this.dedosAvtivos[i]);
          break;
        }
      }
      for (var i = 0; i <= this.pulgaresambas.length - 1; i++) {
        this.pulgares = this.pulgaresambas.join('');
      }
    } else {//region para decadactilar
      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 2 ||
          this.dedosAvtivos[i] === 3 ||
          this.dedosAvtivos[i] === 4 ||
          this.dedosAvtivos[i] === 5) {
          this.manoDerecha.push(this.dedosAvtivos[i]);
        }
      }

      for (var i = 0; i <= this.manoDerecha.length - 1; i++) {
        this.manoD = this.manoDerecha.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 7 ||
          this.dedosAvtivos[i] === 8 ||
          this.dedosAvtivos[i] === 9 ||
          this.dedosAvtivos[i] === 10) {
          this.manoIzquierda.push(this.dedosAvtivos[i]);
        }
      }

      for (var i = 0; i <= this.manoIzquierda.length - 1; i++) {
        this.manoI = this.manoIzquierda.join('');
      }

      for (var i = 0; i <= this.dedosAvtivos.length - 1; i++) {
        if (this.dedosAvtivos[i] === 1 ||
          this.dedosAvtivos[i] === 6) {
          this.pulgaresambas.push(this.dedosAvtivos[i]);
        }
      }

      for (var i = 0; i <= this.pulgaresambas.length - 1; i++) {
        this.pulgares = this.pulgaresambas.join('');
      }
    }
    console.log('variables DedoEnviar: ' + flag + ' mano_D: ' + this.manoD + ' manoI: '
      + this.manoI + ' pulgares: ' + this.pulgares)
    this.DedoEnviar(flag);
  }

  DedoEnviar(flag: boolean) {
    switch (this.manoD) {
      case '2345':
        this.dedoEnviar = 13;
        this.instruccion('índice, medio, anular y meñique derechos', '7');
        //biochkHub.server.addFinger(guid, $scope.dedoEnviar);
        break;
      case '234':
        this.dedoEnviar = 47;
        this.instruccion('índice, medio y anular derechos', '5');
        //biochkHub.server.addFinger(guid, $scope.dedoEnviar);
        break;
      case '345':
        this.dedoEnviar = 48;
        this.instruccion('medio, anular y meñique derechos', '11');
        //biochkHub.server.addFinger(guid, );
        break;
      case '23':
      case '235':
        this.instruccion('índice y medio derechos', '3');
        this.dedoEnviar = 40;
        //biochkHub.server.addFinger(guid, $scope.dedoEnviar);
        break;
      case '2':
      case '245':
      case '24':
      case '25':
        this.dedoEnviar = 2;
        this.instruccion('índice derecho', '2');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '3':
      case '34':
      case '35':
        this.dedoEnviar = 3;
        this.instruccion('medio derecho', '9');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '4':
      case '45':
        this.dedoEnviar = 4;
        this.instruccion('anular derecho', '1');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '5':
        this.dedoEnviar = 5;
        this.instruccion('meñique derecho', '13');
        //biochkHub.server.addFinger(guid,$scope.dedoEnviar );
        break;
      case '0':
        switch (this.manoI) {
          case '78910':
            this.dedoEnviar = 14;
            this.instruccion('índice, medio, anular y meñique izquierdos', '8');
            //FingerNeuro = 14;
            break;
          case '789':
            this.dedoEnviar = 49;
            this.instruccion('índice, medio y anular izquierdos', '6');
            //FingerNeuro = 49;
            break;
          case '8910':
            this.dedoEnviar = 50;
            this.instruccion('medio, anular y meñique izquierdos', '12');
            //FingerNeuro = 50;
            break;
          case '78':
          case '7810':
            this.dedoEnviar = 43;
            this.instruccion('índice y medio izquierdos', '4');
            //FingerNeuro = 43;
            break;
          case '7':
          case '7910':
          case '79':
          case '710':
            this.dedoEnviar = 7;
            this.instruccion('índice izquierdo', '18');
            //FingerNeuro = 7;
            break;
          case '8':
          case '89':
          case '810':
            this.dedoEnviar = 8;
            this.instruccion('medio izquierdo', '10');
            //FingerNeuro = 8;
            break;
          case '9':
          case '910':
            this.dedoEnviar = 9;
            this.instruccion('anular izquierdo', '19');
            //FingerNeuro = 9;
            break;
          case '10':
            this.dedoEnviar = 10;
            this.instruccion('meñique izquierdo', '14');
            //FingerNeuro = 10;
            break;
          case '0':
            switch (this.pulgares) {
              case '1':
                this.dedoEnviar = 1;
                this.instruccion('pulgar derecho', '16');
                break;
              case '16':
                this.instruccion('pulgar derecho e izquierdo', '17');
                this.dedoEnviar = 15;
                break;
              case '6':
                this.instruccion('pulgar izquierdo', '15');
                this.dedoEnviar = 6;
                break;
              case '0':
                flag = false;

                this.cierreModal();
                if (this.terminoFlujoRostro) {
                  this.pruebaVidaExitosa();
                } else {
                  this.evaluateSuccess();
                }

                break;
              default:
                break;

            }
            break;
          default:
            break;

        }
        break;
      default:
        break;
    }

    if (this.dedoEnviar != 0 && flag) {
      this.dedosSolicitados = this.dedoEnviar;
      this.flagFlujo = false;
      //INICIA CAPTURA DE HUELLAS
      console.log('dedo Enviar ' + this.dedoEnviar + ':::::::');
      console.log('control del flujo ' + this.controlFlujo);
      if (this.controlFlujo) {
        this.controlFlujo = false;
        this.bcService.addFinger([this.guid, this.dedoEnviar]);
        this.bcService.getshowPreview()
        this.bcService.showPreviewRespuesta$.subscribe({
          next: (response: any) => {
            if (response) {
              $("#preview").css("opacity", "1");
              $("#preview").attr('src', 'data:image/png;base64,' + response);
//          this.preview.css("opacity", "1");
//          this.preview.attr('src', 'image/png;base64,' + response);
//          this.preview.data('src', 'data:image/png;base64,' + response)
              //var img = document.getElementById("preview") as HTMLImageElement;
              //img.src = "data:image/png;base64," + response;

              response = "";
//          segunda.unsubscribe;

              this.dataFinger();
            } else {
              this.failProcesador();
            }
          }
        });
      }
    }
  }

  public dedosSolicitados: number = 0;
  public segunda: any;

  addFinger() {
    this.bcService.getshowPreview()
    this.bcService.showPreviewRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          $("#preview").css("opacity", "1");
          $("#preview").attr('src', 'data:image/png;base64,' + response);
//          this.preview.css("opacity", "1");
//          this.preview.attr('src', 'image/png;base64,' + response);
//          this.preview.data('src', 'data:image/png;base64,' + response)
          //var img = document.getElementById("preview") as HTMLImageElement;
          //img.src = "data:image/png;base64," + response;

          response = "";
//          segunda.unsubscribe;

          this.dataFinger();
        } else {
          this.failProcesador();
        }
      }
    });
  }

  public statusCapturaInicial() {
    $('#statusCaptura').css('visibility', 'hidden');
    let marcoHuella = $("#marcoHuella");
    marcoHuella.addClass('border-gris');
    marcoHuella.removeClass('border-red');
    marcoHuella.removeClass('border-green');
    let statusCaptura = $("#statusCaptura")
    statusCaptura.text('Captura no exitosa');
    statusCaptura.css('color', '#000');
    statusCaptura.css('visibility', 'hidden');
    this.preview.addClass("std-opacidad-huella");
  }//Cambios visuales iniciales de huellas

  public banderaHuella: boolean = false;
  public banderaAddFinger: boolean= true;
  dataFinger() {
    this.controlFlujo = true;

    this.bcService.getDataFinger();
    this.bcService.dataFingerResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          this.actualizaDialog = true;
          setTimeout(() => {
          this.statusCapturaExitoso();
          }, 1000);

          console.log('aqui vamos _________')
          setTimeout(() => {
          if (this.bcService.dataFingerResponseObject.value != '') {
            this.flagFlujo = true;
            for (var x = 0; x < response.length; x++) {
              this.banderaHuella = true;
              var index = this.dedosAvtivos.indexOf(response[x]);
              if (index > -1) {
                this.dedosAvtivos.splice(index, 1);
              }
            }
            this.fingerChances(this.intentosRestantes, this.EsEscanerUnidactilar);
          }
          }, 2000);
        }
      }
    });
  }

  public statusCapturaExitoso() {
    $('#colorMarco').css('visibility', 'visible');
    //this.estatusCaptura = "Huellas Capturadas";
    $('.marcoHuella').css('border-color', '#63BA68');
    $('#marcoHuella').addClass('border-green');
  } //Cambios visuales cuando la captura de huella fue exitosa

  prueba() {
    console.log('Timeout success');
  }

  controlDeFlujo() {
    if (this.dedosAvtivos[0] == 1 && this.dedosAvtivos[1] == 6 && this.dedoEnviar == 15) {
      this.dedosAvtivos = [];
    }
  }

  public actualizaDialog: boolean = true;

  instruccion(inst: string, dedo: string) {
    this.instruccionText = inst;  //'#instruccion'
    this.combinaciones = 'assets/img/combinaciones/' + dedo + '.png'; //'#imgHuellaModal'
    this.preview.addClass("std-opacidad-huella");
    this.preview.attr('src', 'img/combinaciones/' + dedo + '.png');
    this.cierreModal();
    if (this.dedoEnviar != this.dedosSolicitados) {
      this.actualizaDialog = true;
      this.banderaAddFinger = true;
    }
    console.log('instruccion ' + this.actualizaDialog)


    if (this.actualizaDialog) {
      console.log('creando dialog de solicitud de huella ....');
      this.actualizaDialog = false;
      this.dialogRef = this.dialogs.showModalSolicitaHuella(this.combinaciones, this.instruccionText, this.intentosRestantes);

    }


  };


  cierreModal() {
    this.dialogRef?.close();
  }

  //Seccion dos

  public terminoFlujoRostro: boolean = false;
  public terminoFlujoHuellas: boolean = false;

  evaluateSuccess() {
    this.bcService.failProcesadorUnsubscribe();
//    this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaRostro);
//    this.bcService.getEvaluateSuccess();
//    this.bcService.evaluateSuccessResponse$.subscribe({
//      next: (response: any) => {
//        console.log(response);
    console.log('antes de ir a capturarRostro')
    this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaRostro);
    this.router.navigateByUrl('/capturaDeRostro');
//      }
//    });
  }


  //:::::::: Verificacion Full utilidades::::::::: Seccion errores
  public flujoFail: boolean = true;
  public contadorDePaso: number = 0

  failProcesador() {
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      this.contadorDePaso++
      console.log('ingreso a fail el numero de veces: ' + this.contadorDePaso);
      if (response && response != undefined && this.flujoFail) {
        console.log('ingreso a FailProcesador: ');
        console.log(response)
        this.flagFlujo = true;
        const code = parseInt(response.code);
        this.storageService.bcStorage.procesandoAbierto == true;
        let msg = '';
        if (code >= 100 && code < 200) {
          console.log('error 100 a 200 ');
          //modalerror
          this.cerrarModal();
          msg = `Error inesperado en la lectura de licencias. C\u00F3digo: ${code}`;
          this.flujoFail = false;
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.flujoFail = true;
              // this.errorLicencias() no existe metodo en el archivo
            }
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", msg];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 320) {
          console.log('error 320 ');
          this.cerrarModal();
          this.storageService.bcStorage.codigoflujo = '320';
          this.flujoFail = false;
          msg = `Comprueba conexiones del esc\u00E1ner de huellas.\u000ASi el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.flujoFail = true;
              this.storageService.bcStorage.codigoflujo = '';
              this.renovarFail();
              this.bcService.getFingerLicences([this.guid]);
              this.ngOnInit();
            } //else {
            // this.errorFunction('CA000', 'Proceso cancelado');
            //}
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", msg];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (this.storageService.bcStorage.tipoVerificacion == 'full') {
          this.fail_VerificacionFull(response);
        } else {
        }
      } else {

      }
    });
  }

  renovarFail() {
    this.bcService.failProcesadorNew();
  }

  public flujoFail_VerificacionFull: boolean = true;

  fail_VerificacionFull(response: any) {
    //$(".preview").attr("src", "data:image/png;base64," + "");
    //formatoCaptura.colorMarco = 'rojo';
    this.flujoFail = false;
    var code = response.code;
    var message = response.message;
    var btnlbl = '';
    setTimeout(() => {
      //$scope.cerrarModalCaptura();
      // this.cerrarModal();
      //$scope.cerrarModalReloj();
      if (parseInt(code) == 270) {
        var partsOfStr = message.split(',');

        //message = "No se pudo capturar dedo(s):</br> ";
        message = "No se pudo capturar dedo(s):\n ";
        for (var x = 0; x < partsOfStr.length; x++) {
          if (partsOfStr[x] != "" && partsOfStr[x] != null) {
            switch (parseInt(partsOfStr[x])) {
              case 1:
              case 6:
                message += "pulgar ";
                break;
              case 2:
              case 7:
                message += "índice ";
                break;
              case 3:
              case 8:
                message += "medio ";
                break;
              case 4:
              case 9:
                message += "anular ";
                break;
              case 5:
              case 10:
                message += "meñique ";
                break;
            }
            if (partsOfStr[x] <= 5)
              message += "derecho";
            else
              message += "izquierdo";
            if (partsOfStr.length > 1)
              //message += ",</br>";
              message += ",\n";
          }
        }
        btnlbl = 'Repetir';
//        abrirModalError(message, "Repetir", $scope.error);
      } else if (parseInt(code) == 310) {
        message = 'Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
        btnlbl = 'Repetir';
//        abrirModalErrorDispositivo("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>", "Recargar", $scope.errordevice, $scope.cancelarinfo);
      } else if (parseInt(code) == 320) {
        message = 'Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5'
        btnlbl = 'Repetir';
      } else if (parseInt(code) == 300) {
        message = 'Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
        btnlbl = 'Repetir';
      } else if (parseInt(code) == 200) {
        this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // imagen del flujo(sin imagen)
        message = 'El tiempo para realizar la captura se ha excedido, \n por favor repítela.';
        btnlbl = 'Repetir';
      } else if (parseInt(code) == 280) {
        message = 'Indica al cliente que la captura ha excedido el número de intentos que no es posible concluir el proceso de \n verificación y tendrá que hacerlo en otra visita a \n sucursal. Agradece su tiempo.';
        btnlbl = 'Salir';
      } else if (parseInt(code) >= 100 && parseInt(code) < 200) {
        message = "Error inesperado en la lectura de licencias. Código: " + code;
        btnlbl = "Salir";
//        abrirModalError("Error inesperado en la lectura de licencias. Código: " + code, "Salir", $scope.errorlicencias);
      } else if (parseInt(code) == 230) {
        this.aprobadoFail = true;
        this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // imagen del flujo(sin imagen)
        message = "Se encontraron huellas previamente capturadas."
        btnlbl = "Finalizar";
      } else {
        this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // imagen del flujo(sin imagen)
        message = "Ocurrió un error inesperado en la captura de huellas.";
        btnlbl = "Repetir";
      }

      if (message !== '' && btnlbl !== '' && this.flujoFail_VerificacionFull) {
        this.cerrarModal();
        this.flujoFail_VerificacionFull = false;
        this.controlFlujo = false;
        this.dialogGen = this.dialogs.showDialogErrorMensaje(message, btnlbl, code, false);
        this.dialogGen.afterClosed().subscribe(response => {
          if (response) {
            console.log('cierra dialog Error: ' + response);
            if (btnlbl == 'Repetir') {
              this.reiniciarValores()
            } else {
              this.getFinalDate()
            }

          }
        })
      }

    }, 2000);
  }


  public reiniciarValores() {
    console.log('reiniciando valores')
    this.intentosRestantes--;
    this.controlFlujo = true;
    this.actualizaDialog = true;
    this.flujoFail = true;
    this.flujoFail_VerificacionFull = true;
//    this.bcService.borradoShowPreview();
//    this.bcService.dataFingerResponseObjectUnsucribe();
    this.bcService.failProcesadorUnsubscribe();
    this.cerrarModal();
//    this.startcapture();
    console.log('intento numero: ' + this.intentosRestantes + 'EsEscanerUnidactilar : ' + this.EsEscanerUnidactilar)
    this.fingerChances(this.intentosRestantes, this.EsEscanerUnidactilar);
  }


  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  cancelar() {
    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        //this.storageService.bcStorage.proceso = false;
        this.errorFunction('CA000', 'Se cancelo el proceso.');
      }
    });
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.cerrarModal();
    this.bcService.getFinalDate();
    this.bcService.getfinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    console.log('ingreso a onFinalDato');
    this.router.navigateByUrl('/finalizar');
  }

  finalDate(response: any) {
    this.storageService.bcStorage.fechapros = response.fecha;
    this.storageService.bcStorage.horapros = response.hora;
    this.storageService.bcStorage.foliopros = response.trasaction;
    var valorError = this.storageService.bcStorage.codigoflujo == undefined ? "" : this.storageService.bcStorage.codigoflujo;
    var codigoError = this.biocheckError.codigoError(valorError)
    if (codigoError != '0')
      this.storageService.bcStorage.mensajeflujo = codigoError;
    this.bcService.onStopSignalR();
    this.router.navigateByUrl('/finalizar');
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  public cerrarModal() {
    this.dialogGen?.close();
    this.dialogRef?.close();
  }

  ///Reintento de captura de huellas

  public dialogPro: MatDialogRef<any, any> | undefined;
  public vueltaNumero: number = 0;

  pruebaVidaExitosa() {
    this.modulosAprobados();
    this.vueltaNumero++;
    console.log('metodo prueba de vida vuelta: ' + this.vueltaNumero + 'estatus de aprobado' + this.aprobadoRostroCaptura);
    if (this.aprobadoRostroCaptura) {
      this.bcService.verify();
      this.bcService.getverifyResponse();
      this.bcService.verifyResponse$.subscribe({
        next: (response: any) => {
          if (response) {
            console.log('VerifyResponse:::');
            console.log(response);
            this.verifyResponse(response);
          }
        }
      })
    } else if (this.aprobadoFail) {
      console.log('Se invoco Fail...')
      this.dialogPro?.close();
      this.dialogPro?.close();
    } else if (!this.aprobadoRostroCaptura) {
      this.dialogPro?.close();
      this.dialogPro = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatosFinal);
      this.failProcesador();
      setTimeout(() => {
        this.pruebaVidaExitosa();
      }, 25000);
    }
  }

  public aprobadoRostroCaptura: boolean = false;
  public aprobadoHuellas: boolean = false;
  public aprobadoFail: boolean = false;
  public flujoStartEvaluation: boolean = true;

  modulosAprobados() {
    console.log('modulo aprobación.....')
    if (this.flujoStartEvaluation) {
      this.storageService.bcStorage.tiempoMaximo = true;
      // this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatosFinal);
      this.flujoStartEvaluation = false;
      this.bcService.startEvaluation();
    }

    this.bcService.getEvaluateSuccess();
    this.bcService.evaluateSuccessResponse$.subscribe({

      next: (response: any) => {
        console.log('ingreso' + response)
        if (response || response == undefined) {
          console.log(':::getEvaluateSuccess:::');
          console.log(response);
          this.aprobadoHuellas = true;
          this.aprobadoRostroCaptura = true;
        }
      }
    });

    this.bcService.FaceAlreadyCaptured;
    this.bcService.FaceAlreadyCapturedResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log(':::FaceAlreadyCaptured:::');
          console.log(response);
          this.aprobadoRostroCaptura = true;
        }
      }
    });
  }

  verifyResponse(response: any) {
    this.cerrarModal();
    //$.connection.hub.stop()
    if (response.code == 0) {
      if (response.result) {
        if (response.result.code === "OK0000") {
          this.storageService.bcStorage.proceso = true;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          //$(location).attr('href', '#!finalizar');
        } else {
          this.storageService.bcStorage.proceso = false;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          //$(location).attr('href', '#!finalizar');
        }
      }
    } else {
      if (response.code == 400) {
        var obj = JSON.parse(response.message);
        if (obj.errores)
          if (obj.errores.length > 0) {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = obj.errores[0].code;
            this.storageService.bcStorage.mensajeflujo = obj.errores[0].message;
            this.storageService.bcStorage.mensajeinternoflujo = obj.errores[0].description;
          }
        if (obj.errors)
          if (obj.errors.length > 0) {
            this.storageService.bcStorage.proceso = false;
            this.storageService.bcStorage.codigoflujo = obj.errors[0].code;
            this.storageService.bcStorage.mensajeflujo = obj.errors[0].message;
            this.storageService.bcStorage.mensajeinternoflujo = obj.errors[0].description;
          }
      } else if (response.code == 404) {
        this.storageService.bcStorage.proceso = false;
        this.storageService.bcStorage.codigoflujo = "EVB02";
      } else {
        this.storageService.bcStorage.proceso = false;
        this.storageService.bcStorage.codigoflujo = "EVB00";
      }
    }
    this.getFinalDate();
  };


}
