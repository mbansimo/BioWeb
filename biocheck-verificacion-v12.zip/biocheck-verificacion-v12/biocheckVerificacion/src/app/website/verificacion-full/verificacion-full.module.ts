import {NgModule} from "@angular/core";
import {VerificacionFullComponent} from "./verificacion-full.component";
import {VerificacionFullRoutingModule} from "./verificacion-full-routing.module";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatButtonModule} from "@angular/material/button";
import {MatTooltipModule} from "@angular/material/tooltip";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";


@NgModule({
  declarations: [
    VerificacionFullComponent,
  ],
    imports: [
        CommonModule,
        VerificacionFullRoutingModule,
        MaterialModule,
        SharedModule,
        MatTooltipModule,
        MatButtonModule,
        DialogsModule,
    ],
  exports: [

  ],
  bootstrap: [VerificacionFullComponent]
})
export class VerificacionFullModule {}
