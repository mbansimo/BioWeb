import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerificacionNoClienteFormaMigratoriaComponent } from './verificacion-no-cliente-forma-migratoria.component';

describe('VerificacionNoClienteFormaMigratoriaComponent', () => {
  let component: VerificacionNoClienteFormaMigratoriaComponent;
  let fixture: ComponentFixture<VerificacionNoClienteFormaMigratoriaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerificacionNoClienteFormaMigratoriaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VerificacionNoClienteFormaMigratoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
