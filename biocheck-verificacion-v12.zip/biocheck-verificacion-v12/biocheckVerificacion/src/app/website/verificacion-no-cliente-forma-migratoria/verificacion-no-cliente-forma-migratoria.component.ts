import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {MatDialogRef} from "@angular/material/dialog";
import {BiocheckService} from "../../core/services/biocheck.service";
import {Router} from "@angular/router";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {UtilDialogs} from "../../common/util-dialogs";
import {EscanearService} from "../../core/services/escanear.service";
import {RespuestaControlErroresModel} from "../../core/models/respuesta-control-errores.model";
import {FinalDateModel} from "../../core/models/final-date.model";
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import * as $ from "jquery";
import {GenerarCurpService} from "../../core/services/generar-curp.service";
import {CatalogosService} from "../../core/services/catalogos.service";
import {Errors} from 'src/app/enums/errors.msg';


@Component({
  selector: 'app-verificacion-no-cliente-forma-migratoria',
  templateUrl: './verificacion-no-cliente-forma-migratoria.component.html',
  styleUrls: ['./verificacion-no-cliente-forma-migratoria.component.scss']
})
export class VerificacionNoClienteFormaMigratoriaComponent implements OnInit {

  //Etiquetas de titulo de vista
  public headerVista = 'Escanear forma migratoria';
  public headerInstrucciones = 'Introduce la identificación y da clic en el botón de escanear.';
  public frenteFM = 'Frente de la forma migratoria';
  public reversoFM = 'Vuelta de la forma migratoria';
  public imgFormaM = 'assets/img/forma_migratoria.png';
  public imgFormaMReverso = 'assets/img/FORMAMIGRATORIA_vuelta.png';
  public imgHelp = 'assets/img/svg/ayuda.svg';
  public tooltiptips_1: string = 'Recomendación: Los datos de la forma migratria deben ser legibles y claros, sin enmendaduras o tachaduras.';
  public tituloEscanear = 'Escanear';
  public tituloContinuar = 'Continuar';

  public cabeceraBiocheck: boolean = true;

  //Variables reset escáner
  public intentosReiniciarEscaner = 0;
  public intentosResetEscanerDoc = 3;
  public esReintentoEscaner = false;

  public procesadorInvoked: boolean = false; //bandera para saber si ya se invoco procesador y no invocarlo nuevamente
  public btnEscanear: string = ''; //texto del botón
  public btnCancelar: string = 'Cancelar'; //texto del botón
  public tienePasaporte!: boolean; // en el código no se utiliza, solo se llama en guardarDatosEscaneados
  public invokedScanDocumentActived: boolean = false;
  public instruccionEscaneo: string = 'Escaneando documento.';
  public atras = '';
  public frente = '';

  // scope
  public scan: boolean = false; //esta variable es para saber si el boton escaneara o ira a la siguiente pagina
  public respuestaInstruccion: any;
  public regresoRespuesta: boolean = false;
  public errorEscaner!: boolean;
  public errorGeneral!: boolean;
  public dialogRef: MatDialogRef<any, any> | undefined;
  // variables utilizados en verificacion
  public escaneoOK: boolean = false;
  public nombre: any = '';
  public primerApellido: any = '';
  public segundoApellido: any = '';
  public ano: any = '';
  public mes: any = '';
  public dia: any = '';
  public fechaNacimiento: any = '';
  public genero: any = '';
  public entidadNacimiento: any = '';
  public curp: any = '';
  public nacionalidad: any;

  // msj
  public msjNombre: string = '';
  public msjPrimerApellido: string = '';
  public msjSegundoApellido: string = '';
  public msjFechaNacimiento: string = '';
  public msjGenero: string = '';
  public msjEntidadNacimiento: string = '';
  public msjCurp: string = '';
  public CURPcalculado: string = '';


  public dialogGen: MatDialogRef<any, any> | undefined;

  constructor(
    private cdRef: ChangeDetectorRef,
    private bcService: BiocheckService,
    private storageService: BcstorageService,
    private router: Router,
    private dialogs: UtilDialogs,
    private bccatalogos: CatalogosService,
    private bcCurp: GenerarCurpService,
    private escanearService: EscanearService
  ) {
//    this.bcService.crearConexion();
    this.storageService.bcStorage.documentScan = 2; // 1 = ife/ine   2 = FM   3 = Pasaporte
  }

  ngOnInit(): void {
    this.cabeceraBiocheck = true;
//    this.bcService.initializeSignalConnection();
//    this.bcService.connectionScaner$.subscribe(response => {
//      if (response) {
    console.log('Connected...');
    this.scan = true;
    this.storageService.bcStorage.signalrStopped = false;
    this.inicializarVista();

//      }
//    })
//    this.bcService.initializeSignalConnection();
  }


  dialogA() {
    this.dialogRef = this.dialogs.showDialogInsctructionScan(this.instruccionEscaneo, false);
    this.dialogRef.afterClosed().subscribe(response => {
      this.onAbrirModalErrorSinEscaner();
    });
  }

  dialogB() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan('Voltear documento', true, 'Escanear');
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {
          this.scanSideB();
        }
      }
    );
  }

  onCerrandoModalErrorSinEscaner() {
    if (this.respuestaInstruccion.Message === undefined || typeof this.respuestaInstruccion.Message === 'undefined' || /(esc(a|á)ner de documentos.*conectado)|(conexiones.*esc(a|á)ner de documentos)/i.test(this.respuestaInstruccion.Message)) {
      this.estadoInicialImagenes();
      const msg = 'Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
      const dialogRef = this.dialogs.showDialogError(msg, 'Repetir');
      dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.textoBtnScanear(true);
          try {
            this.sendLog('warning', '', msg);
          } catch (tryError) {
          }
        }
      });
    }
  }

  //funcion inicial para la vista
  inicializarVista() {
    this.textoBtnScanear(true);
    this.estadoInicialImagenes();

    if (this.storageService.bcStorage.YaEscaneoPasaporte &&
      this.storageService.bcStorage.YaEscaneoPasaporte == true) {

      this.nombre = this.storageService.bcStorage.nombrePasaporte;
//      this.primerApellido = this.storageService.bcStorage.apellidoP;
      this.primerApellido = 'MEDINA';
      //this.segundoApellido = this.storageService.bcStorage.apellidoM;
      this.segundoApellido = 'ORTEGA';
      this.ano = this.storageService.bcStorage.ano;
      this.mes = this.storageService.bcStorage.mes;
      this.dia = this.storageService.bcStorage.dia;
      this.fechaNacimiento = this.storageService.bcStorage.fehaNacimientoPasaporte;
      this.genero = this.storageService.bcStorage.sexo;
      this.entidadNacimiento = this.storageService.bcStorage.entidadNacimiento;
      this.curp = this.storageService.bcStorage.curp;
      this.nacionalidad = this.storageService.bcStorage.nacionalidadCode?.toString().toUpperCase();
    }

  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  //Cambia el texto del boton a "escanear" o "continuar" ademas de que decide el flujo
  textoBtnScanear(valor: boolean) {
    if (valor) {
      this.scan = true;
      this.btnEscanear = this.tituloEscanear;
    } else {
      this.scan = false;
      this.btnEscanear = this.tituloContinuar;
    }
    console.log('muestra de titulo de boton::' + valor)
  }

  estadoInicialImagenes() {
    this.frente = this.imgFormaM;
    this.atras = this.imgFormaMReverso;
  }

  // LimpiarVigencia TODO: Crear este metodo y ver en donde se utiliza
  limpiarVigencia(fecha: any) {
    var fechas = [];
    if (!fecha) {
      return '';
    } else {
      fechas = fecha.split("-");
      return fechas[fechas.length - 1];
    }
  }

  guardarDatosEscaneados(responseEscaner: any) {
    if (responseEscaner.ClassName == 'Documento de residencia') {
      this.escanearService.guardarDatos(responseEscaner, 2);
      this.tienePasaporte = true;
      this.storageService.bcStorage.EsFM = true;
    } else {
      this.storageService.bcStorage.EsFM = false;
      responseEscaner.message = "";
    }
    //Revisamos si se escanearon correctamente los dos lados
    return !!(this.storageService.bcStorage.imagenFrente && this.storageService.bcStorage.imagenAtras);
  }

  validarVigencia() {    //TODO: Verificar ya que solicitaba informacion de ingreso como año aun que estaba declarada como variable, ademas no se usa en el flujo
    var fechaDeHoy = new Date();
    var anio = fechaDeHoy.getFullYear();
    var caducidad = new Date(anio, 11, 31);
    if (caducidad >= fechaDeHoy) {
      return true;
    } else {
      return false;
    }
  }

  comparaDatos() {
    if (this.nombre != this.storageService.bcStorage.nombre)
      return false;
    if (this.fechaNacimiento != this.storageService.bcStorage.fehaNacimiento)
      return false
    if (this.genero != this.storageService.bcStorage.sexo)
      return false;
    if (this.nacionalidad != this.storageService.bcStorage.nacionalidadCode)
      return false;
    return true;
  }

  /**
   * FUNCIONES DE RESPUESTA
   */
  onErrorEscaner(responseEscaner: string) {
    this.respuestaInstruccion = responseEscaner;
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogError(responseEscaner, 'OK');
    this.dialogRef.afterClosed().subscribe(() => {
      this.textoBtnScanear(true);
      try {
        this.sendLog('warning', '', responseEscaner);
      } catch (tryError) {
        // ignored
      }
    });
  }

  onRespuestaEscaner(response: any) {
    if (this.errorEscaner && this.respuestaInstruccion.Code === 3 && response.Success && (/cancel/i.test(response.Message) || /no detectada/i.test(response.Message))) {
      return;
    }
    this.sendLog('warning', '', response.Message);
    if (response.Message === 'Side A') {
      this.dialogB();
      return;
    }
    if (response) {
      if (response.Success) {
        if (response.Alertas != null) {
          const data = response.Alertas.filter((alerta: any) => alerta.Valido == false); // filtrar las que Valido = false
          this.storageService.bcStorage.mensajeinternoflujo = (data != undefined && data != null && data.length >= 0) && data;
        }
        //checamos si es valido el documento escaneado
        if (response.valid) {
          //Revisamos si obtuvo los datos necesarios
          if (this.guardarDatosEscaneados(response)) {
            // se valida si existencia vigencia es true
            this.escaneoOK = true;
            this.curp = this.storageService.bcStorage.curp;
            this.errorEscaner = false;
            this.errorGeneral = false;
            this.storageService.bcStorage.proceso = true;
            this.textoBtnScanear(false);
            this.validacionInputs(true);
            this.dialogRef?.close();
            //valida que se haya escaneado una Forma Migratoria
          } else if (!this.storageService.bcStorage.EsFM) {
            this.errorGeneral = true;
            const documentoNoValido = this.escanearService.controlErrores(response, 2);
            const isRepetir = documentoNoValido.msjBoton == 'Repetir';
            const addLabel = isRepetir ? '' : ':ErrorCode:EOB09';
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(documentoNoValido.mensajeError, `${documentoNoValido.msjBoton} ${addLabel}`);
            this.dialogRef.afterClosed().subscribe(
              response => {
                if (response) {
                  if (isRepetir) {
                    this.textoBtnScanear(true);
                    this.estadoInicialImagenes();
                  } else {
                    this.errorFunction('EOB09');
                  }
                }
                try {
                  this.sendLog('warning', '', documentoNoValido.mensajeError);
                } catch (tryError) {
                }
              }
            );
          } else {  // no obtuvo los datos necesarios
            this.errorGeneral = false;
            const mensaje = "Debe escanear ambos lados de la identificación";
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(mensaje, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.textoBtnScanear(true);
                this.estadoInicialImagenes();

                try {
                  this.sendLog('warning', '', mensaje);
                } catch (tryError) {
                }
              }
            });
          }
        } else { //no es valido el documento escaneado
          try {
            this.guardarDatosEscaneados(response);
          } catch (error) {
          }
          this.errorGeneral = true;
          const documentoNoValido: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 2);
          this.textoBtnScanear(true);
        }
      } else { // Response no success
        this.textoBtnScanear(true);
        const documentoNoSuccess: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 2);
        this.dialogRef?.close();
        this.dialogRef = this.dialogs.showDialogError(documentoNoSuccess.mensajeError, documentoNoSuccess.msjBoton);
        this.dialogRef.afterClosed().subscribe(() => {
          try {
            this.sendLog('warning', '', documentoNoSuccess.mensajeError);
          } catch (tryError) {
          }
        });
        this.errorGeneral = true;
      }
    } else { // NO RESPONSE
      this.textoBtnScanear(true);
      const documentoNoSuccess: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 2);
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogError(documentoNoSuccess.mensajeError, documentoNoSuccess.msjBoton);
      this.dialogRef.afterClosed().subscribe(() => {
        try {
          this.sendLog('warning', '', documentoNoSuccess.mensajeError);
        } catch (tryError) {
        }
      });
      this.errorGeneral = true;
    }
  }

  onRespuestaInstruccion(responseEscaner: any) {
    this.respuestaInstruccion = responseEscaner;
    switch (responseEscaner.Code) {
      case 4:
        this.errorEscaner = false;
        break;
      case 5:
      case 6:
        this.errorEscaner = true;
        break;
      case 1:
      case 7:
        this.instruccionEscaneo = 'Escaneando documento.'
        break;

      default:
        this.instruccionEscaneo = responseEscaner.Message;
        break;
    }
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    if (this.storageService.bcStorage.proceso) {
      this.router.navigateByUrl('/finalizar');
    } else {
      this.respuesta();
    }
  }

  onAbrirModalErrorSinEscaner() {
    if (!this.invokedScanDocumentActived) {
      this.bcService.invokeScanDocument([2]);
      this.invokedScanDocumentActived = true;
    }
  }

  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.getFinalDate();
  }

  scanSideB() {
    this.bcService.invokeScanDocumentManual([1]);
    // modalInstrucciones.open();
    const resp = {Code: 7, Message: "Escaneando documento."};
    this.bcService.invokeScanDocument([1]);
    this.dialogA();
    this.onRespuestaInstruccion(resp);
  }

  respuestaProcesador() {
    this.bcService.respuestaProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      if (response) {
        console.log('response', response)
        const id = response.id;
        switch (id) {
          case 'VerificarEstatusEscanerDoc':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Verificar si el escaner está conectado y online
              this.activarModoManualEscaner();
            }
            break;
          case 'VerificarEscanerConectadoOnline':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Poner el flujo que se quiere ejecutar en la respuesta
              this.activarModoManualEscaner();
            }
            break;
          case 'ActivarModoManualEscaner':
            // this.startScanProcess();
            // Se ejecuta función que indica que los dispositivos se chequearon con éxito ??
            break;
          default:
            break;
        }
      }
    });
  }


  failProcesador() {
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      if (response) {
        console.log(response.code);
        const code = parseInt(response.code);
        let msg = '';
        if (code === 330) {
          //modalerror2
          msg = `Comprueba conexiones del esc\u00E1ner de documentos \u000ASi el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              // this.errorFunction();
              // CHECAR error EN CODIGO
            } else {
              this.cancelarinfo();
            }
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 331) {
          //modalerror
          msg = `Servicio de escaneo de documentos no pudo ser iniciado.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 332) {
          //modalerror
          msg = `Comprueba conexiones del esc\u00E1ner de documentos \u000ASi el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          let dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 333) {
          //Si hay intentos, verifica el estatus del escáner
          if (this.intentosReiniciarEscaner < this.intentosResetEscanerDoc) {
            this.intentosReiniciarEscaner++;
            this.esReintentoEscaner = true;
            //modalerror2
            msg = `Comprueba conexiones del esc\u00E1ner de documentos \u000ASi el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5`;
            let dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
            dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.verificarEscanerDocumentos();
              } else {
                this.cancelarinfo();
              }
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          } else { //Si no hay intentos, notifica y termina flujo
            //modalerror
            msg = `Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
            let dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
            dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.errorServiciosEscaner();
              }
              ;
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          }
        } else if (code === 350) {
          //modalerror
          let dialogRef = this.dialogs.showDialogErrorMensaje(response.message, 'Salir');
          dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        }
      }
    });
  }

  verificarEscanerDocumentos() {
    this.dialogRef?.close();
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEstatusEscanerDoc", {});
    })
  }

  verificarEscanerConectadoOnline() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEscanerConectadoOnline", {});
    })
  }

  activarModoManualEscaner() {
    this.controladorFunciones("ActivarModoManualEscaner", {});
  }

  controladorFunciones(id: string, parametrosEntrada: any) {
    console.log('## Controlador de Funciones ....'); //TODO: Quitar logs
    const funcion = {
      Id: id,
      ParametrosEntrada: parametrosEntrada
    };
    this.bcService.procesador([funcion]); // si es necesario no invocarlo lo metemos en if de abajo
    if (!this.procesadorInvoked) {
      this.procesadorInvoked = true;
    }
  }

  errorServiciosEscaner() {
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.codigoflujo = "ELB01";
    this.getFinalDate();
  }

  failScan() {
    this.bcService.getFailScan();
    this.bcService.responseScan$.subscribe(response => {
      if (response) {
        this.onErrorEscaner(response);
      }
    });
  }

  responseScan() {
    if (this.bcService.getResponseScan() != null) {
      this.bcService.responseScan$.subscribe(response => {
        if (response) {
          if (response.Message !== 'Side A') {
          }
          this.onRespuestaEscaner(response);
        }
//        this.failScan();
      });
    }
  }

  async instructionScan() {
    await this.bcService.getInstructionScan();
    await this.bcService.instruccionesScaner$.subscribe({
      next: response => {
        if (response) {
          this.onRespuestaInstruccion(response);
        }
      }
    });
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  sendMessage(msg: string) {
    //postFinalizar(msg); no existe funcionalidad
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  // Acción del botón
  continuar() {
    if (this.scan) {
      console.log(this.instruccionEscaneo);
      this.onAbrirModalErrorSinEscaner();
      this.dialogA();
      this.instructionScan();
      this.responseScan();
    }  else {
      this.storageService.bcStorage.curp = this.curp;
      // @ts-ignore
      this.storageService.bcStorage.respuestaNC?.curp = this.storageService.bcStorage.curp;
      if (this.storageService.bcStorage.repetirCapturaDatosIne === true) {
        this.storageService.bcStorage.nombrePasaporte = this.nombre;
        this.storageService.bcStorage.apellidoP = this.primerApellido;
        this.storageService.bcStorage.apellidoM = this.segundoApellido;
        // @ts-ignore
        this.storageService.bcStorage.respuestaNC?.nombre = this.storageService.bcStorage.nombrePasaporte + " " + this.storageService.bcStorage.apellidoP + " " + this.storageService.bcStorage.apellidoM;
      }
      this.storageService.bcStorage.yaEscaneoIne = true;

      // Compara datos OCR vs datos recibidos del cliente
      if (this.storageService.bcStorage.datosCanal && this.storageService.bcStorage.datosCanal !== undefined && this.storageService.bcStorage.datosCanal !== null && this.storageService.bcStorage.datosCanal !== "") {
        if (typeof this.storageService.bcStorage.datosCanal === 'string') {
          this.storageService.bcStorage.datosCanal = JSON.parse(this.storageService.bcStorage.datosCanal);
        }
        var datosDiferentes = [];
        // @ts-ignore
        if (this.storageService.bcStorage.datosCanal.Nombres && this.storageService.bcStorage.datosCanal.Nombres != null && this.storageService.bcStorage.datosCanal.Nombres != "") {
          // @ts-ignore
          if (this.nombre != this.storageService.bcStorage.datosCanal.Nombres) {
            // @ts-ignore
            datosDiferentes.push({ Dato: "Nombres", Ocr: this.nombre, Canal: this.storageService.bcStorage.datosCanal.Nombres });
          }
          // @ts-ignore
          if (this.primerApellido != this.storageService.bcStorage.datosCanal.PrimerApellido) {
            // @ts-ignore
            datosDiferentes.push({ Dato: "PrimerApellido", Ocr: this.primerApellido, Canal: this.storageService.bcStorage.datosCanal.PrimerApellido });
          }
          // @ts-ignore
          if (this.segundoApellido != this.storageService.bcStorage.datosCanal.SegundoApellido) {
            // @ts-ignore
            datosDiferentes.push({ Dato: "SegundoApellido", Ocr: this.segundoApellido, Canal: this.storageService.bcStorage.datosCanal.SegundoApellido });
          }
          var fechaNacimientoFormato = this.ano + "-" + this.mes + "-" + this.dia;
          // @ts-ignore
          if (fechaNacimientoFormato != this.storageService.bcStorage.datosCanal.FechaNacimiento) {
            // @ts-ignore
            datosDiferentes.push({ Dato: "FechaNacimiento", Ocr: fechaNacimientoFormato, Canal: this.storageService.bcStorage.datosCanal.FechaNacimiento });
          }
          if (datosDiferentes.length > 0) {
            var errores = "";
            datosDiferentes.forEach(function (item, index, arr) {
              errores += "<li><a style='color: rgb(236, 0, 0);'>" + item.Dato + "</a><br/>Pasaporte: " + item.Ocr + "<br/>Origen: " + item.Canal + "</li>";
            });

            var mensajefinal = "Favor de validar la información que no sea un error de captura, en caso de que no sea así sugiere que acuda al INM para actualizar su información";
            this.storageService.bcStorage.codigoflujo = 'EVD03';
            const msjError = `${Errors}.${this.storageService.bcStorage.codigoflujo}`;

            this.dialogGen = this.dialogs.showDialogErrorMensaje(`<div style = 'font-weight:700;' > Comparación de datos OCR vs Canal</div > <br /><div style='text-align: left;'>Indica al cliente que debes finalizar el proceso, porque los siguientes datos obtenidos del pasaporte no coinciden con los de origen: <br><br>`
              + `<ul style='list-style: inside;'>" + errores + "</ul>" + mensajefinal + "</div>" `, "Finalizar", msjError, true);
          } else {
//            biocheck.onStopSignalR();
            this.router.navigateByUrl(`/NoCliente/ausenciaycaptura`);
//            $(location).attr('href', '#!/NoCliente/ausenciaycaptura');
          }
        }
      } else {
        this.router.navigateByUrl(`/NoCliente/ausenciaycaptura`);
      }
    }
  }

  cancelar() {
    const dialogRef = this.dialogs.showDialogCancelar();
    dialogRef.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "PaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  public datosOk: boolean = false;
  public nacionalidadesSinSegundoApellido: Array<string> = ['ARG']

  validacionInputs(primeraVez: boolean) {
    this.datosOk = true;
    this.msjNombre = '';
    this.msjPrimerApellido = '';
    this.msjSegundoApellido = '';
    this.msjFechaNacimiento = '';
    this.msjGenero = '';
    this.msjEntidadNacimiento = '';
    this.msjCurp = '';
    var esNacionalidadSinSegundoApellido = false;
    console.log('ingreso a validacion'+ this.bccatalogos.nacionalidadesSinSegundoApellido)
    if (typeof this.storageService.bcStorage.nacionalidadCode === "string") {
      esNacionalidadSinSegundoApellido = this.nacionalidadesSinSegundoApellido.includes(this.storageService.bcStorage.nacionalidadCode);
      console.log('lleva este valor ::: ' + esNacionalidadSinSegundoApellido);
    }
    if (primeraVez === true) {
      $("#Curp").prop('readonly', true);
    }
    if (this.nombre == null || this.nombre == "") {
      this.datosOk = false;
      this.msjNombre = "Campo vacío";
    } else if (this.primerApellido == null || this.primerApellido == "") {
      this.datosOk = false;
      this.msjPrimerApellido = "Campo vacío";
    } else if ((this.segundoApellido == null || this.segundoApellido == "") && !esNacionalidadSinSegundoApellido) {
      this.datosOk = false;
      this.msjSegundoApellido = "Campo vacío";
    } else if (this.fechaNacimiento == null || this.fechaNacimiento == "") {
      this.datosOk = false;
      this.msjFechaNacimiento = "Campo vacío";
    } else if (this.genero == null || this.genero == "") {
      this.datosOk = false;
      this.msjGenero = "Campo vacío";
    } else if (this.entidadNacimiento == null || this.entidadNacimiento == "") {
      this.datosOk = false;
      this.msjEntidadNacimiento = "Campo vacío";
    } else if (this.curp == null || this.curp == "") {
      // No se hace nada porque en caso de pasaportes extranjeros, la curp no viene, y se usaría la api de consultaByDetalle
      //$scope.datosOk = false;
      //$scope.msjCurp = "Campo vacío";
    } else {
      this.CURPcalculado = this.bcCurp.generar2(this.nombre, this.primerApellido, this.segundoApellido, this.ano, this.mes, this.dia, this.genero, this.entidadNacimiento).toUpperCase();

      // Se obtienen las curp sin los ultimos dos digitos de homoclabe para comparación.
      // Estos dos dígitos son dos dígitos que se asignan por RENAPO en el momento de sacar tu curp y se hace de manera aleatoria. (Si se pueden calcular los 16 primeros dígitos con certeza, pero la homoclave no viene de ningún cálculo).
      var curpSinHomoclabe = this.curp.substring(0, 16).toUpperCase();
      var curpCalculadoSinHomoclabe = this.CURPcalculado.substring(0, 16).toUpperCase();
      var curpIgualACalculada = curpSinHomoclabe === curpCalculadoSinHomoclabe;
      var fechaCurp = this.curp.substring(4, 10).toUpperCase();
      var fechaNacimientoCurpFormat = this.ano.substring(2, 4) + this.mes + this.dia;

      this.curp = this.curp.toUpperCase();

      if (this.curp.length !== 18) {
        this.datosOk = false;
        this.msjCurp = "Estructura de CURP incorrecta";
      } else if (!/^[A-Z][A,E,I,O,U,X][A-Z]{2}[0-9]{2}[0-1][0-9][0-3][0-9][M,H][A-Z]{2}[B,C,D,F,G,H,J,K,L,M,N,Ñ,P,Q,R,S,T,V,W,X,Y,Z]{3}[0-9,A-Z]{2}$/ig.test(this.curp)) {
        this.datosOk = false;
        this.msjCurp = "Estructura de CURP incorrecta";
      } else if (fechaCurp != fechaNacimientoCurpFormat) {
        this.datosOk = false;
        this.msjCurp = "Fecha de CURP no coincide con fecha de nacimiento";
      } else if (!curpIgualACalculada) {
        //$scope.datosOk = false;
        //$scope.msjCurp = "Validación de CURP incorrecta. Ejemplo: " + $scope.CURPcalculado;
      }
    }
    if (this.msjCurp != null && this.msjCurp != "") {
      $("#Curp").prop('readonly', false);
    }
    if (!this.datosOk) {
      $("#escanearBtn").hide();
    } else {
      $("#escanearBtn").show();
    }

  };


}
