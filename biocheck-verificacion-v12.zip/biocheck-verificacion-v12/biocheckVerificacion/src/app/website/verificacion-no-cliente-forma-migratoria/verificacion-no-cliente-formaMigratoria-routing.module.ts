import {RouterModule, Routes} from "@angular/router";
import {NgModule} from "@angular/core";
import {VerificacionNoClienteFormaMigratoriaComponent} from "./verificacion-no-cliente-forma-migratoria.component";


const routes: Routes = [
  {path: '', component: VerificacionNoClienteFormaMigratoriaComponent},

]


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VerificacionNoClienteFormaMigratoriaRoutingModule{

}


