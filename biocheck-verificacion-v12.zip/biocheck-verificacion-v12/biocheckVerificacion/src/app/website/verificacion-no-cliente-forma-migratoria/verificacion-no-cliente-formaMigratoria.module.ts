import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {VerificacionNoClienteFormaMigratoriaComponent} from "./verificacion-no-cliente-forma-migratoria.component";
import {
  VerificacionNoClienteFormaMigratoriaRoutingModule
} from "./verificacion-no-cliente-formaMigratoria-routing.module";

@NgModule({
  declarations: [
    VerificacionNoClienteFormaMigratoriaComponent,
  ],
  imports: [
    CommonModule,
    VerificacionNoClienteFormaMigratoriaRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
  ],
  exports: [

  ],
  bootstrap: [VerificacionNoClienteFormaMigratoriaComponent]
})
export class VerificacionNoClienteFormaMigratoriaModule{}
