import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {VerificacionNoClientePasaporteComponent} from "./verificacion-no-cliente-pasaporte.component";


const routes: Routes = [
  {path: '', component: VerificacionNoClientePasaporteComponent},
]


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VerificacionNoClientePasaporteRoutingModule {
}
