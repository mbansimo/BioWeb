import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {MatDialogRef} from "@angular/material/dialog";
import {DialogGeneralComponent} from "../../shared/dialogs/dialog-general/dialog-general.component";
import {BiocheckService} from "../../core/services/biocheck.service";
import {Router} from "@angular/router";
import {BcstorageService} from "../../core/services/bcstorage.service";
import {UtilDialogs} from "../../common/util-dialogs";
import {EscanearService} from "../../core/services/escanear.service";
import {RespuestaControlErroresModel} from "../../core/models/respuesta-control-errores.model";
import {FinalDateModel} from "../../core/models/final-date.model";
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import * as $ from "jquery";
import {BiocheckPasosService} from "../../core/services/biocheck-pasos.service";
import {CatalogosService} from "../../core/services/catalogos.service";
import {GenerarCurpService} from "../../core/services/generar-curp.service";

@Component({
  selector: 'app-verificacion-no-cliente-pasaporte',
  templateUrl: './verificacion-no-cliente-pasaporte.component.html',
  styleUrls: ['./verificacion-no-cliente-pasaporte.component.scss']
})
export class VerificacionNoClientePasaporteComponent implements OnInit {

  public headerVista = 'Escanear pasaporte';
  public headerInstrucciones = 'Introduce la identificación y da clic en el botón de escanear.';
  public imgHelp = 'assets/img/svg/ayuda.svg';
  public instruccionPasaporte = 'Para Pasaporte extranjero solo se escaneara el frente del documento';
  public frentePasaporte = 'Frente de pasaporte';
  public imgPasaporte = '';
  public reversoPasaporte = 'Vuelta de pasaporte';
  public imgPasaporteReverso = '';
  public btnCancelar: string = 'Cancelar'; //texto del botón
  public btnEscanear: string = ''; //texto del botón

  //Variables reset escáner
  public intentosReiniciarEscaner = 0;
  public intentosResetEscanerDoc = 3;
  public esReintentoEscaner = false;

// titulos en duro
  public tooltiptips_1 = 'Tips de documento: Los datos del pasaporte deben ser legibles y claros, sin enmendaduras o tachaduras.'
  public tituloEscanear = 'Escanear';
  public tituloContinuar = 'Continuar';
  public imgPasaporteFront = 'assets/img/pasaporte.png';
  public imgPasaporteBack = 'assets/img/PassBack.png';
  public procesadorInvoked: boolean = false; //bandera para saber si ya se invoco procesador y no invocarlo nuevamente
  public tienePasaporte!: boolean; // en el código no se utiliza, solo se llama en guardarDatosEscaneados
  public invokedScanDocumentActived: boolean = false;
  public instruccionEscaneo: string = 'Escaneando documento.';

  // scope
  public scan: boolean = false; //esta variable es para saber si el boton escaneara o ira a la siguiente pagina
  public respuestaInstruccion: any;
  public regresoRespuesta: boolean = false;
  public errorEscaner!: boolean;
  public errorGeneral!: boolean;
  public dialogRef: MatDialogRef<DialogGeneralComponent, any> | undefined;

  //declaracion de variables
  public escaneoOk: boolean = false;
  public datosOk: boolean = false;
  public nombre: string | undefined = '';
  public primerApellido: string | undefined = '';
  public segundoApellido: string | undefined = '';
  public ano: any = '';
  public mes: string | undefined = '';
  public dia: string | undefined = '';
  public fechaNacimiento: string | undefined = '';
  public genero: any  = '';
  public entidadNacimiento: string = '';
  public curp: string | undefined = '';
  public nacionalidad:any = '';

  // msj
  public msjNombre: string = '';
  public msjPrimerApellido: string = '';
  public msjSegundoApellido: string = '';
  public msjFechaNacimiento: string = '';
  public msjGenero: string = '';
  public msjEntidadNacimiento: string = '';
  public msjCurp: string = '';
  public CURPcalculado: string = '';


  constructor(
    private bcService: BiocheckService,
    private cdRef: ChangeDetectorRef,
    private storageService: BcstorageService,
    private router: Router,
    private dialogs: UtilDialogs,
    private Pasos: BiocheckPasosService,
    private bccatalogos: CatalogosService,
    private bcCurp: GenerarCurpService,
    private escanearService: EscanearService
  ) {
  }

  ngOnInit(): void {

    this.controlDePasos();
    this.scan = true;
    this.storageService.bcStorage.signalrStopped = false;
    //this.verificarEscanerDocumentos(); // despues de iniciar conexión veficia escaner documentos
    this.inicializarVista();
  }


  ngAfterViewInit(): void {
    setTimeout(() => {
      // this.start()
    }, 0);
    this.cdRef.detectChanges();
  }

  public controlPasos: boolean = true;

  controlDePasos() {
    if (this.controlPasos) {
      var lista = this.Pasos.totalPasos(2);
      $('#listaPasos').append(lista);
      this.cambiarPaso(1, "Escanear Identificación");//revisar
      this.controlPasos = false;
    } else {
      console.log('ya se cargaron los pasos::::')
    }
  }

  cambiarPaso(paso: number, nombre: string) {
    $('#paso' + paso).css('text-decoration', 'underline');
    $('#paso' + paso).css('float', 'left');

    $("#nombrePasoActual").text(nombre);
    for (var i = 1; i <= paso; i++) {
      $('#paso' + i).css('color', '#ec0000');
    }
  }

  dialogA() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan(this.instruccionEscaneo, false);
    this.dialogRef.afterClosed().subscribe(response => {
      this.onAbrirModalErrorSinEscaner();
    });
  }

  dialogB() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogInsctructionScan('Voltear documento', true, 'Escanear');
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {
          this.scanSideB();
        }
      }
    );
  }

  onCerrandoModalErrorSinEscaner() {
    if (this.respuestaInstruccion.Message === undefined || typeof this.respuestaInstruccion.Message === 'undefined' || /(esc(a|á)ner de documentos.*conectado)|(conexiones.*esc(a|á)ner de documentos)/i.test(this.respuestaInstruccion.Message)) {
      this.estadoInicialImagenes();
      const msg = 'Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogError(msg, 'Repetir');
      this.dialogRef.afterClosed().subscribe(response => {
        if (response) {
          this.textoBtnScanear(true);
          try {
            this.sendLog('warning', '', msg);
          } catch (tryError) {
          }
        }
      });
    }
  }

  //funcion inicial para la vista
  inicializarVista() {
    console.log('## inicializando Vista ....Pasaporte:::');
    this.textoBtnScanear(true);
    this.estadoInicialImagenes();


  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  //Cambia el texto del boton a "escanear" o "continuar" ademas de que decide el flujo
  textoBtnScanear(valor: boolean) {
    if (valor) {
      this.scan = true;
      this.btnEscanear = this.tituloEscanear;
    } else {
      this.scan = false;
      this.btnEscanear = this.tituloContinuar;
    }
  }

  estadoInicialImagenes() {
    this.imgPasaporte = this.imgPasaporteFront;
    this.imgPasaporteReverso = this.imgPasaporteBack;
  }

  guardarDatosEscaneados(responseEscaner: any) {
    if (responseEscaner.ClassName == 'Pasaporte') {
      this.escanearService.guardarDatos(responseEscaner, 3);
      this.tienePasaporte = true;
      this.storageService.bcStorage.esPasaporte = true;
    } else {
      this.storageService.bcStorage.esPasaporte = false;
      responseEscaner.message = "";
    }
    //Revisamos si se escanearon correctamente los dos lados
    return !!(this.storageService.bcStorage.imagenFrente);
  }


  /**
   * FUNCIONES DE RESPUESTA
   */
  onErrorEscaner(responseEscaner: string) {
    this.respuestaInstruccion = responseEscaner;
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogError(responseEscaner, 'OK');
    this.dialogRef.afterClosed().subscribe(() => {
      this.textoBtnScanear(true);
      try {
        this.sendLog('warning', '', responseEscaner);
      } catch (tryError) {
        // ignored
      }
    });
  }

  onRespuestaEscaner(response: any) {
    if (this.errorEscaner && this.respuestaInstruccion.Code === 3 && response.Success && (/cancel/i.test(response.Message) || /no detectada/i.test(response.Message))) {
      return;
    }

    this.sendLog('warning', "CaaS [" + window.location.href + "]", response.Message);

    if (response.Message === 'Side A') {
      this.dialogB();
      return;
    }

    if (response) {
      if (response.Success) {
        if (response.Alertas != null) {
          const data = response.Alertas.filter((alerta: any) => alerta.Valido == false); // filtrar las que Valido = false
          this.storageService.bcStorage.mensajeinternoflujo = (data != undefined && data != null && data.length >= 0) && data;
        }
        //checamos si es valido el documento escaneado
        if (response.valid) {
          //Revisamos si obtuvo los datos necesarios
          if (this.guardarDatosEscaneados(response)) {
            // se valida si existencia vigencia es true

            this.llenadoDeDatos();
            this.errorEscaner = false;
            this.errorGeneral = false;
            this.storageService.bcStorage.proceso = true;
            this.textoBtnScanear(false);
            console.log(':::se obtiene imagen de pasaporte y se muestra el valor de testo es false y dara continuar:::')
            this.dialogRef?.close();
            //valida que se haya escaneado una PASAPORTE
          } else if (!this.storageService.bcStorage.esPasaporte) {
            this.errorGeneral = true;
            const documentoNoValido = this.escanearService.controlErrores(response, 3);
            const isRepetir = documentoNoValido.msjBoton == 'Repetir';
            const addLabel = isRepetir ? '' : ':ErrorCode:EOB09';
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(documentoNoValido.mensajeError, `${documentoNoValido.msjBoton} ${addLabel}`);
            this.dialogRef.afterClosed().subscribe(
              response => {
                if (response) {
                  if (isRepetir) {
                    this.textoBtnScanear(true);
                    this.estadoInicialImagenes();
                  } else {
                    this.errorFunction('EOB09');
                  }
                }
                try {
                  this.sendLog('warning', '', documentoNoValido.mensajeError);
                } catch (tryError) {
                }
              }
            );
          } else {  // no obtuvo los datos necesarios
            this.errorGeneral = false;
            const mensaje = "Debe escanear ambos lados de la identificación";
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogError(mensaje, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.textoBtnScanear(true);
                this.estadoInicialImagenes();

                try {
                  this.sendLog('warning', '', mensaje);
                } catch (tryError) {
                }
              }
            });
          }
        } else { //no es valido el documento escaneado
          try {
            this.guardarDatosEscaneados(response);
          } catch (error) {
          }
          this.errorGeneral = true;
          const documentoNoValido: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 3);
          this.textoBtnScanear(true);
          //TypeModal es 2
        }
      } else { // Response no success
        this.textoBtnScanear(true);
        const documentoNoSuccess: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 3);
        this.dialogRef?.close();
        this.dialogRef = this.dialogs.showDialogError(documentoNoSuccess.mensajeError, documentoNoSuccess.msjBoton);
        this.dialogRef.afterClosed().subscribe(() => {
          try {
            this.sendLog('warning', '', documentoNoSuccess.mensajeError);
          } catch (tryError) {
          }
        });
        this.errorGeneral = true;

      }
    } else { // NO RESPONSE
      this.textoBtnScanear(true);
      const documentoNoSuccess: RespuestaControlErroresModel = this.escanearService.controlErrores(response, 3);
      this.dialogRef?.close();
      this.dialogRef = this.dialogs.showDialogError(documentoNoSuccess.mensajeError, documentoNoSuccess.msjBoton);
      this.dialogRef.afterClosed().subscribe(() => {
        try {
          this.sendLog('warning', '', documentoNoSuccess.mensajeError);
        } catch (tryError) {
        }
      });
      this.errorGeneral = true;
    }
  }

  llenadoDeDatos(){

    if (this.storageService.bcStorage.nombrePasaporte != null) {
      // @ts-ignore
      this.storageService.bcStorage.respuestaNC?.nombre = this.storageService.bcStorage.nombrePasaporte;
    }
    if (this.storageService.bcStorage.apellidoP != null) {
      // @ts-ignore
      this.storageService.bcStorage.respuestaNC?.apellidoPaterno = this.storageService.bcStorage.apellidoP;
    }
    if (this.storageService.bcStorage.apellidoM != null) {
      // @ts-ignore
      this.storageService.bcStorage.respuestaNC?.apellidoMaterno = this.storageService.bcStorage.apellidoM;
    }
   // @ts-ignore
    this.storageService.bcStorage.respuestaNC?.fechaDeNacimiento = this.storageService.bcStorage.ano + "-" + this.storageService.bcStorage.mes + "-" + this.storageService.bcStorage.dia;
   // @ts-ignore
    this.storageService.bcStorage.respuestaNC?.genero = this.storageService.bcStorage.sexo;
    if (this.storageService.bcStorage.curp != null) {
      // @ts-ignore
      this.storageService.bcStorage.respuestaNC?.curp = this.storageService.bcStorage.curp
    }
    console.log('llego a nombre')
    this.nombre = this.storageService.bcStorage.nombrePasaporte;
    this.primerApellido = this.storageService.bcStorage.apellidoP;
    this.segundoApellido = this.storageService.bcStorage.apellidoM;
    this.ano = this.storageService.bcStorage.ano;
    this.mes = this.storageService.bcStorage.mes;
    this.dia = this.storageService.bcStorage.dia;
    this.fechaNacimiento = this.storageService.bcStorage.fehaNacimientoPasaporte;
    this.genero = this.storageService.bcStorage.sexo;
    this.entidadNacimiento = this.storageService.bcStorage.entidadNacimiento;
    this.curp = this.storageService.bcStorage.curp;
    this.escaneoOk = true;
    this.nacionalidad = this.storageService.bcStorage.nacionalidadCode;
    if (this.nacionalidad.toUpperCase() == 'MEX'){
      this.validacionInputs(true);
    }else{
      this.escaneoOk = false;
    }
    console.log('termina llenado de datos')
  }

  validacionInputs(primeraVez: boolean) {
    console.log('ingreso a validacion inputs')
    this.datosOk = true;
    this.msjNombre = '';
    this.msjPrimerApellido = '';
    this.msjSegundoApellido = '';
    this.msjFechaNacimiento = '';
    this.msjGenero = '';
    this.msjEntidadNacimiento = '';
    this.msjCurp = '';
    // @ts-ignore
    var esNacionalidadSinSegundoApellido = this.bccatalogos.nacionalidadesSinSegundoApellido.includes(this.storageService.bcStorage.nacionalidadCode);
    if (primeraVez === true) {
      $("#Curp").prop('readonly', true);
    }
    if (this.nombre == null || this.nombre == "") {
      this.datosOk = false;
      this.msjNombre = "Campo vacío";
    } else if (this.primerApellido == null || this.primerApellido == "") {
      this.datosOk = false;
      this.msjPrimerApellido = "Campo vacío";
    } else if ((this.segundoApellido == null || this.segundoApellido == "") && !esNacionalidadSinSegundoApellido) {
      this.datosOk = false;
      this.msjSegundoApellido = "Campo vacío";
    } else if (this.fechaNacimiento == null || this.fechaNacimiento == "") {
      this.datosOk = false;
      this.msjFechaNacimiento = "Campo vacío";
    } else if (this.genero == null || this.genero == "") {
      this.datosOk = false;
      this.msjGenero = "Campo vacío";
    } else if (this.entidadNacimiento == null || this.entidadNacimiento == "") {
      this.datosOk = false;
      this.msjEntidadNacimiento = "Campo vacío";
    } else if (this.curp == null || this.curp == "") {
      // No se hace nada porque en caso de pasaportes extranjeros, la curp no viene, y se usaría la api de consultaByDetalle
      //$scope.datosOk = false;
      //$scope.msjCurp = "Campo vacío";
    } else {
      this.CURPcalculado = this.bcCurp.generar2(this.nombre, this.primerApellido, this.segundoApellido, this.ano, this.mes, this.dia, this.genero, this.entidadNacimiento).toUpperCase();

      // Se obtienen las curp sin los ultimos dos digitos de homoclabe para comparación.
      // Estos dos dígitos son dos dígitos que se asignan por RENAPO en el momento de sacar tu curp y se hace de manera aleatoria. (Si se pueden calcular los 16 primeros dígitos con certeza, pero la homoclave no viene de ningún cálculo).
      var curpSinHomoclabe = this.curp.substring(0, 16).toUpperCase();
      var curpCalculadoSinHomoclabe = this.CURPcalculado.substring(0, 16).toUpperCase();
      var curpIgualACalculada = curpSinHomoclabe === curpCalculadoSinHomoclabe;
      var fechaCurp = this.curp.substring(4, 10).toUpperCase();
      var fechaNacimientoCurpFormat = this.ano.substring(2, 4) + this.mes + this.dia;

      this.curp = this.curp.toUpperCase();

      if (this.curp.length !== 18) {
        this.datosOk = false;
        this.msjCurp = "Estructura de CURP incorrecta";
      } else if (!/^[A-Z][A,E,I,O,U,X][A-Z]{2}[0-9]{2}[0-1][0-9][0-3][0-9][M,H][A-Z]{2}[B,C,D,F,G,H,J,K,L,M,N,Ñ,P,Q,R,S,T,V,W,X,Y,Z]{3}[0-9,A-Z]{2}$/ig.test(this.curp)) {
        this.datosOk = false;
        this.msjCurp = "Estructura de CURP incorrecta";
      } else if (fechaCurp != fechaNacimientoCurpFormat) {
        this.datosOk = false;
        this.msjCurp = "Fecha de CURP no coincide con fecha de nacimiento";
      }
      else if (!curpIgualACalculada) {
        //$scope.datosOk = false;
        //$scope.msjCurp = "Validación de CURP incorrecta. Ejemplo: " + $scope.CURPcalculado;
      }
    }
    if (this.msjCurp != null && this.msjCurp != "") {
      $("#Curp").prop('readonly', false);
    }
    if (!this.datosOk) {
      $("#escanearBtn").hide();
    } else {
      $("#escanearBtn").show();
    }

  };

  escaneaFM(){
    this.storageService.bcStorage.YaEscaneoPasaporte = true;
    this.router.navigateByUrl('/formaMigratoria');
  }


  onRespuestaInstruccion(responseEscaner: any) {
    this.respuestaInstruccion = responseEscaner;
    switch (responseEscaner.Code) {
      case 4:
        this.errorEscaner = false;
        break;
      case 5:
      case 6:
        this.errorEscaner = true;
        this.onCerrandoModalErrorSinEscaner();
        break;
      case 1:
      case 7:
        this.instruccionEscaneo = 'Escaneando documento.'
        break;

      default:
        this.instruccionEscaneo = responseEscaner.Message;
        break;
    }
  }

  /**
   * END FUNCIONES DE RESPUESTA
   */

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    if (this.storageService.bcStorage.proceso) {
      this.router.navigateByUrl('/finalizar');
    } else {
      this.respuesta();
    }
  }

  onAbrirModalErrorSinEscaner() {
    if (!this.invokedScanDocumentActived) {
      this.bcService.invokeScanDocument([3]);
      this.invokedScanDocumentActived = true;
    }
  }

  /**
   * INICIA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
   */


  cancelarinfo() {
    this.storageService.bcStorage.proceso = true;
    this.storageService.bcStorage.codigoflujo = "CA000";
    this.getFinalDate();
  }

  scanSideB() {
    this.bcService.invokeScanDocumentManual([1]);
    // modalInstrucciones.open();
    const resp = {Code: 7, Message: "Escaneando documento."};
    this.bcService.invokeScanDocument([1]);
    this.dialogA();
    this.onRespuestaInstruccion(resp);
  }

  respuestaProcesador() {
    this.bcService.respuestaProcesador();
    this.bcService.respuestaProcesador$.subscribe(response => {
      if (response) {
        console.log('response', response)
        const id = response.id;
        switch (id) {
          case 'VerificarEstatusEscanerDoc':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Verificar si el escaner está conectado y online
              this.activarModoManualEscaner();
            }
            break;
          case 'VerificarEscanerConectadoOnline':
            if (response.Respuesta != undefined && response.Respuesta != null && response.Respuesta != '') {
              //Poner el flujo que se quiere ejecutar en la respuesta
              this.activarModoManualEscaner();
            }
            break;
          case 'ActivarModoManualEscaner':
            // this.startScanProcess();
            // Se ejecuta función que indica que los dispositivos se chequearon con éxito ??
            break;
          default:
            break;
        }
      }
    });
  }

  failProcesador() {
    this.bcService.failProcesador();
    this.bcService.respuestaProcesador$.subscribe((response) => {
      if (response) {
        console.log(response.code);
        const code = parseInt(response.code);
        let msg = '';
        if (code === 330) {
          //modalerror2
          msg = `Comprueba conexiones del esc\u00E1ner de documentos Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              // this.errorFunction();
              // CHECAR error EN CODIGO
            } else {
              this.cancelarinfo();
            }
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 331) {
          //modalerror
          msg = `Servicio de escaneo de documentos no pudo ser iniciado.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 332) {
          //modalerror
          msg = `Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        } else if (code === 333) {
          //Si hay intentos, verifica el estatus del escáner
          if (this.intentosReiniciarEscaner < this.intentosResetEscanerDoc) {
            this.intentosReiniciarEscaner++;
            this.esReintentoEscaner = true;
            //modalerror2
            msg = `Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5`;
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.verificarEscanerDocumentos();
              } else {
                this.cancelarinfo();
              }
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          } else { //Si no hay intentos, notifica y termina flujo
            //modalerror
            msg = `Comprueba conexiones del esc\u00E1ner de documentos. Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5.`;
            this.dialogRef?.close();
            this.dialogRef = this.dialogs.showDialogErrorMensaje(msg, 'Salir');
            this.dialogRef.afterClosed().subscribe(response => {
              if (response) {
                this.errorServiciosEscaner();
              }
              ;
              try {
                this.sendLog('warning', code, msg);
              } catch (tryError) {
                // ignored
              }
            });
          }
        } else if (code === 350) {
          //modalerror
          this.dialogRef?.close();
          this.dialogRef = this.dialogs.showDialogErrorMensaje(response.message, 'Salir');
          this.dialogRef.afterClosed().subscribe(response => {
            if (response) {
              this.errorServiciosEscaner();
            }
            ;
            try {
              this.sendLog('warning', code, msg);
            } catch (tryError) {
              // ignored
            }
          });
        }
      }
    });
  }

  verificarEscanerDocumentos() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEstatusEscanerDoc", {});
    })
  }

  verificarEscanerConectadoOnline() {
    const dialogRef = this.dialogs.showDialogProcesando(MessagesDialogProcesando.capturaIdentificacion);
    dialogRef.afterClosed().subscribe(response => {
      this.controladorFunciones("VerificarEscanerConectadoOnline", {});
    })
  }

  activarModoManualEscaner() {
    this.controladorFunciones("ActivarModoManualEscaner", {});
  }

  controladorFunciones(id: string, parametrosEntrada: any) {
    const funcion = {
      Id: id,
      ParametrosEntrada: parametrosEntrada
    };
    this.bcService.procesador([funcion]); // si es necesario no invocarlo lo metemos en if de abajo
    if (!this.procesadorInvoked) {
      this.procesadorInvoked = true;
    }
  }

  errorServiciosEscaner() {
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.codigoflujo = "ELB01";
    this.getFinalDate();
  }

  /**
   * Función para error en los servicios del escaner de documentos
   * TERMINA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
   */

  failScan() {
    this.bcService.getFailScan();
    this.bcService.responseScan$.subscribe(response => {
      if (response) {
        this.onErrorEscaner(response);
      }
    });
  }

  responseScan() {

    if (this.bcService.getResponseScan() != null) {
      this.bcService.responseScan$.subscribe(response => {
        if (response) {
          if (response.Message !== 'Side A') {

          }
          this.onRespuestaEscaner(response);
        }
//        this.failScan();
      });
    }
  }

  async instructionScan() {
    await this.bcService.getInstructionScan();
    await this.bcService.instruccionesScaner$.subscribe({
      next: response => {
        if (response) {
          this.onRespuestaInstruccion(response);
        }
      }
    });
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  sendMessage(msg: string) {
    //postFinalizar(msg); no existe funcionalidad
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  // Acción del botón
  continuar() {
    if (this.scan) {
      console.log(this.instruccionPasaporte);
      this.onAbrirModalErrorSinEscaner();
      this.dialogA();
      this.instructionScan();
      this.responseScan();
    } else {
      this.escaneaFM();
    }
  }

  cancelar() {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCancelar();
    this.dialogRef.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }


  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "PaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }


}
