import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {VerificacionNoClientePasaporteComponent} from "./verificacion-no-cliente-pasaporte.component";
import {VerificacionNoClientePasaporteRoutingModule} from "./verificacion-no-cliente-pasaporte-routing.module";


@NgModule({
  declarations: [
    VerificacionNoClientePasaporteComponent,
  ],
  imports: [
    CommonModule,
    VerificacionNoClientePasaporteRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
  ],
  exports: [

  ],
  bootstrap: [VerificacionNoClientePasaporteComponent]
})
export class VerificacionNoClientePasaporteModule{}
