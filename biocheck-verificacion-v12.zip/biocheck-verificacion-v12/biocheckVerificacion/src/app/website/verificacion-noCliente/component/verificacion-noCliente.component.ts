import { Component, NgZone, OnInit } from '@angular/core';
import { MatDialogRef } from "@angular/material/dialog";
import { BiocheckService } from 'src/app/core/services/biocheck.service';
import { UtilDialogs } from 'src/app/common/util-dialogs';
import { BcstorageService } from "../../../core/services/bcstorage.service";
import { Router } from "@angular/router";
import { DialogHuellasComponent } from 'src/app/shared/dialogs/dialog-huellas/dialog-huellas.component';
import { BiocheckUtils } from 'src/app/core/services/biocheck-utils.service';

@Component({
    selector: 'app-verificacion-noCliente',
    templateUrl: './verificacion-noCliente.component.html',
})
export class VerificacionNoClienteComponent implements OnInit {
    public typeScan!: string;
    imgDosManos = 'assets/img/dos_manos.png';
    imgINE = 'assets/img/credencial.png';
    img_logo = 'assets/img/logo.png';
    public cargaCompleta: boolean = true;
    public direccion: string = '';
    public respuestaInstruccion: any;
    public errorGeneral!: boolean;
    tituloInstruccion: string = '';
    versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
    versionInstalador = this.storageService.bcStorage.versionSistema;  //Version anterior que se encuentra en el MSI
    public verCancelar: boolean = true;//Muestra u oculta el boton cancelar
    public verVerificar: boolean = true;//Muestra u oculta el boton de verificar
    public urlref: string | undefined;
    public dialogGen: MatDialogRef<any, any> | undefined;
    public dialogRef: MatDialogRef<DialogHuellasComponent, any> | undefined;
    public direccionCorreo: string | undefined;
    public idImg?: string;

    constructor(
        private storageService: BcstorageService,
        private bcService: BiocheckService,
        private dialogs: UtilDialogs,
        private router: Router,
        private Utils: BiocheckUtils,
        private zone: NgZone,
    ) {

    }

    ngOnInit(): void {
        this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;//version anterior de MSI Variable de version comercial
        this.versionInstalador = this.storageService.bcStorage.versionSistema;
        this.iniciarVista();
    }

    iniciarVista() {
        this.Utils.totalPasos(4);
        this.Utils.cambiarPaso(1, "Aviso de privacidad");
    }

    public cancelar() {
        this.Utils.cancelar();
    }

    public iniciar() {
        var path = "escaner-ine";
        this.zone.run(() => {
            this.router.navigateByUrl(`/${path}`);
        });
    };

}
