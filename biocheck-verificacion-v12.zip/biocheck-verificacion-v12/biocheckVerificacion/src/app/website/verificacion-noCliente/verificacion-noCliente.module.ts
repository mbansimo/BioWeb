import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'src/app/material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';

import { VerificacionNoClienteRoutingModule } from './verificacion-noCliente-routing.module';
import { VerificacionNoClienteComponent } from '../verificacion-noCliente/component/verificacion-noCliente.component';
import { TooltipModule } from "../tooltip/tooltip.module";


@NgModule({
    declarations: [
        VerificacionNoClienteComponent,
    ],
    imports: [
        CommonModule,
        VerificacionNoClienteRoutingModule,
        TooltipModule
    ],

    bootstrap: [VerificacionNoClienteComponent]
})
export class VerificacionNoClienteModule { }
