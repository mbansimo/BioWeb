import {RouterModule, Routes} from "@angular/router";
import {VerificacionSimpleComponent} from "./verificacion-simple.component";
import {NgModule} from "@angular/core";


const routes: Routes = [
  {path: '', component: VerificacionSimpleComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VerificacionSimpleRoutingModule{

}


