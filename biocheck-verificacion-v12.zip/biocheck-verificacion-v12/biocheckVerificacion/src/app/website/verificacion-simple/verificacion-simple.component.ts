import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {BcstorageService} from "../../core/services/bcstorage.service";
import {DataDialogModel} from "../../core/models/msg-dialog.model";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import * as $ from "jquery";
import {UtilDialogs} from 'src/app/common/util-dialogs';
import {BiocheckService} from 'src/app/core/services/biocheck.service';
import {FinalDateModel} from "../../core/models/final-date.model";
import {Router} from "@angular/router";
import {MessagesDialogProcesando} from "../../common/msgs-dialog";
import {BiocheckErrorService} from "../../core/services/biocheck.error.service";


@Component({
  selector: 'app-verificacion-simple',
  templateUrl: './verificacion-simple.component.html',
  styleUrls: ['./verificacion-simple.component.scss']
})
export class VerificacionSimpleComponent implements OnInit, OnDestroy {

  public img_logo = 'assets/img/logo.png';
  public tituloInstruccion: string | undefined = "Verificar pulgar";
  public versionBiocheck: string | undefined = 'v1.4.6';  //version anterior que se encuentran en el MSI  Variable de version comercial
  public versionInstalador: string | undefined = "v3.2.2.5";  //Version anterior que se encuentra en el MSI
  public previewIni = '';
  public dedoSelecIni = '';
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public dedoSelec = $('#dedoSelec');//Imagen de la huella seleccionada
  public intentosCapturaHuella: number = 3; //Intentos para capturar la huella

  public iscapturing: boolean = false;
  public btnVerificar: boolean = false;
  public verCancelar: boolean = true;//Muestra u oculta el boton cancelar
  public verVerificar: boolean = true;//Muestra u oculta el boton de verificar
//  public instruccion: string = ''; //Instruccion que se mostrara en la cabecera y modal cambia a tituloInstruccion
  public intentosVerificar: number = 3; //Intentos para verificar la huella


  public guid: string = ''; // Se envia al servicio
  public dedos: any[] = []; //Lista de dedos enrolados
  public dedosManoDerechaPrincipales: any[] = []; //Dedos disponibles para la mano derecha principales
  public dedosManoIzquierdaPrincipales: any[] = [];//Dedos disponibles para la mano izquierda principales
  public dedosManoDerechaOpcional: any[] = []; //Dedos disponibles para la mano derecha opcionales
  public dedosManoIzquierdaOpcional: any[] = [];//Dedos disponibles para la mano izquierda opcionales
  // bcstorage.esEjecutivo = getParameterByName('isPreVerif') == "true"; //Indica si se está realizando una preverificación
  public mano: number = 0; //1)mano derecha 2)Mano izquierda 0)Mano sin definir
  public dedoEnviar = this.storageService.bcStorage.dedoEnviar; //Es el dedo que enviaremos a verificar
  public arrayIntentoHuellas: any[] = [];

  //Elementos del DOM
//public versionInstalador: string = '';
  public statusCaptura = $('#statusCaptura');//Captura exitosa  o no exitosa

  public marcoHuella = $('.marcoHuella');//Marco que cambia de color dependiendo la captura
  public procesando: string = 'Captura huellas';  //Modal de procesando

  public fingerCapturesCount: number = 0;

  public urlref: string | undefined;

  public dialogGen: MatDialogRef<any, any> | undefined;


  constructor(
    private storageService: BcstorageService,
    public dialogRef: MatDialogRef<VerificacionSimpleComponent>,
    private bcService: BiocheckService,
    private dialogs: UtilDialogs,
    private router: Router,
    private biocheckError: BiocheckErrorService,
    @Inject(MAT_DIALOG_DATA) public data: DataDialogModel,
  ) {
  }

  ngOnInit(): void {
    this.dedosActivos();
    this.imagenesIniciales();
    this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
    this.versionInstalador = this.storageService.bcStorage.versionSistema;
    console.log('lleva la instalacion: ' + this.versionInstalador + ' Versiones ' + this.storageService.bcStorage.versionBiocheck);
  }


  ngOnDestroy() {
    console.log('Observables Cerrados Verificación Simple');
     this.bcService.showPreviewObjectUnsuscribe();
//     this.bcService.loadingObjectUnsuscribe();
//     this.bcService.failBuroRespuestaUnsubscribe();
//     this.bcService.successVerifyObjectUnsuscribe();
//     this.bcService.verifyResponseObjectUnsuscribe();
    // this.bcService.fingerChancesSubjectUnsuscribe();
//    this.bcService.transactionID();

  }

  dedosActivos() {
    console.log('Cargamos dedosActivos en inicio.');
    // @ts-ignore
    for (var x = 0; x < this.storageService.bcStorage.dedosAvtivos.length; x++) {
      this.dedos.push(this.storageService.bcStorage.dedosAvtivos?.[x])
    }
  }

  public imagenesIniciales() {
    this.btnVerificar = true;
    this.tituloInstruccion = this.storageService.bcStorage.tituloInstruccion;
    if (this.storageService.bcStorage.numeroDeIntentosHuella != null) {
      this.intentosCapturaHuella = this.storageService.bcStorage.numeroDeIntentosHuella;
    }
    if (this.storageService.bcStorage.dedoInicial != null) {
      console.log("dedo enviado ::::::::" + this.dedoEnviar);
      this.preview.attr('src', 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png');
      this.preview.addClass('std-opacidad-huella');
      this.dedoSelec.attr('src', 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png');
      this.previewIni = this.storageService.bcStorage.dedoInicial;
      this.dedoSelecIni = this.storageService.bcStorage.dedoInicial;
    }
  }


  public error(codigo: any) {
    this.flujoRespuestaVerify = false;
    this.storageService.bcStorage.proceso = false;
    this.storageService.bcStorage.apicNombre = "";
    this.storageService.bcStorage.apicApellidoP = "";
    this.storageService.bcStorage.apicApellidoM = "";
    this.storageService.bcStorage.codigoflujo = codigo;
    this.getFinalDate();
  } // Caen los errores en verificacion


  //Funciones para dedos
  public valorMaximo(arrayDedos: any) {
    return Math.max.apply(null, arrayDedos);
  } //Nos da el valor maximo de un array

  public valorMinimo(arrayDedos: any) {
    return Math.max.apply(null, arrayDedos);
  }//Nos da el valor minimo de un array


  public aleatorio(min: any, max: any) {
    return Math.round(Math.random() * (max - min) + min);
  }

  public eliminarDedo(dedoEliminar: any) {
    console.log("dedos::" + this.dedos);
    if (this.dedos.length !== 1) {
      for (var i = 0; i < this.dedos.length; i++) {
        if (this.dedos[i] == dedoEliminar) {
          this.dedos.splice(i, 1);
        }
      }
    }
  }//Eliminamos el dedo del array de dedos

  //botones
  public verificar() {
    this.btnVerificar = false;
    this.addFingerVerify();
    this.eliminarDedo(this.dedoEnviar);
    this.storageService.bcStorage.dedosAvtivos = this.dedos;
    console.log("quedo::" + this.dedos);
    this.verCancelar = false;
    this.verVerificar = false;
  };

  cancelar() {
    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        //this.storageService.bcStorage.proceso = false;
        this.errorFunction('CA000', 'Se cancelo el proceso.');
      }
    });
  }

  public addFingerVerify() {
    this.bcService.AddFingerVerify([this.guid, this.dedoEnviar]);
    this.bcService.getshowPreview();
    this.bcService.showPreviewRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          $("#preview").css("opacity", "1");
          var img = document.getElementById("preview") as HTMLImageElement;
          img.src = "data:image/png;base64," + response;
          this.preview.attr('src', 'data:image/png;base64,' + response);

        } else {
          this.failBuro();
        }
      }
    });

    this.bcService.getloading();
    this.bcService.loadingRespuesta$.subscribe({
      next: (response: any) => {
        if (response == undefined) {
          this.loading();
        } else {
          this.failBuro();
        }
      }
    });
  }


  prueba() {
    console.log("Timeout success");
  }

  failBuro() {
    console.log('ingreso a failburo');
    this.bcService.getfailBuro();
    this.bcService.failBuroRespuesta$.subscribe({
      next: (response: any) => {
        if (response) {
          this.respuestaNosepuedeCapturar(response);
        } else {

        }
      }
    });
  }

  respuestaNosepuedeCapturar(response: any) {
    this.statusCapturaNoExitosa();
    setTimeout(() => {
      this.cerrarModal();
      var message = '';
      var btnlbl = '';
      const code = parseInt(response.Code);

      switch (code) {
        case 270:
          message = 'No se pudo capturar dedo';
          btnlbl = 'Repetir'
          this.storageService.bcStorage.codigoImagenFlujo = 'LS001';
          this.dialogGen = this.dialogs.showDialogErrorMensajeDos(message, btnlbl);
          this.dialogGen.afterClosed().subscribe(response => {
            if (response) {
              this.bcService.failBuroRespuestaUnsubscribe();
              this.statusRecargarValores();
              this.consultasVerificar(code)
            } //else {
            // this.errorFunction('CA000', 'Proceso cancelado');
            //}
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", message];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });

          break;
        case 300:
          message = 'Comprueba conexiones del esc\u00E1ner de huellas Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5';
          btnlbl = 'Cancelar';
//          biocheck.errorModal("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/lector_conexion.png'></div>", 'Reintentar', function () {
//            consultasVerificar()
//          }, 'Cancelar' + ":ErrorCode:CA000", function () {
//            error('CA000')
//          });
          break;
        case 200:

          message = 'El tiempo para realizar la captura se ha excedido, por favor repítela';
          btnlbl = 'Repetir';
          this.dialogGen = this.dialogs.showDialogErrorMensajeDos(message, btnlbl);
          this.dialogGen.afterClosed().subscribe(response => {
            if (response) {
              this.bcService.transactionID();
              this.bcService.failBuroRespuestaUnsubscribe();
              this.statusRecargarValores();
              this.storageService.bcStorage.repetirProceso = "simple";
              this.storageService.bcStorage.codigoflujo = "time_out_huella";
              this.consultasVerificar("time_out_huella");
            } //else {
            // this.errorFunction('CA000', 'Proceso cancelado');
            //}
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", message];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });


//          biocheck.errorModal('El tiempo para realizar la captura</br> se ha excedido, por favor repítela', 'Repetir', function () {
//            consultasVerificar("time_out_huella")
//          });
          break;
        case 280:
          message = 'Indica al cliente que la captura ha excedido el número de intentos que no es posible concluir el proceso de verificación y tendrá que hacerlo en otra visita a sucursal. Agradece su tiempo.';
          btnlbl = 'Salir';
          this.bcService.failBuroRespuestaUnsubscribe();
          this.dialogGen = this.dialogs.showDialogErrorMensaje(message, btnlbl);
          this.dialogGen.afterClosed().subscribe(response => {
            if (response) {
              this.error('EOB00');
            }
            ;
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", message];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });
          break;
        default:
          message = 'Ocurrió un error inesperado en la captura de huellas';
          btnlbl = 'Repetir';
          this.storageService.bcStorage.codigoImagenFlujo = 'E0001';
          this.dialogGen = this.dialogs.showDialogErrorMensajeDos(message, btnlbl);
          this.dialogGen.afterClosed().subscribe(response => {
            if (response) {
              this.bcService.failBuroRespuestaUnsubscribe();
              this.storageService.bcStorage.repetirProceso = "simple";
              this.consultasVerificar("");
            } //else {
            // this.errorFunction('CA000', 'Proceso cancelado');
            //}
            try {
              const params = ["warning", "PaaS [" + window.location.href + "]", message];
              this.bcService.invokeEscribeLog(params);
            } catch (tryError) {
              // ignored
            }
          });


//          biocheck.errorModal('Ocurrió un error inesperado en la captura de huellas', 'Repetir', function () {
//            consultasVerificar()
//          });
          break;
      }
    }, 2000);
  }


  loading() {
    this.fingerCapturesCount += 1;
    this.statusCapturaExitoso();
    if (this.intentosCapturaHuella==3){
      this.dialogGen = this.dialogs.showDialogProcesando(MessagesDialogProcesando.cargandoDatos);
    }
    this.successVerify();
//    setTimeout(this.prueba, 2000);
  }

  successVerify() {

    this.bcService.evaluateVerify();
    this.bcService.getevaluateVerify();
    console.log("ingreso a succes verify -----");
    this.bcService.successVerify$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('ingreso a verify..');
          this.verify();
        } else {
//          this.failProcesador();  TODO: Falta agregar este metodo de failProcesador
        }
      }
    });
    this.verify();
  }


  verify() {
    this.bcService.verify();
    this.bcService.getverifyResponse();
    this.bcService.verifyResponse$.subscribe({
      next: (response: any) => {
        if (response) {
          console.log('respuesta respuestaVerify');
          if (this.flujoRespuestaVerify){
            this.respuestaVerify(response);
          }
        } else {
//          this.failProcesador();  TODO: Falta agregar este metodo de failProcesador
        }
      }
    });
  }

public flujoRespuestaVerify: boolean = true;
  respuestaVerify(response: any) {
    this.dialogRef?.close()
    console.log(response);
    if (response.code == 0) {
      if (response.result) {

        if (response.result.code === "OK0000") {
          this.storageService.bcStorage.proceso = true;
          this.storageService.bcStorage.codigoflujo = response.result.code;
          this.storageService.bcStorage.mensajeflujo = response.result.message;
          this.storageService.bcStorage.hash = response.result.fingerHash;
          this.getFinalDate();
        }//Respuesta exitosa (Se debe direccionar a la pantalla finalizar)
        else {
          //------------------------------------------INTENTOS------------------------------//
          if (this.intentosVerificar > 1) {
            console.log('verificacion no exitosa')
            this.intentosVerificar--;
//            this.eraseBiometricsVerify();
            this.bcService.transactionID();
            this.cerrarModal();
            var msg = 'Verificación no exitosa. Tiene ' + this.intentosVerificar + ' intentos más.';
            this.storageService.bcStorage.codigoImagenFlujo = 'LS001'; // sin imagen.
            this.dialogGen = this.dialogs.showDialogErrorMensajeDos(msg, 'Repetir');
            this.dialogGen.afterClosed().subscribe(response => {
              console.log('regreso del dialog' + response);
              if (response) {

                this.statusRecargarValores();
                this.consultasVerificar("");
              }
              try {
                const params = ["warning", "PaaS [" + window.location.href + "]", msg];
                this.bcService.invokeEscribeLog(params);
              } catch (tryError) {
                // ignored
              }
            });

//consultasVerificar();
          }//Reintentas verificar
          else {
            this.flujoRespuestaVerify = false;
            this.storageService.bcStorage.mensajeflujo = response.result.message;
            this.storageService.bcStorage.hash = response.result.fingerHash;
            this.error(response.result.code);
          }//Se acabaron los intentos de verificación simple (Se debe direccionar a la pantalla finalizar)
        }
      }
    } else {
      switch (response.code) {
        case 400:
          var obj = JSON.parse(response.message);
          var objError = obj.errores || obj.errors;
          if (objError) {
            if (objError.length > 0) {
              this.storageService.bcStorage.mensajeflujo = obj.errores[0].message;
              this.storageService.bcStorage.mensajeinternoflujo = obj.errores[0].description;
              this.error(objError[0].code);
            }
          } else {
            this.error('EVB02');
          }
          break;
        case 404:
          this.error('EVB02');
          break;
        default:
          this.error('EVB00');
          break;
      }
    }
  }

  regresarValores() {
    console.log('unsuscribe valores');
    this.bcService.showPreviewObjectUnsuscribe();
    this.bcService.verifyResponseObjectUnsuscribe();
    this.statusCapturaInicial();
  }

  public consultasVerificar(codigo: any) {
    switch (codigo) {
      case "time_out_huella":
        //biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "error", "time_out_huella", "repetir", ""); TODO: evento log al parecer
        break;
      case "no_identifica_huella":
        //      biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "error", "no_identifica_huella", "repetir", "");
        break;

    }
    this.bcService.fingerChancesVerify();
    this.fingerChances();
  }

  fingerChances() {
    this.intentosCapturaHuella--;
    this.storageService.bcStorage.numeroDeIntentosHuella = this.intentosCapturaHuella;
    console.log('actualizacion de intentos de captura' + this.intentosCapturaHuella)

    this.bcService.getfingerChances();
    this.bcService.fingerChances$.subscribe(response => {
      console.log('intentos otorgado: ' + response);
      if (response != null && response != "" && response != undefined) {
        this.intentosCapturaHuella = response;
        this.respuestaFingerChances(this.intentosCapturaHuella);
      } else {
        console.log('Else respuesta finger');
        this.respuestaFingerChances(this.intentosCapturaHuella);
      }
    });
  }

  respuestaFingerChances(intentos: any) {
    console.log('Ingreso a respuestaFingerChance...' + intentos);
    this.cerrarModal();
    this.intentosCapturaHuella = intentos;
    if (intentos > 0) {
      this.iscapturing = true;
      this.flujoVerificacion();
    } else {
      this.storageService.bcStorage.codigoflujo = 'EOB00';
      let msj = 'Indica al cliente que la captura ha excedido el número de intentos que no es posible concluir el proceso de verificación y tendrá que hacerlo en otra visita a sucursal. Agradece su tiempo.';
      this.dialogGen = this.dialogs.showDialogErrorMensajeDos(msj, 'Salir');
      this.dialogGen.afterClosed().subscribe(response => {
        this.responseDialogErrorMsg(response, msj);
      });
    }
    //$scope.$applyAsync();
  }

  flujoVerificacion() {
    console.log('ingreso a flujo de verificacion..')
    this.mostrarVista();
  }

  public mostrarVista() {
    console.log('se invoco metodo de mostrarVista')
    if (this.storageService.bcStorage.esEjecutivo) {
//      biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "pageView"); TODO:Faltante de ver si se ocupa
    }
    this.dedoEnviar = this.dedoCapturar();
    if (this.dedoEnviar != 0) {
      this.statusCapturaInicial();
      console.log(this.dedoEnviar);
      this.storageService.bcStorage.dedoEnviar = this.dedoEnviar;
      this.storageService.bcStorage.dedoInicial = 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png';
      this.preview.attr('src', 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png');
      this.preview.addClass('std-opacidad-huella');
      this.dedoSelec.attr('src', 'assets/img/combinaciones/numeroDedos/' + this.dedoEnviar + '.png');
      this.tituloInstruccion = this.instruccion(parseInt(String(this.dedoEnviar)));
      this.storageService.bcStorage.tituloInstruccion = this.tituloInstruccion;
      if (this.storageService.bcStorage.esEjecutivo) {
        //Le agregamos a la instrucción para indicar que es el dedo del ejecutivo en preverificación
        this.tituloInstruccion += " del ejecutivo";
      }
      // MXSLBIOM-2750 Se ocultan los botones cuando es ejecutivo
      this.verVerificar = !this.storageService.bcStorage.esEjecutivo;
      this.verCancelar = !this.storageService.bcStorage.esEjecutivo;
      this.cerrarModal();
      this.abrirCapturarHuella();
//      $scope.$applyAsync();  TODO: ver para que sirve
      if (this.storageService.bcStorage.esEjecutivo) {
        // MXSLBIOM-2750 Si es ejecutivo, arranca de inmediato el proceso de captura de huellas
        this.verificar();
      }
    } else {
//      biocheck.errorModal('El cliente no cuenta con dedos para verificar', "Salir" + ":ErrorCode:ClienteNoHuellas", '');
    }
//    $scope.$applyAsync();   TODO: saber si se utiliza esta parte
  }

  public abrirCapturarHuella() {
    this.dialogRef = this.dialogs.showDialogVerificacionSimple();
    // this.dialogGen?.afterClosed().subscribe(response => {
    //   if (response) {
    //     console.log('ingreso en este if de abrir captura')
    //     this.procesandoFlujo();
    //   }
    // })
//    $('#modalSolicitaHuella').modal('show'); TODO: esto se utiliza
  }

  procesandoFlujo() {
    if (this.storageService.bcStorage.repetirProceso == "simple") {
      this.consultasVerificar(this.storageService.bcStorage.codigoflujo);
    } else {

    }
  }

  public dedoCapturar() {
    this.asignarDedosManos();
    let dedo;
    switch (this.intentosCapturaHuella) {
      case 2:
        this.mano = this.aleatorio(1, 2);//Asignamos la mano aleatoria
        switch (this.mano) {
          case 1:
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              dedo = this.dedosManoIzquierdaPrincipales[this.aleatorio(0, this.dedosManoIzquierdaPrincipales.length - 1)];
            } else {
              if (this.dedosManoIzquierdaOpcional.length != 0) {
                dedo = this.dedosManoIzquierdaOpcional[this.aleatorio(0, this.dedosManoIzquierdaOpcional.length - 1)];
              } else {
                if (this.dedosManoDerechaPrincipales.length != 0) {
                  dedo = this.dedosManoDerechaPrincipales[this.aleatorio(0, this.dedosManoDerechaPrincipales.length - 1)];
                } else {
                  if (this.dedosManoDerechaOpcional.length != 0) {
                    dedo = this.dedosManoDerechaOpcional[this.aleatorio(0, this.dedosManoDerechaOpcional.length - 1)];
                  } else {
                    dedo = 0;
                  }
                }
              }
            }
            break;
          case 2:
            if (this.dedosManoDerechaPrincipales.length != 0) {
              dedo = this.dedosManoDerechaPrincipales[this.aleatorio(0, this.dedosManoDerechaPrincipales.length - 1)];
            } else {
              if (this.dedosManoDerechaOpcional.length != 0) {
                dedo = this.dedosManoDerechaOpcional[this.aleatorio(0, this.dedosManoDerechaOpcional.length - 1)];
              } else {
                if (this.dedosManoIzquierdaPrincipales.length != 0) {
                  dedo = this.dedosManoIzquierdaPrincipales[this.aleatorio(0, this.dedosManoIzquierdaPrincipales.length - 1)];
                } else {
                  if (this.dedosManoIzquierdaOpcional.length != 0) {
                    dedo = this.dedosManoIzquierdaOpcional[this.aleatorio(0, this.dedosManoIzquierdaOpcional.length - 1)];
                  } else {
                    dedo = 0;
                  }
                }
              }
            }
            break;
          case 3:
            dedo = this.dedos[0];
            break;
          default:
            dedo = 0;//No tiene ni un dedo disponible para verificar
            break;
        }
        break;
      case 1:
      case 3:
      default:
        if (this.dedos.length == 1) {
          this.mano = 3; //Solo tiene una huella
        } else {
          if (this.dedosManoDerechaPrincipales.length != 0) {
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              this.mano = this.aleatorio(1, 2);//Asignamos la mano aleatoria
            } else {
              this.mano = 1;
            }
          } else {
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              this.mano = 2;
            } else {
              if (this.dedosManoDerechaOpcional.length != 0) {
                if (this.dedosManoIzquierdaOpcional.length != 0) {
                  this.mano = this.aleatorio(1, 2);//Asignamos la mano aleatoria
                } else {
                  this.mano = 1;
                }
              } else {
                if (this.dedosManoIzquierdaOpcional.length != 0) {
                  this.mano = 2;//Asignamos la mano aleatoria
                } else {
                  this.mano = 0;
                }
              }
            }
          } //Revisamos que mano tiene
        }
        switch (this.mano) {
          case 1:
            if (this.dedosManoDerechaPrincipales.length != 0) {
              dedo = this.dedosManoDerechaPrincipales[this.aleatorio(0, this.dedosManoDerechaPrincipales.length - 1)];
            } else {
              dedo = this.dedosManoDerechaOpcional[this.aleatorio(0, this.dedosManoDerechaOpcional.length - 1)];
            }
            break;
          case 2:
            if (this.dedosManoIzquierdaPrincipales.length != 0) {
              dedo = this.dedosManoIzquierdaPrincipales[this.aleatorio(0, this.dedosManoIzquierdaPrincipales.length - 1)];
            } else {
              dedo = this.dedosManoIzquierdaOpcional[this.aleatorio(0, this.dedosManoIzquierdaOpcional.length - 1)];
            }
            break;
          case 3:
            dedo = this.dedos[0];
            break;
          default:
            dedo = 0;//No tiene ni un dedo disponible para verificar
            break;
        }
        break;
    }
    return dedo;
  }//Devulve el dedo que debe capturar

  public instruccion(dedoEnviar: number) {
    var respuesta = '';
    switch (dedoEnviar) {
      case 1:
        respuesta = 'pulgar derecho';
        break;
      case 2:
        respuesta = 'índice derecho';
        break;
      case 3:
        respuesta = 'medio derecho';
        break;
      case 4:
        respuesta = 'anular derecho';
        break;
      case 5:
        respuesta = 'meñique derecho';
        break;
      case 6:
        respuesta = 'pulgar izquierdo';
        break;
      case 7:
        respuesta = 'índice izquierdo';
        break;
      case 8:
        respuesta = 'medio izquierdo';
        break;
      case 9:
        respuesta = 'anular izquierdo';
        break;
      case 10:
        respuesta = 'meñique izquierdo';
        break;
      default:
        respuesta = 'índice derecho';
        break;
    }
    return respuesta;
  }

  public asignarDedosManos() {
    console.log('asignar dedos ...')
    this.dedosManoDerechaPrincipales = [];
    this.dedosManoIzquierdaPrincipales = [];
    this.dedosManoDerechaOpcional = [];
    this.dedosManoIzquierdaOpcional = [];
    for (var i = 0; i < this.dedos.length; i++) {
      switch (this.dedos[i]) {
        case 1:
        case 2:
        case 3:
          this.dedosManoDerechaPrincipales.push(this.dedos[i]);
          break;
        case 4:
        case 5:
          this.dedosManoDerechaOpcional.push(this.dedos[i])
          break;
        default:
          break;
      }
    }//Mano derecha
    for (var i = 0; i < this.dedos.length; i++) {
      switch (this.dedos[i]) {
        case 6:
        case 7:
        case 8:
          this.dedosManoIzquierdaPrincipales.push(this.dedos[i]);
          break;
        case 9:
        case 10:
          this.dedosManoIzquierdaOpcional.push(this.dedos[i]);
          break;
        default:
          break;
      }
    }//Mano izquierda
  }//Guardamos los dedos disponibles en cada mano

  public estatusCaptura = '';

  statusCapturaNoExitosa() {
    $('#statusCaptura').css('color', '#ec0000');
    $('#statusCaptura').css('visibility', 'visible');
    $('.marcoHuella').css('border-color', '#EC0000');
    this.estatusCaptura = 'Captura no exitosa';
    this.marcoHuella.addClass('border-red');
    this.statusCaptura.text('Captura no exitosa');
    this.statusCaptura.css('color', '#ec0000');
    this.statusCaptura.css('visibility', 'visible');
    if (this.storageService.bcStorage.esEjecutivo) {
      this.arrayIntentoHuellas.push("fracaso");
      //biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "verificacion_ejecutivo", "error_verificacion_" + instruccion($scope.dedoEnviar).replace(/\s/g, "_"), "captura_no_exitosa");
    }
  }

  public statusCapturaInicial() {
    $('#statusCaptura').css('visibility', 'hidden');
    let marcoHuella = $("#marcoHuella");
    marcoHuella.addClass('border-gris');
    marcoHuella.removeClass('border-red');
    marcoHuella.removeClass('border-green');
    let statusCaptura = $("#statusCaptura")
    statusCaptura.text('Captura no exitosa');
    statusCaptura.css('color', '#000');
    statusCaptura.css('visibility', 'hidden');
    this.preview.addClass("std-opacidad-huella");
  }//Cambios visuales iniciales de huellas

  public dedoImg = '';

  public statusRecargarValores(){
    this.statusCapturaInicial();
    this.bcService.borradoShowPreview();

  }


  public statusCapturaExitoso() {
    $('#statusCaptura').css('visibility', 'visible');
    this.estatusCaptura = "Huellas Capturadas";
    $('.marcoHuella').css('border-color', '#63BA68');
    $('#marcoHuella').addClass('border-green');
    if (this.storageService.bcStorage.esEjecutivo) {
      this.arrayIntentoHuellas.push("exitoso");
      var arrayAdicional = [];
      arrayAdicional.push({key: "IntentoDeHuellas", value: this.arrayIntentoHuellas});
      //biocheck.sendGtmTag("Paso-1", "Enrolamiento", "Pre-Verificacion", "biocheck", "verificacion_ejecutivo", "correcto_verificacion_" + instruccion($scope.dedoEnviar).replace(/\s/g, "_"), "captura_exitosa", arrayAdicional, true);
    }
  } //Cambios visuales cuando la captura de huella fue exitosa


  responseDialogErrorMsg(response: boolean, message: string) {
    if (response) {
      if (this.storageService.bcStorage.codigoflujo != null) {
        this.error(this.storageService.bcStorage.codigoflujo)
      }
    }
    ;
    try {
      const params = ["warning", "PaaS [" + window.location.href + "]", message];
      this.bcService.invokeEscribeLog(params);
    } catch (tryError) {
      // ignored
    }
  }

  //Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  // invocamos GetFinalDate y nos suscribimos para obtener la fecha final
  getFinalDate() {
    this.cerrarModal();
    this.bcService.getFinalDate();
    this.bcService.getfinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    console.log('ingreso a onFinalDato');
    this.router.navigateByUrl('/finalizar');
  }

  finalDate(response: any) {
    this.storageService.bcStorage.fechapros = response.fecha;
    this.storageService.bcStorage.horapros = response.hora;
    this.storageService.bcStorage.foliopros = response.trasaction;
    var valorError = this.storageService.bcStorage.codigoflujo == undefined ? "" : this.storageService.bcStorage.codigoflujo;
    var codigoError = this.biocheckError.codigoError(valorError)
    if (codigoError != '0')
      this.storageService.bcStorage.mensajeflujo = codigoError;
    this.bcService.onStopSignalR();
    this.router.navigateByUrl('/finalizar');
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  sendMessage(msg: string) {
    this.router.navigateByUrl('/finalizar');
    //postFinalizar(msg); no existe funcionalidad
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  public cerrarModal() {
    this.dialogGen?.close();
    this.dialogRef?.close();

  }


  //Invocacion de servicios


}
