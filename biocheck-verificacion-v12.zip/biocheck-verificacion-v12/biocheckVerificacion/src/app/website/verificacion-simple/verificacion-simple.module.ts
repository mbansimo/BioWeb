import {NgModule} from "@angular/core";
import {VerificacionSimpleComponent} from "./verificacion-simple.component";
import {MaterialModule} from "../../material/material.module";
import {SharedModule} from "../../shared/shared.module";
import {MatTooltipModule} from "@angular/material/tooltip";
import {MatButtonModule} from "@angular/material/button";
import {DialogsModule} from "../../shared/dialogs/dialogs.module";
import {CommonModule} from "@angular/common";
import {VerificacionSimpleRoutingModule} from "./verificacion-simple-routing.module";


@NgModule({
  declarations: [
    VerificacionSimpleComponent
  ],
  imports: [
    CommonModule,
    VerificacionSimpleRoutingModule,
    MaterialModule,
    SharedModule,
    MatTooltipModule,
    MatButtonModule,
    DialogsModule,
  ],
  exports:[],
  bootstrap:[VerificacionSimpleComponent]
})
export class VerificacionSimpleModule{}

