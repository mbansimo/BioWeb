import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerificacionVentanillaComponent } from './verificacion-ventanilla.component';

describe('VerificacionVentanillaComponent', () => {
  let component: VerificacionVentanillaComponent;
  let fixture: ComponentFixture<VerificacionVentanillaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerificacionVentanillaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VerificacionVentanillaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
