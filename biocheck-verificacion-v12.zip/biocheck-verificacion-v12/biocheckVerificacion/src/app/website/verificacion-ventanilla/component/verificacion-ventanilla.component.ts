import { Component, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { BiocheckService } from 'src/app/core/services/biocheck.service';
import { FinalDateModel } from "../../../core/models/final-date.model";
import { UtilDialogs } from 'src/app/common/util-dialogs';
import { BcstorageService } from "../../../core/services/bcstorage.service";
import { Router } from "@angular/router";
import * as $ from "jquery";
import { DialogHuellasComponent } from 'src/app/shared/dialogs/dialog-huellas/dialog-huellas.component';
import { DataEditableModel } from "../../../core/models/dataTable.model";
import { BiocheckUtils } from 'src/app/core/services/biocheck-utils.service';

@Component({
  selector: 'app-verificacion-ventanilla',
  templateUrl: './verificacion-ventanilla.component.html',
  styleUrls: ['./verificacion-ventanilla.component.css']
})
export class VerificacionVentanillaComponent implements OnInit {

  public ToolTipOCR: string = 'Son 13 dígitos después de las letras.';
  public headerVista = '1. Identificación del cliente.';
  //public headerInstrucciones = 'Selecciona el tipo de identificación.';
  public nombreCliente?: string;
  public IFE = 'IFE';
  public INE = 'INE';
  public imgIFE = 'assets/img/ifeEscanear.png';
  public imgINE = 'assets/img/INE.png';
  public btnCancelar = 'Cancelar';
  public btnValidar = 'Verificar';
  public imgHelp = "assets/img/ayuda.svg";
  public IdFlujo: number = 0;

  public TipoIdentificacion?: string;
  public msjclaveElector = "";
  public msjocr?: string;
  public msjCic: string = "";
  public msjAnioRegister: string = "";
  public msjAnioemision: string = "";
  public msjEmision?: string;
  public Curp = "";

  img_logo = 'assets/img/logo.png';
  tituloInstruccion: string = '';
  versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
  versionInstalador = this.storageService.bcStorage.versionSistema;  //Version anterior que se encuentra en el MSI

  public verCancelar: boolean = true;//Muestra u oculta el boton cancelar
  public verVerificar: boolean = true;//Muestra u oculta el boton de verificar
  //  public instruccion: string = ''; //Instruccion que se mostrara en la cabecera y modal cambia a tituloInstruccion
  public intentosCapturaHuella: number = 3; //Intentos para capturar la huella
  public intentosVerificar: number = 3; //Intentos para verificar la huella


  public guid: string = ''; // Se envia al servicio
  public dedos: any[] = []; //Lista de dedos enrolados
  public dedosManoDerechaPrincipales: any[] = []; //Dedos disponibles para la mano derecha principales
  public dedosManoIzquierdaPrincipales: any[] = [];//Dedos disponibles para la mano izquierda principales
  public dedosManoDerechaOpcional: any[] = []; //Dedos disponibles para la mano derecha opcionales
  public dedosManoIzquierdaOpcional: any[] = [];//Dedos disponibles para la mano izquierda opcionales
  // bcstorage.esEjecutivo = getParameterByName('isPreVerif') == "true"; //Indica si se está realizando una preverificación
  public mano: number = 0; //1)mano derecha 2)Mano izquierda 0)Mano sin definir
  public dedoEnviar: number = 0; //Es el dedo que enviaremos a verificar
  public arrayIntentoHuellas: any[] = [];

  //Elementos del DOM
  //public versionInstalador: string = '';
  public statusCaptura: string = '';  //Captura exitosa  o no exitosa

  public marcoHuella = $('.marcoHuella');//Marco que cambia de color dependiendo la captura
  public procesando: string = 'Captura huellas';  //Modal de procesando
  public preview = $('#preview'); //Imagen donde se imprimira la huella
  public dedoSelec = $('#dedoSelec');//Imagen de la huella seleccionada

  public urlref: string | undefined;

  public dialogGen: MatDialogRef<any, any> | undefined;
  public dialogRef: MatDialogRef<DialogHuellasComponent, any> | undefined;

  public toolTipClaveElector = "assets/img/clave.png";
  public toolTipOCR_i = 'assets/img/ocr.png';
  public toolTipEmision = 'assets/img/emision.png';
  public toolTipFechaEmision = 'assets/img/ine_emision.png';
  public toolTipFechaRegistro = 'assets/img/ine_Registro.png';
  public toolTipCIC = 'assets/img/cic.png';

  constructor(
    private storageService: BcstorageService,
    private bcService: BiocheckService,
    private dialogs: UtilDialogs,
    private router: Router,
    private Utils: BiocheckUtils,
  ) { }

  ngOnInit(): void {
    this.versionBiocheck = this.storageService.bcStorage.versionBiocheck;  //version anterior que se encuentran en el MSI  Variable de version comercial
    this.versionInstalador = this.storageService.bcStorage.versionSistema;
    this.nombreCliente = this.storageService.bcStorage.nombreCliente == undefined ? "Cliente: " : "Cliente: " + this.storageService.bcStorage.nombreCliente;
    this.iniciarVista();
  }

  iniciarCampos() {
    this.ToolTipOCR = 'Son 13 dígitos después de las letras.';
    this.OcultaCampos();
    this.msjCic = '';
    this.msjocr = '';
    this.msjEmision = '';
    this.msjclaveElector = '';
    this.msjAnioemision = '';
    this.msjAnioRegister = '';
    this.Curp = this.storageService.bcStorage.curp || '';
    this.TipoIdentificacion = "";
    $("#btnEscan").prop("disabled ", true);
  }

  OcultaCampos() {
    this.TipoIdentificacion = "";
  }

  iniciarVista() {
    this.Utils.totalPasos(2);
    this.Utils.cambiarPaso(1, "Datos identificación");//revisar
    this.iniciarCampos();
  }

  toolTipView() {
    debugger;
    this.ToolTipOCR = 'Son 13 dígitos después de las letras.';
  }

  mostrarCampos(identificacion: string) {
    this.OcultaCampos();
    $("#identificaionIFE_INE").show();
    $("#identificaionINE").show();
    this.TipoIdentificacion = identificacion;
    this.storageService.bcStorage.esINE = true;
  }

  cancelar() {
    this.dialogGen?.close();
    this.dialogGen = this.dialogs.showDialogCancelar();
    this.dialogGen.afterClosed().subscribe(response => {
      if (response) {
        this.errorFunction('CA000', 'Proceso cancelado');
      }
    });
  }

  public errorFunction(codigoError: string, mensajeLegible?: string) {
    this.storageService.bcStorage.codigoflujo = codigoError;
    if (mensajeLegible && mensajeLegible != undefined && mensajeLegible != null && mensajeLegible != "" && mensajeLegible != "undefined") {
      this.storageService.bcStorage.mensajeflujo = mensajeLegible;
    }
    codigoError === "CA000" ? this.storageService.bcStorage.proceso = true : this.storageService.bcStorage.proceso = false;
    codigoError === "CA000" ? this.storageService.bcStorage.cancel = true : this.storageService.bcStorage.cancel = false;
    this.sendLog('error', codigoError, this.storageService.bcStorage.mensajeflujo)
    this.getFinalDate();
  }

  getFinalDate() {
    this.bcService.getFinalDate();
    this.bcService.finalDate$.subscribe(response => {
      if (response) {
        this.onFinalDato(response);
      }
    });
  }

  sendLog(status: string, codigoError: string | number, msg: string | undefined) {
    const info = codigoError ? ` ${codigoError}: ${msg}` : `${msg}`;
    let paramsLog = [status, "CaaS [" + window.location.href + "]", info];
    this.bcService.invokeEscribeLog(paramsLog);
  }

  onFinalDato(data: FinalDateModel) {
    this.storageService.bcStorage.fechapros = data.fecha;
    this.storageService.bcStorage.horapros = data.hora;
    this.storageService.bcStorage.foliopros = data.trasaction;
    this.bcService.onStopSignalR();
    if (this.storageService.bcStorage.proceso) {
      this.router.navigateByUrl('/finalizar');
    } else {
      this.respuesta();
    }
  }

  respuesta() {
    let innerMessage = '';

    if (this.storageService.bcStorage.mensajeinternoflujo && this.storageService.bcStorage.mensajeinternoflujo.length > 0) {
      innerMessage = this.storageService.bcStorage.mensajeinternoflujo;
    } else if (this.storageService.bcStorage.hash) {
      innerMessage = this.storageService.bcStorage.hash;
    }

    if (this.storageService.bcStorage.mensajeflujo) {
      const dom = new DOMParser().parseFromString(this.storageService.bcStorage.mensajeflujo, "text/html");
      const cleanMessage = dom.body?.textContent?.replace((/  |\r\n|\n|\r/gm), "");
      this.storageService.bcStorage.mensajeflujo = cleanMessage;
    }

    const response = {
      message: this.storageService.bcStorage.mensajeflujo,
      innerMessage: innerMessage,
      code: this.storageService.bcStorage.codigoflujo,
      response: this.storageService.bcStorage.proceso
    };

    var responseStr = JSON.stringify(response);
    this.sendMessage('' + responseStr);
  }

  sendMessage(msg: string) {
    //postFinalizar(msg); no existe funcionalidad
  }

  public validar() {
    if (!this.validarCampos()) {
      var TipoFlujo = this.storageService.bcStorage.tipoFlujoVerificacion;
      this.storageService.bcStorage.cic = $("#CIC").val()?.toString();
      this.storageService.bcStorage.claveElector = $("#ClaveElectorINE").val()?.toString();

      var dataine = this.Utils.DataEditable(null, null, this.storageService.bcStorage.curp, this.storageService.bcStorage.ocr, null, this.storageService.bcStorage.apicNombre, this.storageService.bcStorage.apicApellidoP, this.storageService.bcStorage.apicApellidoM, this.storageService.bcStorage.claveElector, this.storageService.bcStorage.codigoEmision, this.storageService.bcStorage.cic);

      const params = [
        dataine
      ];
      this.bcService.editableData(params);
      this.bcService.geteditableDataResponse();
      this.bcService.editableDataResponseRespuesta$.subscribe(response => {
        if (response) {
          this.editableDataResponse(response);
        }
      });

      switch (TipoFlujo) {
        case 3:
          //   this.bcService.onStopSignalR();
          this.dialogCapturaHuella('índice derecho', '2');

          break;
        default:
          //   this.bcService.onStopSignalR();
          this.dialogCapturaHuella('índice izquierdo', '2');
          break;
      }
    }

  }

  editableDataResponse(response: any) {
    // biocheck.onStopSignalR();
    // $(location).attr('href', '#!/VentanillaINE/ausenciaycaptura');
  }

  public curp?: string | null | undefined;
  public ocr?: String | null | undefined;
  public nombrefront?: string | null | undefined;
  public appatfront?: string | null | undefined;
  public apmatfront?: string | null | undefined;
  public claveElector?: String | null | undefined;
  public codigoEmision?: String | null | undefined;
  public cic: String | null | undefined;
  public anioEmision: String | null | undefined;
  public anioRegistro: String | null | undefined;

  //#region VALIDA CAMPOS INGRESADOS
  validarCampos() {
    var error = false;
    this.validacionCic() ? error = true : error = error;
    this.validacioClaveDeElector() ? error = true : error = error;

    if (!error) {
      $("#btnEscan").css('background-color', 'red');
      $("#btnEscan").css('color', 'white');
      $("#btnEscan").prop("disabled ", false);
    }
    else {
      $("#btnEscan").css('background-color', 'white');
      $("#btnEscan").css('color', '#990000');
      $("#btnEscan").prop("disabled ", true);
    }
    return error;
  }

  validacioClaveDeElector() {
    var error = false;
    var ClaveElector = new String($("#ClaveElectorINE").val());
    if (ClaveElector.length == 0 || ClaveElector == undefined) {
      this.msjclaveElector = 'Campo vacío';
      error = true;
    } else if (ClaveElector.length != 18) {
      this.msjclaveElector = 'Requiere 18 caracteres';
      error = true;
    } else {
      if (ClaveElector.match(/[^A-Z0-9]/g)) {
        this.msjclaveElector = 'Solo se aceptan números y letras en mayúsculas';
        error = true;
      } else {
        this.msjclaveElector = "";
      }
    }
    return error;
  }

  validacionCic() {
    var error = false;
    var cic = new String($("#CIC").val());
    if (cic === "undefined" || cic.length == 0) {
      this.msjCic = 'Campo vacío';
      error = true;
    } else if (cic.length != 9) {
      this.msjCic = 'Requiere 9 caracteres';
      error = true;
    } else {
      if (cic.match(/^[0-9]*$/i)) {
        this.msjCic = "";
      } else {
        this.msjCic = 'Solo se aceptan números';
        error = true;
      }
    }
    return error;
  }

  //#endregion

  dialogCapturaHuella(dedo: any, img: any) {
    this.dialogRef?.close();
    this.dialogRef = this.dialogs.showDialogCaupturaHuellas(dedo, img);
    this.dialogRef.afterClosed().subscribe(
      response => {
        if (response) {

        }
      }
    );
  }
}
