import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VerificacionVentanillaComponent } from "./component/verificacion-ventanilla.component";

const routes: Routes = [
  { path: '', component: VerificacionVentanillaComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VerificacionVentanillaRoutingModule { }
