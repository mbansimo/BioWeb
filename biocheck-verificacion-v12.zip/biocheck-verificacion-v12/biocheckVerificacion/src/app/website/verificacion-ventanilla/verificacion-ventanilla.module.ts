import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerificacionVentanillaRoutingModule } from './verificacion-ventanilla-routing.module';
import { VerificacionVentanillaComponent } from '../verificacion-ventanilla/component/verificacion-ventanilla.component';
import { TooltipModule } from "../tooltip/tooltip.module";
import { CustomTooltipDirective } from "../../directives/custom-tooltip.directive";
import { MatTooltipModule } from '@angular/material/tooltip';

@NgModule({
  declarations: [
    VerificacionVentanillaComponent,
    CustomTooltipDirective
  ],
  imports: [
    CommonModule,
    VerificacionVentanillaRoutingModule,
    TooltipModule,
    MatTooltipModule
  ],
  exports: [
    CustomTooltipDirective
  ],
  bootstrap: [VerificacionVentanillaComponent]
})
export class VerificacionVentanillaModule { }
