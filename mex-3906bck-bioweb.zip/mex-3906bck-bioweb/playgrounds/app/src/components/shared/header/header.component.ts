import { Component } from '@angular/core';

@Component({
  selector: 'pg-header',
  standalone: true,
  imports: [],
  templateUrl: 'header.component.html'

})
export default class HeaderComponent {



  public imgLogo = 'img/logo.png';
  public versionInstalador!: string;
  public versionComercial!: string | undefined;

}
