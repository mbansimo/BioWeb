import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BiocheckWebComponent } from './biocheck-web.component';

describe('BiocheckWebComponent', () => {
  let component: BiocheckWebComponent;
  let fixture: ComponentFixture<BiocheckWebComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BiocheckWebComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BiocheckWebComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
