import { Component } from '@angular/core';

@Component({
  selector: 'lib-biocheck-web',
  standalone: true,
  imports: [],
  template: `
    <p>
      biocheck-web works!
    </p>
  `,
  styles: ``
})
export class BiocheckWebComponent {

}
