import { TestBed } from '@angular/core/testing';

import { BiocheckWebService } from './biocheck-web.service';

describe('BiocheckWebService', () => {
  let service: BiocheckWebService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiocheckWebService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
