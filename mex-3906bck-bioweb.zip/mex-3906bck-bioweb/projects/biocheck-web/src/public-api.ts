/*
 * Public API Surface of biocheck-web
 */

export * from './lib/biocheck-web.service';
export * from './lib/biocheck-web.component';
