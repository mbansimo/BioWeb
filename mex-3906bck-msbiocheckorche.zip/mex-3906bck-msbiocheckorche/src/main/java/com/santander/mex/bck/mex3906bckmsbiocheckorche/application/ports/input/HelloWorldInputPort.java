package com.santander.mex.bck.mex3906bckmsbiocheckorche.application.ports.input;


import com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service.HelloWorldService;
import com.santander.mex.bck.mex3906bckmsbiocheckorche.application.usecases.HelloWorldUseCase;
import org.springframework.stereotype.Component;

/**
 * Input port for hello world application
 * 
 * @author Created by Team DCOE Mx
 */
@Component
public class HelloWorldInputPort implements HelloWorldUseCase {
    
    /**
     * Say hello
     * 
     * @return a greeting
     */
    @Override
    public String sayHello() {
        return HelloWorldService.sayHello();
    }
}
