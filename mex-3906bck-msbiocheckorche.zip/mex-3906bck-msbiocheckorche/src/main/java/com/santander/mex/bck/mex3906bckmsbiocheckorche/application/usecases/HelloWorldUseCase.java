package com.santander.mex.bck.mex3906bckmsbiocheckorche.application.usecases;

/**
 * Hello World Use Case
 * 
 * @author Created by Team DCOE Mx
 */
public interface HelloWorldUseCase {
    /**
     * Say hello use case
     * 
     * @return a greeting
     */
    String sayHello();
}
