package com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service;

import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.InformacionConfiguracionBiocheck;

public interface IInformacionAppService {
    InformacionConfiguracionBiocheck invocandoConfiguracion();
}
