package com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service;

import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.ResponseGeneral;

public interface IOauthService {


    ResponseGeneral generateToken();

    String getAccessToken();
}
