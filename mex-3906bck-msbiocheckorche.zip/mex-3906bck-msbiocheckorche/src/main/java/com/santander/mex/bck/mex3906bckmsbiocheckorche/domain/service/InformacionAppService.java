package com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service;


import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.InformacionConfiguracionBiocheck;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class InformacionAppService implements IInformacionAppService {


    @Value("${version.comercial}")
    private String versionComercial;

    @Value("${version.compilado}")
    private String versionCompilado;

    @Value("${version.front}")
    private String versionFront;

    @Value("${version.instalador}")
    private String versionInstalador;

    @Value("${version.activadorLicencias}")
    private String versionActivadorLicencia;

    @Override
    public InformacionConfiguracionBiocheck invocandoConfiguracion() {

        InformacionConfiguracionBiocheck resp = new InformacionConfiguracionBiocheck();
        resp.setVersionCompilado(versionCompilado);
        resp.setVersionComercial(versionComercial);
        resp.setVersionFront(versionFront);
        resp.setVersionInstalador(versionInstalador);
        resp.setVersionActivadorLicencias(versionActivadorLicencia);

        return resp;
    }


}
