package com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service;


import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.OauthTokenResponseBean;
import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.ResponseGeneral;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Calendar;
import java.util.WeakHashMap;

@Slf4j
@Service
public class OauthService implements IOauthService {

    /**
     * Inyeccion de instancia del objeto RestTemplate para la invocacion de
     * servicios externos
     */
    @Autowired
    private RestTemplate restTemplate;

    @Value("${CLIENT_ID_PAAS}")
    private String CLIENT_ID_PAAS;

    @Value("${URL_GATEWAY_BIOCHECK}")
    private String urlGateway;

    @Value("${PARAM_CLIENTE_ID}")
    private String paramClienteId;


    /**
     * Constante que contiene el nombre del encabezado: client_id
     */
    private static final String CLIENT_ID = "client_id";

    /*
     ** Peticion para generar el bearer
     */

    private static WeakHashMap<String, OauthTokenResponseBean> ACCESS_TOKEN = new WeakHashMap<String, OauthTokenResponseBean>();


    @Override
    public ResponseGeneral generateToken() {
        ResponseGeneral result = new ResponseGeneral();
        String accessToken = getAccessToken();

        if (accessToken == null || "".equals(accessToken)) {
            log.info("Error interno en Access Token ");
            result.setEstatus(HttpStatus.CONFLICT);
            result.setDescripcion("Error en el servicio");
            result.setMensaje("Conflico en el servicio de access token ");

        } else {
            log.info("Token ... SUCCESSFUL");
            result.setMensaje(accessToken);
            result.setDescripcion("Bearer");
            result.setEstatus(HttpStatus.OK);

        }
        return result;
    }

    @Override
    public String getAccessToken() {
        String respuesta = new String();
        String urlCompleta = urlGateway;
        String valores = urlCompleta.trim();

        OauthTokenResponseBean accessToken = ACCESS_TOKEN.get(valores);

        if (!isValidAccessToken(accessToken)) {
            log.info(":: Obteniendo access token, token anterior no es valido::");
            synchronized (this) {
                accessToken = ACCESS_TOKEN.get(valores);
                if (isValidAccessToken(accessToken)) {
                    log.warn(":: Concurrencia de mas de dos hilos no se procesa la solicitud del hilo {} ::", Thread.currentThread().getName());
                    return accessToken.getAccessToken();
                }
                ResponseEntity<OauthTokenResponseBean> responseEntity = invocarServicioAccessToken();

                if (responseEntity != null && responseEntity.getBody() != null) {
                    accessToken = responseEntity.getBody();

                    // Obtencion del tiempo de expiracion
                    Calendar calendar = Calendar.getInstance();
                    if (accessToken != null) {
                        calendar.add(Calendar.SECOND, accessToken.getExpiresIn() - 5);
                        accessToken.setExpiresInAct(calendar.getTimeInMillis());
                        log.debug("Duracion de token {} segundos", accessToken.getExpiresIn());
                        log.debug("Tiempo de expiracion {}", accessToken.getExpiresInAct());

                        // String token = accessToken.getAccessToken();
                        //Adding Bearer Header
                        //accessToken.setAccessToken((new StringBuilder("Bearer ").append(token)).toString());
                        ACCESS_TOKEN.put(valores, accessToken);
                    }
                } else {
                    accessToken = null;
                }
            }
        }
        if (accessToken != null) {
            log.trace(":: Access token para servicios de transacciones: {} ::", accessToken.getAccessToken());
            respuesta = accessToken.getAccessToken();
        }
        return respuesta;
    }

    private ResponseEntity<OauthTokenResponseBean> invocarServicioAccessToken() {
        String urlCompleta = urlGateway.trim();
        log.info(":::" + urlCompleta);

        // Info para armar el mensaje de peticion al servicio
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        // Cabeceras de autenticacion
        MultiValueMap<String, String> mapa = new LinkedMultiValueMap<>();
        mapa.add(CLIENT_ID, CLIENT_ID_PAAS);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(mapa, headers);

        log.trace(":: URL ACCESS TOKEN: {} ", urlCompleta.trim());

        ResponseEntity<OauthTokenResponseBean> responseEntity = null;
        OauthTokenResponseBean body = new OauthTokenResponseBean();
        try {
            responseEntity = restTemplate.exchange(urlCompleta.trim(), HttpMethod.POST, request, OauthTokenResponseBean.class);

            if (responseEntity != null && responseEntity.getBody() != null) {
                body = responseEntity.getBody();
            }
            if (body != null) {
                log.debug("Body response: [{}]", StringUtils.trimAllWhitespace(body.toString()));
            }

        } catch (RestClientException rce) {
            log.error("Error invocando al servicio ", rce);
        }

        return responseEntity;
    }

    private boolean isValidAccessToken(OauthTokenResponseBean accessTokenDTO) {

        boolean isValid = false;

        if (accessTokenDTO != null && accessTokenDTO.getExpiresInAct() >= Calendar.getInstance().getTimeInMillis()) {
            log.trace("ExpiresInAct {}, Calendar {}", accessTokenDTO.getExpiresInAct(),
                    Calendar.getInstance().getTimeInMillis());
            isValid = true;
        }

        log.debug(":: Estatus del token: {} ::", isValid);

        return isValid;
    }
}
