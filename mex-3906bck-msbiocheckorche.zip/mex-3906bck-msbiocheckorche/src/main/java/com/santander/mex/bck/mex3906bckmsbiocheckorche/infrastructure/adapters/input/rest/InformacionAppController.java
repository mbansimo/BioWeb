package com.santander.mex.bck.mex3906bckmsbiocheckorche.infrastructure.adapters.input.rest;


import com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service.IInformacionAppService;
import com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service.InformacionAppService;
import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.InformacionConfiguracionBiocheck;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@RequestMapping("/biocheck/information")
public class InformacionAppController {

    @Autowired
    IInformacionAppService service;


    @GetMapping(value = "/versiones")
    public ResponseEntity<Object> obtenerInformacionVersion() {
        log.info("Solicitud de informacion de versionado de aplicacion de biocheck ");
        HttpStatus estatus = HttpStatus.OK;
        InformacionConfiguracionBiocheck response = service.invocandoConfiguracion();
        if (response.getVersionInstalador() == null) {
            estatus = HttpStatus.CONFLICT;
        }
        return new ResponseEntity<>(response, estatus);
    }


}

