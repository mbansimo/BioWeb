package com.santander.mex.bck.mex3906bckmsbiocheckorche.infrastructure.adapters.input.rest;


import com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service.IOauthService;
import com.santander.mex.bck.mex3906bckmsbiocheckorche.model.ResponseGeneral;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/biocheck/token")
@Slf4j
public class OauthController {

    @Autowired
    private IOauthService oauthService;


    /*
     ** Crear el AccesToken para poder generar el token requerido despues
     *
     */
    @PostMapping(value = "/createAccessToken", produces = {"application/json;charset=UTF-8"})
    public ResponseEntity<Object> createAccessToken() {
        log.info(":::: Solicitud accessToken ::::");
        HttpStatus estatus = HttpStatus.ACCEPTED;
        ResponseGeneral response = new ResponseGeneral();
        response = oauthService.generateToken();
        return new ResponseEntity<>(response, estatus);
    }


/*    @PostMapping(value = "/tokenTransversal")
    public ResponseEntity<Object> createTokenTransversal(){
        log.trace("Solicitud de token transversal ");
        HttpStatus estatus = HttpStatus.ACCEPTED;



        return new ResponseEntity<>(response, estatus);
    }*/


}
