package com.santander.mex.bck.mex3906bckmsbiocheckorche.infrastructure.config;


import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Enable caching in the application.
 */
@Configuration
@EnableCaching
class ApplicationConfiguration  {


    @Bean
    public RestTemplate restTemplate() {
        //Inicializa un RestTemplate por default
        return new RestTemplate();
    }

}
