package com.santander.mex.bck.mex3906bckmsbiocheckorche.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;


@Getter
@Setter
public class OauthTokenResponseBean implements Serializable {
    @Serial
    private static final long serialVersionUID = -3852746149899277650L;

    /**
     * Propiedad con el valor del tokenType
     */
    @JsonProperty("token_type")
    private String tokenType;

    /**
     * Propiedad con el valor del accessToken
     */
    @JsonProperty("access_token")
    private String accessToken;

    /**
     * Propiedad con el valor del tiempo de expiracion del token en segundos
     */
    @JsonProperty("expires_in")
    private int expiresIn;

    /**
     * Propiedad con el valor del scope del Token de API
     */
    @JsonProperty("scope")
    private String scope;

    /**
     * Propiedad con el valor de la fecha de expiracion en milisegundos a partir de 1970
     */
    private long expiresInAct;




}
