package com.santander.mex.bck.mex3906bckmsbiocheckorche.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;


@Getter
@Setter
public class ResponseAccesToken implements Serializable {
    @Serial
    private static final long serialVersionUID = 3604108066479777953L;

    String access_token;
    String token_type;
    String scope;
    int expires_in;

}
