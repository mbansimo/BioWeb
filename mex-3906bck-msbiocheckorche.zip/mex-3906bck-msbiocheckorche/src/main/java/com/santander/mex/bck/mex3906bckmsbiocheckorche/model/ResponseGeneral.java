package com.santander.mex.bck.mex3906bckmsbiocheckorche.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseGeneral implements Serializable {

    @Serial
    private static final long serialVersionUID = 7144323062586554943L;

    HttpStatus estatus;
    String mensaje;
    String descripcion;
}
