package com.santander.mex.bck.mex3906bckmsbiocheckorche.domain.service;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class HelloWorldServiceTest {
    @Test
    public void testSayHello() {
        assertEquals("Hello World!", HelloWorldService.sayHello());
    }
}
