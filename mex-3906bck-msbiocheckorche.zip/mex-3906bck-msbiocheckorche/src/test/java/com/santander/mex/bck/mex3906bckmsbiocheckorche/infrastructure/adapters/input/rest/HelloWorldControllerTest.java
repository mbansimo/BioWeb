package com.santander.mex.bck.mex3906bckmsbiocheckorche.infrastructure.adapters.input.rest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.junit.jupiter.api.condition.DisabledInNativeImage;

@ActiveProfiles("test")
@SpringBootTest
@AutoConfigureWebTestClient
@WithMockUser
@DisabledInNativeImage
class HelloWorldControllerTest {

    @Autowired
    WebTestClient webTestClient;

    @Test
    void testCallHelloEndpoint() throws Exception {
        webTestClient.get().uri("/mex-3906bck-msbiocheckorche/hello")
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class).isEqualTo("Hello World!");
    }
}
